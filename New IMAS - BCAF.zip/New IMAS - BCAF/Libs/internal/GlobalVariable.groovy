package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object URLDev
     
    /**
     * <p></p>
     */
    public static Object Username
     
    /**
     * <p></p>
     */
    public static Object Password
     
    /**
     * <p></p>
     */
    public static Object Path
     
    /**
     * <p></p>
     */
    public static Object NoBAST
     
    /**
     * <p></p>
     */
    public static Object ChkboxKontak
     
    /**
     * <p></p>
     */
    public static Object ChkboxAlarm
     
    /**
     * <p></p>
     */
    public static Object ChkboxLampuDpn
     
    /**
     * <p></p>
     */
    public static Object ChkboxWiper
     
    /**
     * <p></p>
     */
    public static Object ChkboxSpionKr
     
    /**
     * <p></p>
     */
    public static Object ChkboxSpionKnn
     
    /**
     * <p></p>
     */
    public static Object ChkboxVelgDpnKr
     
    /**
     * <p></p>
     */
    public static Object ChkboxVelgDpnKnn
     
    /**
     * <p></p>
     */
    public static Object ChkboxVelgBlkgKnn
     
    /**
     * <p></p>
     */
    public static Object ChkboxVelgBlkgKr
     
    /**
     * <p></p>
     */
    public static Object ChkboxVelgSrp
     
    /**
     * <p></p>
     */
    public static Object ChkboxLampublkg
     
    /**
     * <p></p>
     */
    public static Object ChkboxKondisiCat
     
    /**
     * <p></p>
     */
    public static Object PerbedaanKontak
     
    /**
     * <p></p>
     */
    public static Object PerbedaanAlarm
     
    /**
     * <p></p>
     */
    public static Object PerbedaanLampuDpn
     
    /**
     * <p></p>
     */
    public static Object PerbedaanWiper
     
    /**
     * <p></p>
     */
    public static Object PerbedaanSpionKr
     
    /**
     * <p></p>
     */
    public static Object PerbedaanSpionKnn
     
    /**
     * <p></p>
     */
    public static Object PerbedaanVelgDpnKr
     
    /**
     * <p></p>
     */
    public static Object PerbedaanVelgDpnKanan
     
    /**
     * <p></p>
     */
    public static Object PerbedaanVelgBlkgKanan
     
    /**
     * <p></p>
     */
    public static Object PerbedaanVelgBlkgKr
     
    /**
     * <p></p>
     */
    public static Object PerbedaanVelgSrp
     
    /**
     * <p></p>
     */
    public static Object PerbedaanLampublg
     
    /**
     * <p></p>
     */
    public static Object PerbedaanKondisiCat
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBKunciKontak
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBAlarm
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBLampuDpn
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBWiper
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBSpionKr
     
    /**
     * <p>Profile default : 1= Elektrik, 2=NonElektrik</p>
     */
    public static Object RBTipeSpionKr
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBSpionKnn
     
    /**
     * <p>Profile default : 1= Elektrik, 2=NonElektrik</p>
     */
    public static Object RBTipeSpionKnn
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBVelgDpnKr
     
    /**
     * <p>Profile default : 1= Elektrik, 2=NonElektrik</p>
     */
    public static Object RBTipeVelgDpnKr
     
    /**
     * <p>Profile default : 1= Ada, 2=Tidak ada</p>
     */
    public static Object RBDopVelgDpnKr
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBVelgDpnKnn
     
    /**
     * <p>Profile default : 1= Elektrik, 2=NonElektrik</p>
     */
    public static Object RBTipeVelgDpnKnn
     
    /**
     * <p>Profile default : 1= Ada, 2=Tidak ada</p>
     */
    public static Object RBDopVelgDpnKnn
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBVelgBlkgKnn
     
    /**
     * <p>Profile default : 1= Elektrik, 2=NonElektrik</p>
     */
    public static Object RBTipeVelgBlkgKnn
     
    /**
     * <p>Profile default : 1= Ada, 2=Tidak ada</p>
     */
    public static Object RBDopVelgBlkgKnn
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBVelgBlkgKr
     
    /**
     * <p>Profile default : 1= Elektrik, 2=NonElektrik</p>
     */
    public static Object RBTipeVelgBlkgKr
     
    /**
     * <p>Profile default : 1= Ada, 2=Tidak ada</p>
     */
    public static Object RBDopVelgBlkgKr
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBVelgSrp
     
    /**
     * <p>Profile default : 1= Elektrik, 2=NonElektrik</p>
     */
    public static Object RBTipeVelgSrp
     
    /**
     * <p>Profile default : 1= Ada, 2=Tidak ada</p>
     */
    public static Object RBDopVelgSrp
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBLampuBlkg
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBKondisiCat
     
    /**
     * <p></p>
     */
    public static Object JumlahKontak
     
    /**
     * <p></p>
     */
    public static Object ChkboxRadio
     
    /**
     * <p></p>
     */
    public static Object ChkboxAC
     
    /**
     * <p></p>
     */
    public static Object ChkboxSpionDlm
     
    /**
     * <p></p>
     */
    public static Object ChkboxPwrWndw
     
    /**
     * <p></p>
     */
    public static Object ChkboxCentralLock
     
    /**
     * <p></p>
     */
    public static Object ChkboxKursi
     
    /**
     * <p></p>
     */
    public static Object ChkboxKarpet
     
    /**
     * <p></p>
     */
    public static Object ChkboxTang
     
    /**
     * <p></p>
     */
    public static Object ChkboxObeng
     
    /**
     * <p></p>
     */
    public static Object ChkboxKunciPas
     
    /**
     * <p></p>
     */
    public static Object ChkboxKunciBan
     
    /**
     * <p></p>
     */
    public static Object ChkboxDongkrak
     
    /**
     * <p></p>
     */
    public static Object ChkboxSegitiga
     
    /**
     * <p></p>
     */
    public static Object ChkboxBarangKnsmn
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBRadio
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBAC
     
    /**
     * <p>Profile default : 1= Single, 2=Double</p>
     */
    public static Object RBtipeAC
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBSpionDlm
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBPwrWndw
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBCentralLock
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBKursi
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBKarpet
     
    /**
     * <p>Profile default : 1= Standar, 2=Ada-Tambah</p>
     */
    public static Object RBTipeKarpet
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBTang
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBObeng
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBKunciPas
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBKunciBan
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBDongkrak
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBSegitiga
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBBarangKnsmn
     
    /**
     * <p></p>
     */
    public static Object PerbedaanRadio
     
    /**
     * <p></p>
     */
    public static Object PerbedaanAC
     
    /**
     * <p></p>
     */
    public static Object PerbedaanSpionDlm
     
    /**
     * <p></p>
     */
    public static Object PerbedaanPwrWndw
     
    /**
     * <p></p>
     */
    public static Object PerbedaanCentralLock
     
    /**
     * <p></p>
     */
    public static Object PerbedaanKursi
     
    /**
     * <p></p>
     */
    public static Object PerbedaanKarpet
     
    /**
     * <p></p>
     */
    public static Object PerbedaanTang
     
    /**
     * <p></p>
     */
    public static Object PerbedaanObeng
     
    /**
     * <p></p>
     */
    public static Object PerbedaanKunciPas
     
    /**
     * <p></p>
     */
    public static Object PerbedaanKunciBan
     
    /**
     * <p></p>
     */
    public static Object PerbedaanDongkrak
     
    /**
     * <p></p>
     */
    public static Object PerbedaanSegitiga
     
    /**
     * <p></p>
     */
    public static Object PerbedaanBarangKnsmn
     
    /**
     * <p></p>
     */
    public static Object JumlahKursi
     
    /**
     * <p></p>
     */
    public static Object JumlahKarpet
     
    /**
     * <p></p>
     */
    public static Object DeskripsiBrgKnsmn
     
    /**
     * <p></p>
     */
    public static Object ChkboxMesin
     
    /**
     * <p></p>
     */
    public static Object ChkboxAccu
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBMesin
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBAccu
     
    /**
     * <p></p>
     */
    public static Object PerbedaanMesin
     
    /**
     * <p></p>
     */
    public static Object PerbedaanAccu
     
    /**
     * <p></p>
     */
    public static Object KelengkapanKendaraan
     
    /**
     * <p></p>
     */
    public static Object KeteranganRusak
     
    /**
     * <p></p>
     */
    public static Object fotoKerusakan
     
    /**
     * <p></p>
     */
    public static Object RemarkSubmit
     
    /**
     * <p></p>
     */
    public static Object NoPolisi
     
    /**
     * <p></p>
     */
    public static Object Pool
     
    /**
     * <p></p>
     */
    public static Object BulanKonsumen
     
    /**
     * <p></p>
     */
    public static Object TanggalKonsumen
     
    /**
     * <p></p>
     */
    public static Object TahunKonsumen
     
    /**
     * <p></p>
     */
    public static Object BulanPool
     
    /**
     * <p></p>
     */
    public static Object TanggalPool
     
    /**
     * <p></p>
     */
    public static Object TahunPool
     
    /**
     * <p></p>
     */
    public static Object KotaKendaraan
     
    /**
     * <p></p>
     */
    public static Object Lokasikendaraan
     
    /**
     * <p></p>
     */
    public static Object Kilometer
     
    /**
     * <p></p>
     */
    public static Object MeterBensin
     
    /**
     * <p></p>
     */
    public static Object STNK5thn
     
    /**
     * <p></p>
     */
    public static Object STNK1thn
     
    /**
     * <p></p>
     */
    public static Object KIR
     
    /**
     * <p></p>
     */
    public static Object ManualService
     
    /**
     * <p></p>
     */
    public static Object Perbedaan5thn
     
    /**
     * <p></p>
     */
    public static Object Perbedaan1thn
     
    /**
     * <p></p>
     */
    public static Object PerbedaanKIR
     
    /**
     * <p></p>
     */
    public static Object PerbedaanManualService
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBSTNK5thn
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBSTNK1thn
     
    /**
     * <p>Profile default : 1= Ada-Baik, 2=Ada-Rusak, 3=Tidak ada</p>
     */
    public static Object RBKIR
     
    /**
     * <p></p>
     */
    public static Object RBManualService
     
    /**
     * <p></p>
     */
    public static Object Bulan5thn
     
    /**
     * <p></p>
     */
    public static Object Tanggal5thn
     
    /**
     * <p></p>
     */
    public static Object Tahun5thn
     
    /**
     * <p></p>
     */
    public static Object Pajak1Tahun
     
    /**
     * <p></p>
     */
    public static Object Bulan1thn
     
    /**
     * <p></p>
     */
    public static Object Tanggal1thn
     
    /**
     * <p></p>
     */
    public static Object Tahun1thn
     
    /**
     * <p></p>
     */
    public static Object BulanKIR
     
    /**
     * <p></p>
     */
    public static Object TanggalKIR
     
    /**
     * <p></p>
     */
    public static Object TahunKIR
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            URLDev = selectedVariables['URLDev']
            Username = selectedVariables['Username']
            Password = selectedVariables['Password']
            Path = selectedVariables['Path']
            NoBAST = selectedVariables['NoBAST']
            ChkboxKontak = selectedVariables['ChkboxKontak']
            ChkboxAlarm = selectedVariables['ChkboxAlarm']
            ChkboxLampuDpn = selectedVariables['ChkboxLampuDpn']
            ChkboxWiper = selectedVariables['ChkboxWiper']
            ChkboxSpionKr = selectedVariables['ChkboxSpionKr']
            ChkboxSpionKnn = selectedVariables['ChkboxSpionKnn']
            ChkboxVelgDpnKr = selectedVariables['ChkboxVelgDpnKr']
            ChkboxVelgDpnKnn = selectedVariables['ChkboxVelgDpnKnn']
            ChkboxVelgBlkgKnn = selectedVariables['ChkboxVelgBlkgKnn']
            ChkboxVelgBlkgKr = selectedVariables['ChkboxVelgBlkgKr']
            ChkboxVelgSrp = selectedVariables['ChkboxVelgSrp']
            ChkboxLampublkg = selectedVariables['ChkboxLampublkg']
            ChkboxKondisiCat = selectedVariables['ChkboxKondisiCat']
            PerbedaanKontak = selectedVariables['PerbedaanKontak']
            PerbedaanAlarm = selectedVariables['PerbedaanAlarm']
            PerbedaanLampuDpn = selectedVariables['PerbedaanLampuDpn']
            PerbedaanWiper = selectedVariables['PerbedaanWiper']
            PerbedaanSpionKr = selectedVariables['PerbedaanSpionKr']
            PerbedaanSpionKnn = selectedVariables['PerbedaanSpionKnn']
            PerbedaanVelgDpnKr = selectedVariables['PerbedaanVelgDpnKr']
            PerbedaanVelgDpnKanan = selectedVariables['PerbedaanVelgDpnKanan']
            PerbedaanVelgBlkgKanan = selectedVariables['PerbedaanVelgBlkgKanan']
            PerbedaanVelgBlkgKr = selectedVariables['PerbedaanVelgBlkgKr']
            PerbedaanVelgSrp = selectedVariables['PerbedaanVelgSrp']
            PerbedaanLampublg = selectedVariables['PerbedaanLampublg']
            PerbedaanKondisiCat = selectedVariables['PerbedaanKondisiCat']
            RBKunciKontak = selectedVariables['RBKunciKontak']
            RBAlarm = selectedVariables['RBAlarm']
            RBLampuDpn = selectedVariables['RBLampuDpn']
            RBWiper = selectedVariables['RBWiper']
            RBSpionKr = selectedVariables['RBSpionKr']
            RBTipeSpionKr = selectedVariables['RBTipeSpionKr']
            RBSpionKnn = selectedVariables['RBSpionKnn']
            RBTipeSpionKnn = selectedVariables['RBTipeSpionKnn']
            RBVelgDpnKr = selectedVariables['RBVelgDpnKr']
            RBTipeVelgDpnKr = selectedVariables['RBTipeVelgDpnKr']
            RBDopVelgDpnKr = selectedVariables['RBDopVelgDpnKr']
            RBVelgDpnKnn = selectedVariables['RBVelgDpnKnn']
            RBTipeVelgDpnKnn = selectedVariables['RBTipeVelgDpnKnn']
            RBDopVelgDpnKnn = selectedVariables['RBDopVelgDpnKnn']
            RBVelgBlkgKnn = selectedVariables['RBVelgBlkgKnn']
            RBTipeVelgBlkgKnn = selectedVariables['RBTipeVelgBlkgKnn']
            RBDopVelgBlkgKnn = selectedVariables['RBDopVelgBlkgKnn']
            RBVelgBlkgKr = selectedVariables['RBVelgBlkgKr']
            RBTipeVelgBlkgKr = selectedVariables['RBTipeVelgBlkgKr']
            RBDopVelgBlkgKr = selectedVariables['RBDopVelgBlkgKr']
            RBVelgSrp = selectedVariables['RBVelgSrp']
            RBTipeVelgSrp = selectedVariables['RBTipeVelgSrp']
            RBDopVelgSrp = selectedVariables['RBDopVelgSrp']
            RBLampuBlkg = selectedVariables['RBLampuBlkg']
            RBKondisiCat = selectedVariables['RBKondisiCat']
            JumlahKontak = selectedVariables['JumlahKontak']
            ChkboxRadio = selectedVariables['ChkboxRadio']
            ChkboxAC = selectedVariables['ChkboxAC']
            ChkboxSpionDlm = selectedVariables['ChkboxSpionDlm']
            ChkboxPwrWndw = selectedVariables['ChkboxPwrWndw']
            ChkboxCentralLock = selectedVariables['ChkboxCentralLock']
            ChkboxKursi = selectedVariables['ChkboxKursi']
            ChkboxKarpet = selectedVariables['ChkboxKarpet']
            ChkboxTang = selectedVariables['ChkboxTang']
            ChkboxObeng = selectedVariables['ChkboxObeng']
            ChkboxKunciPas = selectedVariables['ChkboxKunciPas']
            ChkboxKunciBan = selectedVariables['ChkboxKunciBan']
            ChkboxDongkrak = selectedVariables['ChkboxDongkrak']
            ChkboxSegitiga = selectedVariables['ChkboxSegitiga']
            ChkboxBarangKnsmn = selectedVariables['ChkboxBarangKnsmn']
            RBRadio = selectedVariables['RBRadio']
            RBAC = selectedVariables['RBAC']
            RBtipeAC = selectedVariables['RBtipeAC']
            RBSpionDlm = selectedVariables['RBSpionDlm']
            RBPwrWndw = selectedVariables['RBPwrWndw']
            RBCentralLock = selectedVariables['RBCentralLock']
            RBKursi = selectedVariables['RBKursi']
            RBKarpet = selectedVariables['RBKarpet']
            RBTipeKarpet = selectedVariables['RBTipeKarpet']
            RBTang = selectedVariables['RBTang']
            RBObeng = selectedVariables['RBObeng']
            RBKunciPas = selectedVariables['RBKunciPas']
            RBKunciBan = selectedVariables['RBKunciBan']
            RBDongkrak = selectedVariables['RBDongkrak']
            RBSegitiga = selectedVariables['RBSegitiga']
            RBBarangKnsmn = selectedVariables['RBBarangKnsmn']
            PerbedaanRadio = selectedVariables['PerbedaanRadio']
            PerbedaanAC = selectedVariables['PerbedaanAC']
            PerbedaanSpionDlm = selectedVariables['PerbedaanSpionDlm']
            PerbedaanPwrWndw = selectedVariables['PerbedaanPwrWndw']
            PerbedaanCentralLock = selectedVariables['PerbedaanCentralLock']
            PerbedaanKursi = selectedVariables['PerbedaanKursi']
            PerbedaanKarpet = selectedVariables['PerbedaanKarpet']
            PerbedaanTang = selectedVariables['PerbedaanTang']
            PerbedaanObeng = selectedVariables['PerbedaanObeng']
            PerbedaanKunciPas = selectedVariables['PerbedaanKunciPas']
            PerbedaanKunciBan = selectedVariables['PerbedaanKunciBan']
            PerbedaanDongkrak = selectedVariables['PerbedaanDongkrak']
            PerbedaanSegitiga = selectedVariables['PerbedaanSegitiga']
            PerbedaanBarangKnsmn = selectedVariables['PerbedaanBarangKnsmn']
            JumlahKursi = selectedVariables['JumlahKursi']
            JumlahKarpet = selectedVariables['JumlahKarpet']
            DeskripsiBrgKnsmn = selectedVariables['DeskripsiBrgKnsmn']
            ChkboxMesin = selectedVariables['ChkboxMesin']
            ChkboxAccu = selectedVariables['ChkboxAccu']
            RBMesin = selectedVariables['RBMesin']
            RBAccu = selectedVariables['RBAccu']
            PerbedaanMesin = selectedVariables['PerbedaanMesin']
            PerbedaanAccu = selectedVariables['PerbedaanAccu']
            KelengkapanKendaraan = selectedVariables['KelengkapanKendaraan']
            KeteranganRusak = selectedVariables['KeteranganRusak']
            fotoKerusakan = selectedVariables['fotoKerusakan']
            RemarkSubmit = selectedVariables['RemarkSubmit']
            NoPolisi = selectedVariables['NoPolisi']
            Pool = selectedVariables['Pool']
            BulanKonsumen = selectedVariables['BulanKonsumen']
            TanggalKonsumen = selectedVariables['TanggalKonsumen']
            TahunKonsumen = selectedVariables['TahunKonsumen']
            BulanPool = selectedVariables['BulanPool']
            TanggalPool = selectedVariables['TanggalPool']
            TahunPool = selectedVariables['TahunPool']
            KotaKendaraan = selectedVariables['KotaKendaraan']
            Lokasikendaraan = selectedVariables['Lokasikendaraan']
            Kilometer = selectedVariables['Kilometer']
            MeterBensin = selectedVariables['MeterBensin']
            STNK5thn = selectedVariables['STNK5thn']
            STNK1thn = selectedVariables['STNK1thn']
            KIR = selectedVariables['KIR']
            ManualService = selectedVariables['ManualService']
            Perbedaan5thn = selectedVariables['Perbedaan5thn']
            Perbedaan1thn = selectedVariables['Perbedaan1thn']
            PerbedaanKIR = selectedVariables['PerbedaanKIR']
            PerbedaanManualService = selectedVariables['PerbedaanManualService']
            RBSTNK5thn = selectedVariables['RBSTNK5thn']
            RBSTNK1thn = selectedVariables['RBSTNK1thn']
            RBKIR = selectedVariables['RBKIR']
            RBManualService = selectedVariables['RBManualService']
            Bulan5thn = selectedVariables['Bulan5thn']
            Tanggal5thn = selectedVariables['Tanggal5thn']
            Tahun5thn = selectedVariables['Tahun5thn']
            Pajak1Tahun = selectedVariables['Pajak1Tahun']
            Bulan1thn = selectedVariables['Bulan1thn']
            Tanggal1thn = selectedVariables['Tanggal1thn']
            Tahun1thn = selectedVariables['Tahun1thn']
            BulanKIR = selectedVariables['BulanKIR']
            TanggalKIR = selectedVariables['TanggalKIR']
            TahunKIR = selectedVariables['TahunKIR']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
