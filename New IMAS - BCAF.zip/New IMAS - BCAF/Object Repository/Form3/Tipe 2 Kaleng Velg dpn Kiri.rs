<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Tipe 2 Kaleng Velg dpn Kiri</name>
   <tag></tag>
   <elementGuidId>471bbee6-dbda-4923-8c8d-274f359b5ba8</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Ban + Velg Depan Kiri']&#xd;
    /following::android.widget.RadioGroup[2]&#xd;
    //android.widget.RadioButton[@text='Kaleng']&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
