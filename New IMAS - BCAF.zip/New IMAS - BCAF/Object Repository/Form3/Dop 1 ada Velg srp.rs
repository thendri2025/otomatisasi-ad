<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Dop 1 ada Velg srp</name>
   <tag></tag>
   <elementGuidId>aff121a1-b01b-437b-8969-7b97f34c6bc3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Ban + Velg Serep']&#xd;
    /following::android.widget.RadioGroup[3]&#xd;
    //android.widget.RadioButton[@text='Ada']&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
