<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>RB Ada rusak 6 Spion kanan</name>
   <tag></tag>
   <elementGuidId>cb48c676-c0a6-49db-aa4d-f9b411298db4</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Kaca Spion Kanan']&#xd;
 /following::android.widget.RadioButton[@text='Ada - Rusak'][1]&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
