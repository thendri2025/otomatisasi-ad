<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Dop 2 tidak Velg srp</name>
   <tag></tag>
   <elementGuidId>64a5c0ba-4327-4978-a0f7-2cf646fa7734</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Ban + Velg Serep']&#xd;
    /following::android.widget.RadioGroup[3]&#xd;
    //android.widget.RadioButton[@text='Tidak']&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
