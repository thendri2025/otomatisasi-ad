<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Tipe 1 Elektrik Spion Kanan</name>
   <tag></tag>
   <elementGuidId>55f50f04-49e0-427c-a93c-04292aec846b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.RadioButton' and (@text = 'Electric' or . = 'Electric') and @resource-id = 'com.indocyber.bcaf:id/electricRadioButton']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
