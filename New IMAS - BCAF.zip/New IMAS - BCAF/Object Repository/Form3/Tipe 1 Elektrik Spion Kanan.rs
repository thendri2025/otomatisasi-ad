<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Tipe 1 Elektrik Spion Kanan</name>
   <tag></tag>
   <elementGuidId>c25c7b9b-8a78-41f4-86d8-494d1bce0987</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Kaca Spion Kanan']&#xd;
    /following::android.widget.RadioGroup[2]&#xd;
    //android.widget.RadioButton[@text='Electric']&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
