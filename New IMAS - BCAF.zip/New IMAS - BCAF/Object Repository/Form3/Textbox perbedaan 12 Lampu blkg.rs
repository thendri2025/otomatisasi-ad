<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Textbox perbedaan 12 Lampu blkg</name>
   <tag></tag>
   <elementGuidId>ee382e4e-3194-461f-815f-4adfb9a6a87b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[.//android.widget.TextView[@text='Lampu Belakang']]//android.widget.EditText&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
