<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Upload Samping kanan</name>
   <tag></tag>
   <elementGuidId>0d4ee06f-4d57-473e-97f7-585691e38f87</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[@class = 'android.widget.ImageView' and @resource-id = 'com.indocyber.bcaf:id/takePictureImageView' and (@text = '' or . = '')])[5]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
