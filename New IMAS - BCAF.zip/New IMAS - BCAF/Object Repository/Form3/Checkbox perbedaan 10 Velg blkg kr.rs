<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Checkbox perbedaan 10 Velg blkg kr</name>
   <tag></tag>
   <elementGuidId>3c268036-78b9-4b21-9d01-6bd3902122ae</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[./android.widget.TextView[@text='Ban + Velg Belakang Kiri']]//android.widget.CheckBox[@text='Ada Perbedaan']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
