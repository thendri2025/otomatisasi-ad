<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Tipe 2 Non Elektrik Spion Kanan</name>
   <tag></tag>
   <elementGuidId>2008a5d2-202a-42f1-9370-aff360f843b2</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Kaca Spion Kanan']&#xd;
/following::android.widget.RadioButton[@text='Non Electric'][1]&#xd;
&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
