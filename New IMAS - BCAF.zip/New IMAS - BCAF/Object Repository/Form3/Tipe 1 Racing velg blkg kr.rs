<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Tipe 1 Racing velg blkg kr</name>
   <tag></tag>
   <elementGuidId>8dbc2690-9807-40ee-bbba-576954d9ed52</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Ban + Velg Belakang Kiri']&#xd;
    /following::android.widget.RadioGroup[2]&#xd;
    //android.widget.RadioButton[@text='Racing']&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
