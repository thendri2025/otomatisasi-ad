<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Tipe 2 Kaleng Velg blkg knn</name>
   <tag></tag>
   <elementGuidId>cd05b97c-d7f1-4a17-9f47-2ae8d2943b80</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Ban + Velg Belakang Kanan']&#xd;
    /following::android.widget.RadioGroup[2]&#xd;
    //android.widget.RadioButton[@text='Kaleng']&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
