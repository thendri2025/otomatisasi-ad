<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Dop 2 Tida velg blkg kn</name>
   <tag></tag>
   <elementGuidId>5cab5c75-b58b-40f3-a46e-5aee1dd26772</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Ban + Velg Belakang Kanan']&#xd;
    /following::android.widget.RadioGroup[3]&#xd;
    //android.widget.RadioButton[@text='Tidak']&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
