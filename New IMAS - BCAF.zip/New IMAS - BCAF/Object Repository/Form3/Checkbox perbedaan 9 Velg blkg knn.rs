<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Checkbox perbedaan 9 Velg blkg knn</name>
   <tag></tag>
   <elementGuidId>66a295a4-128e-4124-9853-fa96f648c659</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[./android.widget.TextView[@text='Ban + Velg Belakang Kanan']]//android.widget.CheckBox[@text='Ada Perbedaan']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
