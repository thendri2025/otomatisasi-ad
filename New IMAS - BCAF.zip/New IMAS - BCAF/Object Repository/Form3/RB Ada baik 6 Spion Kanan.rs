<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>RB Ada baik 6 Spion Kanan</name>
   <tag></tag>
   <elementGuidId>f6f24d66-6eea-4a60-8e2f-1f3e408dd1c6</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Kaca Spion Kanan']&#xd;
    /following::android.widget.RadioGroup[1]&#xd;
    //android.widget.RadioButton[contains(@text,'Ada - Baik')]&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
