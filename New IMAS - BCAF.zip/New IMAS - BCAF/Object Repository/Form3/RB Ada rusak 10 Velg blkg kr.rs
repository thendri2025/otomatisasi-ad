<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>RB Ada rusak 10 Velg blkg kr</name>
   <tag></tag>
   <elementGuidId>20b8e84f-5c2a-4ede-b4e0-44c284a8cdf9</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Ban + Velg Belakang Kiri']&#xd;
    /following::android.widget.RadioGroup[1]&#xd;
    //android.widget.RadioButton[contains(@text,'Ada - Rusak')]&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
