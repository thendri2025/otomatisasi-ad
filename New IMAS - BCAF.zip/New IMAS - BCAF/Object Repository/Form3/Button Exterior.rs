<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Button Exterior</name>
   <tag></tag>
   <elementGuidId>8db86611-c56f-4a0c-98bf-54f5fa876e36</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.ImageView' and @resource-id = 'com.indocyber.bcaf:id/imgAttachment' and (@text = '' or . = '')]</locator>
   <locatorCollection>
      <entry>
         <key>ATTRIBUTES</key>
         <value>(//*[@class = 'android.widget.LinearLayout' and (@text = '' or . = '')])[1]</value>
      </entry>
      <entry>
         <key>CLASS_NAME</key>
         <value></value>
      </entry>
      <entry>
         <key>CUSTOM</key>
         <value></value>
      </entry>
      <entry>
         <key>ID</key>
         <value></value>
      </entry>
      <entry>
         <key>IOS_CLASS_CHAIN</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@class = 'android.widget.ImageView' and @resource-id = 'com.indocyber.bcaf:id/imgAttachment' and (@text = '' or . = '')]</value>
      </entry>
      <entry>
         <key>IMAGE</key>
         <value></value>
      </entry>
      <entry>
         <key>ANDROID_UI_AUTOMATOR</key>
         <value>new UiSelector()</value>
      </entry>
      <entry>
         <key>ACCESSIBILITY</key>
         <value></value>
      </entry>
      <entry>
         <key>NAME</key>
         <value></value>
      </entry>
      <entry>
         <key>ANDROID_VIEWTAG</key>
         <value></value>
      </entry>
      <entry>
         <key>IOS_PREDICATE_STRING</key>
         <value></value>
      </entry>
   </locatorCollection>
   <locatorStrategy>XPATH</locatorStrategy>
   <platform>ANDROID</platform>
</MobileElementEntity>
