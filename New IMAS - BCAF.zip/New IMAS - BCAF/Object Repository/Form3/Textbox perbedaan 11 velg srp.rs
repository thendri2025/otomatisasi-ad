<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Textbox perbedaan 11 velg srp</name>
   <tag></tag>
   <elementGuidId>8f1d108d-a4cc-41fe-934d-d2d7a9e5cd56</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[.//android.widget.TextView[@text='Ban + Velg Serep']]//android.widget.EditText</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
