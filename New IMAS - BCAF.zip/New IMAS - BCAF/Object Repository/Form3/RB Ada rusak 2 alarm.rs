<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>RB Ada rusak 2 alarm</name>
   <tag></tag>
   <elementGuidId>a7efd706-5d67-4727-a1a2-1b098795d3b4</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Alarm']&#xd;
    /following::android.widget.RadioGroup[1]&#xd;
    //android.widget.RadioButton[contains(@text,'Ada - Rusak')]&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
