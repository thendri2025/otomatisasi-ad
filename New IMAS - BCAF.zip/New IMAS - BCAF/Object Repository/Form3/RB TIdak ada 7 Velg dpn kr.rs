<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>RB TIdak ada 7 Velg dpn kr</name>
   <tag></tag>
   <elementGuidId>4fa35187-6622-4bb0-b8f4-4a7dc2b1dedd</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Ban + Velg Depan Kiri']&#xd;
    /following::android.widget.RadioGroup[1]&#xd;
    //android.widget.RadioButton[contains(@text,'Tidak Ada')]&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
