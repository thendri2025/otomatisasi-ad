<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Tipe 2 Non Elektrik Spion Kiri</name>
   <tag></tag>
   <elementGuidId>447ca42a-c4a4-4495-8b81-f02a85d9f690</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Kaca Spion Kiri']&#xd;
    /following::android.widget.RadioGroup[2]&#xd;
    //android.widget.RadioButton[@text='Non Electric']&#xd;
&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
