<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Tipe 2 Non Elektrik Spion Kiri</name>
   <tag></tag>
   <elementGuidId>ea3075d6-80c9-456f-8304-6ce36965f36a</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[@class = 'android.widget.RadioButton' and (@text = 'Non Electric' or . = 'Non Electric') and @resource-id = 'com.indocyber.bcaf:id/nonElectricRadioButton'])[1]&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
