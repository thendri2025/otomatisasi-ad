<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Dop 1 Ada Velg blkg knn</name>
   <tag></tag>
   <elementGuidId>ad09026c-8193-424f-97f3-65200be9bc48</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Ban + Velg Belakang Kanan']&#xd;
    /following::android.widget.RadioGroup[3]&#xd;
    //android.widget.RadioButton[@text='Ada']&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
