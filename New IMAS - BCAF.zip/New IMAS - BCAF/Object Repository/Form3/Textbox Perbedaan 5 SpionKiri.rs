<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Textbox Perbedaan 5 SpionKiri</name>
   <tag></tag>
   <elementGuidId>34bc1ef6-ec26-423b-97d5-55b3f23cafdb</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[.//android.widget.TextView[@text='Kaca Spion Kiri']]//android.widget.EditText</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
