<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Textbox perbedaan 7 Velg dpn kr</name>
   <tag></tag>
   <elementGuidId>dc5f2efe-9727-487f-8922-e9628ad77eb4</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[.//android.widget.TextView[@text='Ban + Velg Depan Kiri']]//android.widget.EditText</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
