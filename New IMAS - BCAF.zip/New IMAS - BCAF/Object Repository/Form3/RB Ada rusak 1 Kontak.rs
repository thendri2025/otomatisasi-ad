<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>RB Ada rusak 1 Kontak</name>
   <tag></tag>
   <elementGuidId>0097b131-48ac-4a8e-97e5-c647eb92d085</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Kunci Kontak']/following::android.widget.RadioButton[@text='Ada - Rusak'][1]&#xd;
&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
