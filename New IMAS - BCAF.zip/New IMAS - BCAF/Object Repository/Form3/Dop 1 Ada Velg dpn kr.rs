<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Dop 1 Ada Velg dpn kr</name>
   <tag></tag>
   <elementGuidId>1605a735-a0fa-4d72-b60e-e9e4d3609122</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Ban + Velg Depan Kiri']&#xd;
    /following::android.widget.RadioGroup[3]&#xd;
    //android.widget.RadioButton[@text='Ada']&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
