<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Upload depan</name>
   <tag></tag>
   <elementGuidId>78cc9a34-e06b-4a38-8dba-23ba04f819fb</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[@class = 'android.widget.ImageView' and @resource-id = 'com.indocyber.bcaf:id/takePictureImageView' and (@text = '' or . = '')])[4]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
