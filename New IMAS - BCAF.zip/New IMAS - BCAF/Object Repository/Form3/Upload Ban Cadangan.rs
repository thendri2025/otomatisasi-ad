<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Upload Ban Cadangan</name>
   <tag></tag>
   <elementGuidId>da2e0772-5baf-4210-bb9b-2c88f2e8067a</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[.//android.widget.TextView[@text='Foto Ban Cadangan']]&#xd;
    //android.widget.FrameLayout[@resource-id='com.indocyber.bcaf:id/takePictureCardView']&#xd;
    //android.widget.ImageView&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
