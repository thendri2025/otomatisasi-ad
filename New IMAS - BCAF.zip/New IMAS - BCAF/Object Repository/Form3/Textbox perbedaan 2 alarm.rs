<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Textbox perbedaan 2 alarm</name>
   <tag></tag>
   <elementGuidId>17134996-f4b9-4792-a055-49662dd10d5b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[.//android.widget.TextView[@text='Alarm']]//android.widget.EditText&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
