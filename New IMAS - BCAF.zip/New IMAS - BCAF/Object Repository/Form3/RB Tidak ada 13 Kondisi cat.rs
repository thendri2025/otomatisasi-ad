<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>RB Tidak ada 13 Kondisi cat</name>
   <tag></tag>
   <elementGuidId>d7481bb4-5f00-4801-9a20-797c4d1b50ad</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text='Kondisi Cat Body']&#xd;
    /following::android.widget.RadioGroup[1]&#xd;
    //android.widget.RadioButton[contains(@text,'Tidak Ada')]&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
