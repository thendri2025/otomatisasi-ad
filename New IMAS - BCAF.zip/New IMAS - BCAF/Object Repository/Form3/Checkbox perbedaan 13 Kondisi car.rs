<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Checkbox perbedaan 13 Kondisi car</name>
   <tag></tag>
   <elementGuidId>af5e858c-dbf9-4c25-9506-37730a308e04</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[./android.widget.TextView[@text='Kondisi Cat Body']]//android.widget.CheckBox[@text='Ada Perbedaan']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
