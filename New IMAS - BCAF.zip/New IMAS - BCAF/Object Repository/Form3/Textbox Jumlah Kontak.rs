<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Textbox Jumlah Kontak</name>
   <tag></tag>
   <elementGuidId>8751e61a-bc88-43eb-9a1f-d8534239e643</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.EditText[@resource-id='com.indocyber.bcaf:id/valueTxtChild']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
