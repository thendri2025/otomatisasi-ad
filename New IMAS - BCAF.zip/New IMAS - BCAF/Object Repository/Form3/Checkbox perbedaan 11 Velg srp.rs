<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Checkbox perbedaan 11 Velg srp</name>
   <tag></tag>
   <elementGuidId>b997a415-1322-45f6-810d-9cdecda40178</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[./android.widget.TextView[@text='Ban + Velg Serep']]//android.widget.CheckBox[@text='Ada Perbedaan']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
