<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Checkbox Perbedaan 3 LampuDpn</name>
   <tag></tag>
   <elementGuidId>30255b5e-5011-40b5-86e1-b87c23f3d1af</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.LinearLayout[./android.widget.TextView[@text='Lampu Depan']]//android.widget.CheckBox[@text='Ada Perbedaan']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
