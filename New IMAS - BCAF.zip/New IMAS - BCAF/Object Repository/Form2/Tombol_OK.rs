<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Tombol_OK</name>
   <tag></tag>
   <elementGuidId>f1050a5d-bbf4-4d68-b43b-ed97c33a8fb0</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.ImageView[@resource-id='com.transsion.camera:id/shutter_button']&#xd;
</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
