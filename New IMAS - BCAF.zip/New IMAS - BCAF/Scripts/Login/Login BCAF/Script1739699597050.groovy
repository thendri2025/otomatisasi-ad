import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys


try {
	// Coba jalankan dari file APK (tanpa reinstall)
	Mobile.startExistingApplication('com.indocyber.bcaf')
	println("Aplikasi berhasil dijalankan dari package name.")
} catch (Exception e1) {
	println("Gagal menjalankan dari file APK. Coba jalankan aplikasi yang sudah terinstal...")
	try {
		// Jalankan aplikasi yang sudah terinstal via package name		
//		Mobile.startApplication(GlobalVariable.Path, false)
		Mobile.startExistingApplication(GlobalVariable.Path)
		println("Aplikasi berhasil dijalankan dari file APK.")		
	} catch (Exception e2) {
		println("Start gagal, coba ulang...")
//		Mobile.startApplication(GlobalVariable.Path, false) 
		Mobile.startExistingApplication(GlobalVariable.Path)
					}
}

Mobile.waitForElementPresent(findTestObject('Header Login Page'), 5)
Mobile.tap(findTestObject('Button Setting'), 5)
Mobile.setText(findTestObject('textBox Url'), GlobalVariable.URLDev, 0)
Mobile.tap(findTestObject('Button Test Connection'), 0)
Mobile.waitForElementPresent(findTestObject('Popup Success'), 0)
Mobile.tap(findTestObject('Popup Success'), 0)
Mobile.tap(findTestObject('Button Save Url'), 0)
Mobile.waitForElementPresent(findTestObject('Popup Success'), 5)
Mobile.tap(findTestObject('Popup Success'), 0)
Mobile.setText(findTestObject('TextBox Username'), GlobalVariable.Username, 0)
Mobile.setText(findTestObject('Textbox Password'), GlobalVariable.Password, 0)
Mobile.tap(findTestObject('Button Submit Login'), 5)
