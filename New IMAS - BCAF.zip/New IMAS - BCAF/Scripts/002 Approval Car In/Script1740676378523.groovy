import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper as MobileElementCommonHelper
import io.appium.java_client.MobileElement as MobileElement
import io.appium.java_client.TouchAction as TouchAction
import io.appium.java_client.android.AndroidDriver as AndroidDriver
import io.appium.java_client.touch.WaitOptions as WaitOptions
import io.appium.java_client.touch.offset.PointOption as PointOption
import java.time.Duration as Duration
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory as MobileDriverFactory

WebUI.callTestCase(findTestCase('Login/Login BCAF'), [:], FailureHandling.STOP_ON_FAILURE)
//Mobile.startApplication(GlobalVariable.Path, false)

Mobile.waitForElementPresent(findTestObject('Button Task'), 0)

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Button Task'), 0)

Mobile.waitForElementPresent(findTestObject('Approval/Approval Cari In'), 0)

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Approval/Approval Cari In'), 0)

Mobile.waitForElementPresent(findTestObject('Object Repository/Approval/Textbox Nopol'), 0)

Mobile.takeScreenshot()

Mobile.setText(findTestObject('Approval/Textbox Nopol'), GlobalVariable.NoPolisi, 0)

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

Mobile.tapAtPosition(980, 2180, FailureHandling.STOP_ON_FAILURE)

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

Mobile.takeScreenshot()

TestObject ChoosePool = new TestObject()

ChoosePool.addProperty('xpath', ConditionType.EQUALS, "//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/androidx.recyclerview.widget.RecyclerView[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[4]")

String verify = Mobile.getText(ChoosePool, 0)
	
println(verify)

if (verify == GlobalVariable.NoPolisi) {
	
	Mobile.tap(ChoosePool, 0)
	
}

Mobile.waitForElementNotPresent(findTestObject('Object Repository/Approval/Pop up download'), 60)

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Approval/Button Approve'), 0)

Mobile.waitForElementPresent(findTestObject('Object Repository/Approval/Textbox Remark'), 0)

Mobile.takeScreenshot()

Mobile.setText(findTestObject('Object Repository/Approval/Textbox Remark'), GlobalVariable.RemarkSubmit, 0)

Mobile.takeScreenshot()

//Mobile.tap(findTestObject('Object Repository/Approval/Button submit remark'), 0)