import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper as MobileElementCommonHelper
import io.appium.java_client.MobileElement as MobileElement
import io.appium.java_client.TouchAction as TouchAction
import io.appium.java_client.android.AndroidDriver as AndroidDriver
import io.appium.java_client.touch.WaitOptions as WaitOptions
import io.appium.java_client.touch.offset.PointOption as PointOption
import java.time.Duration as Duration
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory as MobileDriverFactory
import io.appium.java_client.android.nativekey.AndroidKey
import io.appium.java_client.android.nativekey.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date

def takeSS(String name = "SS") {
	String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date())
	String path = "Screenshots/${name}_${timestamp}.png"
	Mobile.takeScreenshot(path)
	println("[SS] Screenshot disimpan → ${path}")
}


def startApp() {
	println("[INFO] Mencoba menjalankan aplikasi...")
	
	try {
		Mobile.startExistingApplication('com.indocyber.bcaf')
		println("[INFO] App dijalankan dari package name.")
	} catch (Exception e1) {
		println("[WARN] Gagal start via package name, mencoba dari file APK...")

		try {
//			Mobile.startApplication(GlobalVariable.Path, false)
			Mobile.startExistingApplication(GlobalVariable.Path)
			println("[INFO] App berhasil dijalankan dari file APK.")
		} catch (Exception e2) {
			println("[ERROR] Gagal start app, mencoba reinstall...")
//			Mobile.startApplication(GlobalVariable.Path, true)
			Mobile.startExistingApplication(GlobalVariable.Path)
		}
	}
}

def tapAndWait(String objPath, int timeout = 3, boolean shot = false) {
	Mobile.waitForElementPresent(findTestObject(objPath), timeout)
	Mobile.tap(findTestObject(objPath), timeout)
	if (shot) Mobile.takeScreenshot()
}

def setInput(String objPath, String text, int timeout = 3, boolean shot = false) {
	Mobile.waitForElementPresent(findTestObject(objPath), timeout)
	Mobile.setText(findTestObject(objPath), text, timeout)
	if (shot) Mobile.takeScreenshot()
}

def handlePopupOk() {
	TestObject btnOkPopup = new TestObject('dynamicOkPopup')
	btnOkPopup.addProperty("class", ConditionType.EQUALS, "android.widget.TextView")
	btnOkPopup.addProperty("text", ConditionType.EQUALS, "OK")
	btnOkPopup.addProperty("resource-id", ConditionType.EQUALS, "com.indocyber.bcaf:id/okDialogButton")
	if (Mobile.waitForElementPresent(btnOkPopup, 5, FailureHandling.OPTIONAL)) {
		Mobile.tap(btnOkPopup, 0)
		println("Popup Info muncul → sudah tap OK")
	} else {
		println("Tidak ada popup Info")
	}
}

def handleLoginAgain() {
	TestObject notifLogin = new TestObject('notifLoginAgain')
	notifLogin.addProperty("resource-id", ConditionType.EQUALS, "com.indocyber.bcaf:id/txtNotifLogin")
	notifLogin.addProperty("text", ConditionType.CONTAINS, "Silakan tekan tombol Login lagi")
	if (Mobile.waitForElementPresent(notifLogin, 3, FailureHandling.OPTIONAL)) {
		println("[INFO] Notifikasi muncul → Silakan tekan tombol Login lagi")
		TestObject btnLoginAgain = new TestObject('btnLoginAgain')
		btnLoginAgain.addProperty("resource-id", ConditionType.EQUALS, "com.indocyber.bcaf:id/btnLogin")
		Mobile.tap(btnLoginAgain, 2)
		println("[INFO] Tombol LOGIN ditekan ulang.")
		Mobile.delay(1)
		return true
	}
	return false
}

//WebUI.callTestCase(findTestCase('Login/Login BCAF'), [:], FailureHandling.STOP_ON_FAILURE)
startApp()
tapAndWait('Header Login Page', 5)
tapAndWait('Button Setting')
setInput('textBox Url', GlobalVariable.URLDev)
tapAndWait('Button Test Connection')
tapAndWait('Popup Success')
tapAndWait('Button Save Url')
tapAndWait('Popup Success', 5)
setInput('TextBox Username', GlobalVariable.UsernameApproval)
setInput('Textbox Password', GlobalVariable.PasswordApproval)
tapAndWait('Button Submit Login', 5)
if (handleLoginAgain()) {
	println("[INFO] Login ulang berhasil dilakukan.")
}
println("[SUCCESS] Login & konfigurasi URL selesai.")
takeSS("After_Login")

//Mobile.startApplication(GlobalVariable.Path, false)
Mobile.waitForElementPresent(findTestObject('Button Task'), 0)
Mobile.tap(findTestObject('Button Task'), 0)
Mobile.waitForElementPresent(findTestObject('Approval/Approval Cari In'), 0)
Mobile.tap(findTestObject('Approval/Approval Cari In'), 0)
Mobile.waitForElementPresent(findTestObject('Object Repository/Approval/Textbox Nopol'), 0)
Mobile.setText(findTestObject('Approval/Textbox Nopol'), GlobalVariable.NoPolisiApproval, 0)
takeSS("After_Input_Nopol")
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)
AndroidDriver<?> driver = MobileDriverFactory.getDriver()
driver.pressKey(new KeyEvent(AndroidKey.ENTER))
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)
TestObject ChoosePool = new TestObject()
ChoosePool.addProperty('xpath', ConditionType.EQUALS, "//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/androidx.recyclerview.widget.RecyclerView[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[4]")
String verify = Mobile.getText(ChoosePool, 0)	
println(verify)
if (verify == GlobalVariable.NoPolisiApproval) {	
	Mobile.tap(ChoosePool, 0)	
}

handlePopupOk()
Mobile.waitForElementNotPresent(findTestObject('Object Repository/Approval/Pop up download'), 60)
try {
	Mobile.waitForElementNotPresent(findTestObject('Object Repository/Approval/Button Approve'), 10)
	Mobile.tap(findTestObject('Object Repository/Approval/Button Approve'), 5)
	println("[INFO] Berhasil Tap Approve")
}
catch (Exception e) {
	println("[WARN] Gagal tap Approve → cek popup error")	
	if (handlePopupOk()) {
		println("[INFO] Popup error tertangani. Flow dihentikan.")
		return
	} else {
		throw e
	}
}
handlePopupOk()
Mobile.waitForElementPresent(findTestObject('Object Repository/Approval/Textbox Remark'), 0)
Mobile.setText(findTestObject('Object Repository/Approval/Textbox Remark'), GlobalVariable.RemarkSubmit, 0)
takeSS("After_Input_Remark")
//sengaja di remarks agar tidak submit data dulu jika sudah yakin pakai data baru maka buka remarksnya
//Mobile.tap(findTestObject('Object Repository/Approval/Button submit remark'), 0)
takeSS("After_Submit_Remark")
