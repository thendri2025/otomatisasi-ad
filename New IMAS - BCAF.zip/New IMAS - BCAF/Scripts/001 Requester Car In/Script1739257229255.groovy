import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import java.util.Arrays
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.mobile.keyword.internal.MobileAbstractKeyword as MobileAbstractKeyword
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import com.kms.katalon.core.util.KeywordUtil
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper as MobileElementCommonHelper
import io.appium.java_client.MobileElement as MobileElement
import io.appium.java_client.android.nativekey.AndroidKey
import io.appium.java_client.android.nativekey.KeyEvent
import io.appium.java_client.AppiumDriver
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.interactions.PointerInput
import org.openqa.selenium.interactions.Sequence
import io.appium.java_client.TouchAction as TouchAction
import io.appium.java_client.android.AndroidDriver as AndroidDriver
import io.appium.java_client.touch.WaitOptions as WaitOptions
import io.appium.java_client.touch.offset.PointOption as PointOption
import java.time.Duration as Duration
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory as MobileDriverFactory
import java.text.SimpleDateFormat
import java.util.Date


public class SwipeHelper {	
	private static AndroidDriver getDriver() {
		return (AndroidDriver) MobileDriverFactory.getDriver()
	}

	static void swipeUp() {
		AndroidDriver driver = getDriver()
		int width = driver.manage().window().getSize().width
		int height = driver.manage().window().getSize().height
		int startX = width / 2
		int startY = (int) (height * 0.8)   // titik bawah
		int endY   = (int) (height * 0.2)   // titik atas
		performSwipe(driver, startX, startY, startX, endY)
	}

	static void swipeUp2() {
		AndroidDriver driver = getDriver()
		int width = driver.manage().window().getSize().width
		int height = driver.manage().window().getSize().height
		int startX = width / 2
		int startY = (int) (height * 0.8)   // titik bawah
		int endY   = (int) (height * 0.6)   // titik atas
		performSwipe(driver, startX, startY, startX, endY)
	}

	static void swipeDown() {
		AndroidDriver driver = getDriver()
		int width = driver.manage().window().getSize().width
		int height = driver.manage().window().getSize().height
		int startX = width / 2
		int startY = (int) (height * 0.2)   // titik atas
		int endY   = (int) (height * 0.8)   // titik bawah
		performSwipe(driver, startX, startY, startX, endY)
	}
	
	static void scrollToText(String text) {
		AndroidDriver driver = getDriver()
		try {
			driver.findElementByAndroidUIAutomator(
				'new UiScrollable(new UiSelector().scrollable(true))' +
				'.scrollIntoView(new UiSelector().text("' + text + '"))'
			)
		} catch (Exception e) {
			println "⚠️ Tidak menemukan teks: " + text
		}
	}

	private static void performSwipe(AndroidDriver driver, int startX, int startY, int endX, int endY) {
		PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger")
		Sequence swipe = new Sequence(finger, 1)
		swipe.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), startX, startY))
		swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
		swipe.addAction(finger.createPointerMove(Duration.ofMillis(800), PointerInput.Origin.viewport(), endX, endY))
		swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))
		driver.perform(Arrays.asList(swipe))
	}
}

def scroll(String dicari, String menuju) {
	if (Mobile.verifyElementNotVisible(findTestObject(dicari), 5, FailureHandling.OPTIONAL) == true) {
		Mobile.scrollToText(menuju)
	}
}

def scrollKoorY(int y1, int y2) {
	AndroidDriver<?> driver = MobileDriverFactory.getDriver()
	TouchAction action = new TouchAction(driver)
	action.press(PointOption.point(500, y1)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).moveTo(PointOption.point(
			500, y2)).release().perform()
}

def tipe(int type, String tipeA, String tipeB) {
	switch (type) {
		case 1:
			Mobile.tap(findTestObject(tipeA), 0)
			break
		case 2:
			Mobile.tap(findTestObject(tipeB), 0)
			break
	}
}

def setSliderPercent(TestObject slider, int percent) {
	AppiumDriver<?> driverApp = MobileDriverFactory.getDriver()
	// Tunggu sampai slider ada
	Mobile.waitForElementPresent(slider, 20)
	// Cari elemen slider
	MobileElement sliderElement = (MobileElement) MobileElementCommonHelper.findElement(slider, 20)	
	int startX = sliderElement.getLocation().getX()
	int elementWidth = sliderElement.getSize().getWidth()
	int yAxis = sliderElement.getLocation().getY() + (sliderElement.getSize().getHeight() / 2)
	int moveToX = startX + (elementWidth * percent / 100)
	PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger")
	Sequence swipe = new Sequence(finger, 1)
	swipe.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), startX, yAxis))
	swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	swipe.addAction(finger.createPointerMove(Duration.ofMillis(1000), PointerInput.Origin.viewport(), moveToX, yAxis))
	swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))
	driverApp.perform(Arrays.asList(swipe))
}

def handlePopupOk() {
	TestObject btnOkPopup = new TestObject('dynamicOkPopup')
	btnOkPopup.addProperty("class", ConditionType.EQUALS, "android.widget.TextView")
	btnOkPopup.addProperty("text", ConditionType.EQUALS, "OK")
	btnOkPopup.addProperty("resource-id", ConditionType.EQUALS, "com.indocyber.bcaf:id/okDialogButton")
	if (Mobile.waitForElementPresent(btnOkPopup, 5, FailureHandling.OPTIONAL)) {
		Mobile.tap(btnOkPopup, 0)
		println("Popup Info muncul → sudah tap OK")
	} else {
		println("Tidak ada popup Info")
	}
}

def adaPerubahan(boolean isChecked, String checkBox, String textBox, String isi) {
	if (isChecked) {
		Mobile.tap(findTestObject(checkBox), 0)
		Mobile.setText(findTestObject(textBox), isi, 0)
		Mobile.hideKeyboard()
	}
}

def takePhoto(String pathPhoto) {
	Mobile.waitForElementPresent(findTestObject(pathPhoto), 20)
	Mobile.tap(findTestObject(pathPhoto), 0)
	Mobile.delay(2)
	int deviceHeight = Mobile.getDeviceHeight()
	int deviceWidth = Mobile.getDeviceWidth()
	int x = deviceWidth / 2
	int y = deviceHeight * 90 / 100
	AppiumDriver<?> driver = MobileDriverFactory.getDriver()
	PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger")
	Sequence tap = new Sequence(finger, 1)
	tap.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), x, y))
	tap.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	tap.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))
	driver.perform(Arrays.asList(tap))
	Mobile.delay(3)
	if (Mobile.waitForElementPresent(findTestObject('Object Repository/Form2/Tombol_OK'), 10, FailureHandling.OPTIONAL)) {
		Mobile.tap(findTestObject('Object Repository/Form2/Tombol_OK'), 0)
		Mobile.delay(2)		
		TestObject tombolCentang = new TestObject("tombolCentangKamera")
		tombolCentang.addProperty("xpath", ConditionType.EQUALS, "//android.widget.ImageView[@resource-id='com.transsion.camera:id/btn_shutter_panel_camera_switcher']")		
		Mobile.waitForElementPresent(tombolCentang, 10)		
		Mobile.tap(tombolCentang, 0)
	} else {
		KeywordUtil.markFailed("Tombol OK tidak ditemukan setelah ambil foto")
	}
}

def inputNumber(String pathNumber, String isiNumber) {
	Mobile.tap(findTestObject(pathNumber), 0)
	for (int j = 0; j < isiNumber.length(); j++) {
		int digit = Character.getNumericValue(isiNumber.charAt(j))
		Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
		switch (digit) {
			case 1:
				Mobile.tapAtPosition(160, 1620)
				Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
				break
			case 2:
				Mobile.tapAtPosition(420, 1620)
				Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
				break
			case 3:
				Mobile.tapAtPosition(675, 1620)
				Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
				break
			case 4:
				Mobile.tapAtPosition(160, 1800)
				Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
				break
			case 5:
				Mobile.tapAtPosition(420, 1800)
				Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
				break
			case 6:
				Mobile.tapAtPosition(675, 1800)
				Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
				break
			case 7:
				Mobile.tapAtPosition(160, 1980)
				Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
				break
			case 8:
				Mobile.tapAtPosition(420, 1980)
				Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
				break
			case 9:
				Mobile.tapAtPosition(675, 1980)
				Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
				break
			case 0:
				Mobile.tapAtPosition(420, 2160)
				Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
				break
		}
	}	
	Mobile.hideKeyboard()
}

def kondisiBarang(int radioButton, String tipe1, String tipe2, String tipe3) {
	String selectedObjPath = ""
	switch (radioButton) {
		case 1:
			selectedObjPath = tipe1
			break
		case 2:
			selectedObjPath = tipe2
			break
		case 3:
			selectedObjPath = tipe3
			break
		default:
			KeywordUtil.logInfo("Radio button value tidak valid: " + radioButton)
			return
	}

	TestObject obj = findTestObject(selectedObjPath)
	if (Mobile.waitForElementPresent(obj, 10, FailureHandling.OPTIONAL)) {
		Mobile.tap(obj, 0)
		Mobile.delay(2, FailureHandling.CONTINUE_ON_FAILURE)
	} else {
		KeywordUtil.markFailed("Element tidak ditemukan: " + selectedObjPath)
	}
}

def datePicker(String tgl, String bln, String thn) {
	while (true) {
		println(tgl)
		println(bln)
		println(thn)
		TestObject kata = new TestObject().addProperty('xpath', ConditionType.EQUALS, '//hierarchy/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.DatePicker[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[2]')
		String cekData = Mobile.getText(kata, 0)
		println(cekData)
		if (cekData.contains(bln)) {
			break
		} else {
			Mobile.tap(findTestObject('Prev Month'), 0)
			TestObject tanggal = new TestObject().addProperty('xpath', ConditionType.EQUALS, ('//hierarchy/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.DatePicker[1]/android.widget.LinearLayout[1]/android.widget.ScrollView[1]/android.widget.ViewAnimator[1]/android.view.ViewGroup[1]/com.android.internal.widget.ViewPager[1]/android.view.View[1]/android.view.View[contains(@text, "' +
				tgl) + '")]')
			Mobile.tap(tanggal, 0)
		}
	}
	TestObject DrpDwnTahun = new TestObject().addProperty('xpath', ConditionType.EQUALS, '//hierarchy/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.DatePicker[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]')
	Mobile.tap(DrpDwnTahun, 0)
	TestObject Tahun = new TestObject().addProperty('xpath', ConditionType.EQUALS, ('//hierarchy/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.DatePicker[1]/android.widget.LinearLayout[1]/android.widget.ScrollView[1]/android.widget.ViewAnimator[1]/android.widget.ListView[1]/android.widget.TextView[contains(@text, "' +
		thn) + '")]')
	Mobile.tap(Tahun, 0)
	Mobile.tap(findTestObject('Object Repository/Submit Datepicker'), 0)
	handlePopupOk()
}

def handlePopupMengerti() {
    TestObject btnMengertiPopup = new TestObject('dynamicMengertiPopup')
    btnMengertiPopup.addProperty("class", ConditionType.EQUALS, "android.widget.Button")
    btnMengertiPopup.addProperty("text", ConditionType.EQUALS, "MENGERTI")
    btnMengertiPopup.addProperty("resource-id", ConditionType.EQUALS, "android:id/button1")    
    if (Mobile.waitForElementPresent(btnMengertiPopup, 5, FailureHandling.OPTIONAL)) {
		Mobile.tap(btnMengertiPopup, 0)
        println("Popup 'MENGERTI' muncul → sudah tap MENGERTI")
    } else {
        // Tidak perlu error di sini, karena kemunculannya opsional
        println("Tidak ada popup 'MENGERTI'")
    }
}

def takePhoto2(String pathPhoto) {
	// 1. Tunggu dan Tap Tombol Upload di Aplikasi Utama
	Mobile.waitForElementPresent(findTestObject(pathPhoto), 20)
	Mobile.tap(findTestObject(pathPhoto), 0) // <-- Melakukan tap pada tombol upload (e.g., 'Upload Mesin kendaraan')
	Mobile.delay(4)	
	// 2. TANGANI POP-UP "MENGERTI" (Jika muncul segera setelah tap tombol upload)
	handlePopupMengerti() // <-- Panggil fungsi untuk klik "MENGERTI" di sini
	handlePopupOk()
	Mobile.delay(2)
	
	// 1. Tunggu dan Tap Tombol Upload di Aplikasi Utama
	Mobile.waitForElementPresent(findTestObject(pathPhoto), 20)
	Mobile.tap(findTestObject(pathPhoto), 0) // <-- Melakukan tap pada tombol upload (e.g., 'Upload Mesin kendaraan')
	
	// 3. Masuk ke Aplikasi Kamera dan Klik Shutter
	int deviceHeight = Mobile.getDeviceHeight()
	int deviceWidth = Mobile.getDeviceWidth()
	int x = deviceWidth / 2
	int y = deviceHeight * 90 / 100 // Koordinat untuk tombol shutter
	
	AppiumDriver<?> driver = MobileDriverFactory.getDriver()
	PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger")
	Sequence tap = new Sequence(finger, 1)
	tap.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), x, y))
	tap.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	tap.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))
	driver.perform(Arrays.asList(tap)) // KLIK SHUTTER KAMERA
	Mobile.delay(3)
	
	// 4. TANGANI POP-UP KONFIRMASI (Misalnya 'Tombol_OK' jika muncul setelah shutter)
	if (Mobile.waitForElementPresent(findTestObject('Object Repository/Form2/Tombol_OK'), 10, FailureHandling.OPTIONAL)) {
		Mobile.tap(findTestObject('Object Repository/Form2/Tombol_OK'), 0)
		Mobile.delay(2)
		
		// 5. Klik Tombol Centang/Accept Foto
		TestObject tombolCentang = new TestObject("tombolCentangKamera")
		// Asumsi resource-id ini adalah tombol centang setelah mengambil foto
		tombolCentang.addProperty("xpath", ConditionType.EQUALS, "//android.widget.ImageView[@resource-id='com.transsion.camera:id/btn_shutter_panel_camera_switcher']")
		Mobile.waitForElementPresent(tombolCentang, 10)
		Mobile.tap(tombolCentang, 0)
	} else {
		// Jika Tombol_OK tidak ditemukan, coba klik tombol centang langsung (tergantung alur kamera)
		TestObject tombolCentang = new TestObject("tombolCentangKamera")
		tombolCentang.addProperty("xpath", ConditionType.EQUALS, "//android.widget.ImageView[@resource-id='com.transsion.camera:id/btn_shutter_panel_camera_switcher']")
		
		if (Mobile.waitForElementPresent(tombolCentang, 5, FailureHandling.OPTIONAL)) {
			Mobile.tap(tombolCentang, 0)
		} else {
			KeywordUtil.markFailed("Tombol OK atau Tombol Centang tidak ditemukan setelah ambil foto")
		}
	}
}

def takePhoto3(String pathPhoto, Map params = [:]) {
	Mobile.waitForElementPresent(findTestObject(pathPhoto, params), 20)
	Mobile.tap(findTestObject(pathPhoto, params), 0)
	Mobile.delay(2)

	int deviceHeight = Mobile.getDeviceHeight()
	int deviceWidth = Mobile.getDeviceWidth()
	int x = deviceWidth / 2
	int y = deviceHeight * 90 / 100

	AppiumDriver<?> driver = MobileDriverFactory.getDriver()
	PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger")
	Sequence tap = new Sequence(finger, 1)
	tap.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), x, y))
	tap.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	tap.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))
	driver.perform(Arrays.asList(tap))

	Mobile.delay(3)

	if (Mobile.waitForElementPresent(findTestObject('Object Repository/Form2/Tombol_OK'), 10, FailureHandling.OPTIONAL)) {
		Mobile.tap(findTestObject('Object Repository/Form2/Tombol_OK'), 0)
		Mobile.delay(2)

		TestObject tombolCentang = new TestObject("tombolCentangKamera")
		tombolCentang.addProperty("xpath", ConditionType.EQUALS,
				"//android.widget.ImageView[@resource-id='com.transsion.camera:id/btn_shutter_panel_camera_switcher']")

		Mobile.waitForElementPresent(tombolCentang, 10)
		Mobile.tap(tombolCentang, 0)
	} else {
		KeywordUtil.markFailed("Tombol OK tidak ditemukan setelah ambil foto")
	}
}

def takeSS(String name = "SS") {
	String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date())
	String path = "Screenshots/${name}_${timestamp}.png"
	Mobile.takeScreenshot(path)
	println("[SS] Screenshot disimpan → ${path}")
}


WebUI.callTestCase(findTestCase('Login/Login BCAF'), [:], FailureHandling.STOP_ON_FAILURE)
AndroidDriver<?> driver = (AndroidDriver<?>) MobileDriverFactory.getDriver()
Mobile.waitForElementPresent(findTestObject('Button Task'), 20)
Mobile.tap(findTestObject('Button Task'), 10)
Mobile.waitForElementPresent(findTestObject('Button CarIn'), 10)
Mobile.tap(findTestObject('Button CarIn'), 0)
Mobile.waitForElementPresent(findTestObject('Dropdown Tipe Transaksi'), 0)
Mobile.verifyElementExist(findTestObject('Dropdown Tipe Transaksi'), 10)
Mobile.tap(findTestObject('Dropdown Tipe Transaksi'), 0)
Mobile.tap(findTestObject('List Dropdown - Titipan Konsumen'), 0)
Mobile.waitForElementPresent(findTestObject('TextBox No Polisi'), 0)
Mobile.setText(findTestObject('TextBox No Polisi'), GlobalVariable.NoPolisi, 0 )
takeSS("Input NoPol")
Mobile.hideKeyboard()
Mobile.tap(findTestObject('Button submit pencarian CarIn'), 0)
Mobile.waitForElementPresent(findTestObject('Verify No Polisi'), 5)
TestObject DataCarIn = new TestObject().addProperty('xpath', ConditionType.EQUALS,
	"//androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[1]")
TestObject VerifyNopol = new TestObject()
VerifyNopol.addProperty("resource-id", ConditionType.EQUALS, "com.indocyber.bcaf:id/valNoPolisi")
Mobile.waitForElementPresent(VerifyNopol, 10)
String Nopol = Mobile.getText(VerifyNopol, 0)
println("Nopol: " + Nopol)

if (GlobalVariable.NoPolisi.contains(Nopol)) {
    TestObject DetailData = new TestObject().addProperty('xpath', ConditionType.EQUALS, DataCarIn.findPropertyValue('xpath') + 
        '/android.widget.ImageView[1]')
    Mobile.tap(DataCarIn, 0)
} else {
    KeywordUtil.markFailed('Object yang dicari tidak sesuai.')
}
Mobile.waitForElementPresent(findTestObject('NoBAST'), 0 )
Mobile.delay(3)
Mobile.setText(findTestObject('NoBAST'), GlobalVariable.NoBAST, 0 )
Mobile.hideKeyboard()
Mobile.tap(findTestObject('Nama_Pool'), 0 )

int i = 1
while (true) {
    TestObject ChoosePool = new TestObject()
    ChoosePool.addProperty('xpath', ConditionType.EQUALS, "//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.view.ViewGroup[1]/androidx.recyclerview.widget.RecyclerView[1]/android.widget.LinearLayout[$i]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    String verify = Mobile.getText(ChoosePool, 0)
    println(verify)
    if (verify == GlobalVariable.Pool) {
        Mobile.takeScreenshot()
        Mobile.tap(ChoosePool, 0)
        break //4
    } else {
		SwipeHelper.swipeUp()		
    }
}
Mobile.delay(3)
Mobile.waitForElementPresent(findTestObject('TanggalTerimaKonsumen'), 0 )
Mobile.tap(findTestObject('TanggalTerimaKonsumen'), 0 )
datePicker(GlobalVariable.TanggalKonsumen, GlobalVariable.BulanKonsumen, GlobalVariable.TahunKonsumen)
Mobile.waitForElementPresent(findTestObject('TanggalTerimaPool'), 0 )
Mobile.tap(findTestObject('TanggalTerimaPool'), 0 )
datePicker(GlobalVariable.TanggalPool, GlobalVariable.BulanPool, GlobalVariable.TahunPool)
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)
takeSS("Tgl Terima Konsumen")

// scrollToEnd
SwipeHelper.swipeUp()
SwipeHelper.swipeUp()

// Klik field kota
Mobile.waitForElementPresent(findTestObject('Pencarian kota Kendaraan'), 30)
Mobile.tap(findTestObject("Pencarian kota Kendaraan"), 10)
TestObject searchField = new TestObject("dynamicSearch")
searchField.addProperty("xpath", ConditionType.EQUALS,
	"//*[@class='android.widget.EditText' and @resource-id='com.indocyber.bcaf:id/searchEditText']")
Mobile.waitForElementPresent(searchField, 20)
Mobile.tap(searchField, 10)
Mobile.setText(searchField, GlobalVariable.KotaKendaraan, 0)
Mobile.hideKeyboard()
MobileDriverFactory.getDriver().pressKey(new KeyEvent(AndroidKey.ENTER))
Mobile.delay(3)

boolean found = false
int z = 1
String kota = GlobalVariable.KotaKendaraan.trim()
while (!found) {
	TestObject kotaOption = new TestObject("dynamicKota" + z)
	kotaOption.addProperty("xpath", ConditionType.EQUALS,
		"//androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[" + z + "]/android.widget.LinearLayout/android.widget.TextView")
	try {
		String verify = Mobile.getText(kotaOption, 3)
		println("Ditemukan: " + verify)
		if (verify.equalsIgnoreCase(kota)) {
			Mobile.takeScreenshot()
			Mobile.tap(kotaOption, 10)
			println("Berhasil memilih kota: " + verify)
			found = true
		} else {
			SwipeHelper.swipeUp()
		}
	} catch (Exception e) {
		SwipeHelper.swipeUp()
	}
	z++
}
Mobile.hideKeyboard()
takeSS("Kota Kendaraan")
// scrollToEnd
SwipeHelper.swipeUp()
SwipeHelper.swipeUp()

// Step 11 - Set lokasi kendaraan
Mobile.setText(findTestObject('LokasiKendaraanDiAmbil'), GlobalVariable.Lokasikendaraan, 0)
Mobile.hideKeyboard()
// Step 12 - Input kilometer
Mobile.waitForElementPresent(findTestObject('Object Repository/KM'), 20)
Mobile.tap(findTestObject("Object Repository/KM"), 10)
Mobile.clearText(findTestObject("Object Repository/KM"), 0)
driver.getKeyboard().pressKey(GlobalVariable.Kilometer.toString())
Mobile.hideKeyboard()
int targetPercent = GlobalVariable.MeterBensin
setSliderPercent(findTestObject('Object Repository/MeterBensin'), targetPercent)
Mobile.delay(2)
Mobile.takeScreenshot()
Mobile.tap(findTestObject('Object Repository/Button Next Form (1)'), 0 )

//Lanjut Form2
Mobile.waitForElementPresent(findTestObject('Form2/Ada baik 1'), 0)

//STNK 5 Tahun
adaPerubahan(GlobalVariable.STNK5thn, 'Object Repository/Form2/Checkbox Ada perbedaan 1', 'Object Repository/Form2/Textbox STNK 5thn', 
    GlobalVariable.Perbedaan5thn 
    )
kondisiBarang(GlobalVariable.RBSTNK5thn, 'Object Repository/Form2/Ada baik 1', 'Object Repository/Form2/Ada rusak 1', 'Object Repository/Form2/Tidak ada 1' 
    )
if ((GlobalVariable.RBSTNK5thn == 1) || (GlobalVariable.RBSTNK5thn == 2)) {
    Mobile.tap(findTestObject('Object Repository/Form2/Datepicker STNK5thn'), 0)
    datePicker(GlobalVariable.Tanggal5thn, GlobalVariable.Bulan5thn, GlobalVariable.Tahun5thn)
	Mobile.delay(2)
	Mobile.waitForElementPresent(findTestObject('Object Repository/Form2/Upload STNK5thn'), 20)	
	takePhoto('Object Repository/Form2/Upload STNK5thn' 
        )
}
SwipeHelper.swipeUp()
//STNK 1 Tahun
adaPerubahan(GlobalVariable.STNK1thn, 'Object Repository/Form2/Checkbox ada perbedaan 2', 'Object Repository/Form2/Textbox STNK 1thn', 
    GlobalVariable.Perbedaan1thn )
kondisiBarang(GlobalVariable.RBSTNK1thn, 'Object Repository/Form2/Ada baik 2', 'Object Repository/Form2/Ada rusak 2', 'Object Repository/Form2/Tidak ada 2' )
SwipeHelper.swipeUp()
if ((GlobalVariable.RBSTNK1thn == 1) || (GlobalVariable.RBSTNK1thn == 2)) {
    Mobile.tap(findTestObject('Object Repository/Form2/Datepicker STNK1thn'), 0)
    datePicker(GlobalVariable.Tanggal1thn, GlobalVariable.Bulan1thn, GlobalVariable.Tahun1thn)
	Mobile.waitForElementPresent(findTestObject('Object Repository/Form2/Textbox Pajak 1thn'), 20)
	Mobile.tap(findTestObject("Object Repository/Form2/Textbox Pajak 1thn"), 10)
	Mobile.clearText(findTestObject("Object Repository/Form2/Textbox Pajak 1thn"), 0)
	driver.getKeyboard().pressKey(GlobalVariable.Pajak1Tahun.toString())
	Mobile.hideKeyboard()
	SwipeHelper.swipeUp()
    takePhoto('Object Repository/Form2/Upload STNK1thn' 
        )
}

//Buku KIR
//Mobile.scrollToText('Buku KIR' )
SwipeHelper.swipeUp()
adaPerubahan(GlobalVariable.KIR, 'Object Repository/Form2/Checkbox ada perbedaan 3', 'Object Repository/Form2/Textbox KIR', 
    GlobalVariable.PerbedaanKIR )
kondisiBarang(GlobalVariable.RBKIR, 'Object Repository/Form2/Ada baik 3', 'Object Repository/Form2/Ada rusak 3', 'Object Repository/Form2/Tidak ada 3')
SwipeHelper.swipeUp()
if ((GlobalVariable.RBKIR == 1) || (GlobalVariable.RBKIR == 2)) {
    Mobile.tap(findTestObject('Object Repository/Form2/Datepicker KIR'), 0)
    datePicker(GlobalVariable.TanggalKIR, GlobalVariable.BulanKIR, GlobalVariable.TahunKIR)
    SwipeHelper.swipeUp()
    takePhoto('Object Repository/Form2/Upload KIR')
    SwipeHelper.swipeUp()
}

//Buku Manual or Service
adaPerubahan(GlobalVariable.ManualService, 'Object Repository/Form2/Checkbox ada perbedaan 4', 'Object Repository/Form2/TextBox Manual service', 
    GlobalVariable.PerbedaanManualService )
kondisiBarang(GlobalVariable.RBManualService, 'Object Repository/Form2/Ada baik 4', 'Object Repository/Form2/Ada rusak 4', 
    'Object Repository/Form2/Tidak ada 4' )
handlePopupOk()	
takeSS("Form 2")
Mobile.tap(findTestObject('Object Repository/Button next form 2'), 0 )
handlePopupOk()
		
//Form ke-3
Mobile.waitForElementPresent(findTestObject('Object Repository/Form3/Button Exterior'), 0)
Mobile.tap(findTestObject('Object Repository/Form3/Button Exterior'), 0 )
takePhoto('Object Repository/Form3/Upload Ban Cadangan' )
takePhoto('Object Repository/Form3/Upload Ban Digunakan' )
takePhoto('Object Repository/Form3/Upload belakang' )
takePhoto('Object Repository/Form3/Upload depan' )
SwipeHelper.swipeUp()
takePhoto('Object Repository/Form3/Upload Samping kanan' )
takePhoto('Object Repository/Form3/Upload samping kiri' )
Mobile.takeScreenshot()
Mobile.tap(findTestObject('Object Repository/Form3/Button save eksterior'), 0 )
Mobile.waitForElementPresent(findTestObject('Popup Success'), 0)
Mobile.tap(findTestObject('Popup Success'), 0)
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Kunci Kontak
adaPerubahan(GlobalVariable.ChkboxKontak, 'Object Repository/Form3/Checkbox perbedaan 1 Kontak', 'Object Repository/Form3/Textbox Perbedaan 1 Kontak', 
    GlobalVariable.PerbedaanKontak )
kondisiBarang(GlobalVariable.RBKunciKontak, 'Object Repository/Form3/RB Ada baik 1 Kontak', 'Object Repository/Form3/RB Ada rusak 1 Kontak', 
    'Object Repository/Form3/RB Tidak ada 1 Kontak' )
if ((GlobalVariable.RBKunciKontak == 1) || (GlobalVariable.RBKunciKontak == 2)) {
	Mobile.waitForElementPresent(findTestObject('Object Repository/Form3/Textbox Jumlah Kontak'), 20)
	Mobile.tap(findTestObject("Object Repository/Form3/Textbox Jumlah Kontak"), 10)
	Mobile.clearText(findTestObject("Object Repository/Form3/Textbox Jumlah Kontak"), 0)
	driver.getKeyboard().pressKey(GlobalVariable.JumlahKontak.toString())
	Mobile.hideKeyboard()
	takePhoto('Object Repository/Form3/Upload kontak')
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Alarm
adaPerubahan(GlobalVariable.ChkboxAlarm, 'Object Repository/Form3/Checkbox pebedaan 2 Alarm', 'Object Repository/Form3/Textbox perbedaan 2 alarm', 
    GlobalVariable.PerbedaanAlarm)
kondisiBarang(GlobalVariable.RBAlarm, 'Object Repository/Form3/RB Ada baik 2 Alarm', 'Object Repository/Form3/RB Ada rusak 2 alarm', 
    'Object Repository/Form3/RB Tidak ada 2 Alarm')
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)
SwipeHelper.swipeUp2()

//Lampu Depan
adaPerubahan(GlobalVariable.ChkboxLampuDpn, 'Object Repository/Form3/Checkbox Perbedaan 3 LampuDpn', 'Object Repository/Form3/TextBoxt Perbedaan 3 LampuDpn', 
    GlobalVariable.PerbedaanLampuDpn)
kondisiBarang(GlobalVariable.RBLampuDpn, 'Object Repository/Form3/RB Ada baik 3 LampuDPn', 'Object Repository/Form3/RB Ada Rusak 3 LampuDPn', 
    'Object Repository/Form3/RB Tidak ada 3 LampuDpn')
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)
SwipeHelper.swipeUp2()

//Wiper
adaPerubahan(GlobalVariable.ChkboxWiper, 'Object Repository/Form3/Checkbox perbedaan 4 Wiper', 'Object Repository/Form3/Textbox Perbedaan 4 Wiper', 
    GlobalVariable.PerbedaanWiper)
kondisiBarang(GlobalVariable.RBWiper, 'Object Repository/Form3/RB ada baik 4 WIper', 'Object Repository/Form3/RB ada rusak 4 wiper', 
    'Object Repository/Form3/RB tidak ada 4 wiper')
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)
SwipeHelper.swipeUp2()

//Kaca Spion Kiri
adaPerubahan(GlobalVariable.ChkboxSpionKr, 'Object Repository/Form3/Checkbox Perbedaan 5 Spion Kiri', 'Object Repository/Form3/Textbox Perbedaan 5 SpionKiri', 
    GlobalVariable.PerbedaanSpionKr)
kondisiBarang(GlobalVariable.RBSpionKr, 'Object Repository/Form3/RB Ada baik 5 Spion Kiri', 'Object Repository/Form3/RB Ada rusak 5 Spion Kiri', 
    'Object Repository/Form3/RB Tidak ada 5 Spion Kiri')
if ((GlobalVariable.RBSpionKr == 1) || (GlobalVariable.RBSpionKr == 2)) {
    tipe(GlobalVariable.RBTipeSpionKr, 'Object Repository/Form3/Tipe 1 Elektrik Spion Kiri', 'Object Repository/Form3/Tipe 2 Non Elektrik Spion Kiri')
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Spion Kanan
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxSpionKnn, 'Object Repository/Form3/Checkbox Perbedaan 6 SpionKanan', 'Object Repository/Form3/Textbox perbedaan 6 Spion kanan', 
    GlobalVariable.PerbedaanSpionKnn)
kondisiBarang(GlobalVariable.RBSpionKnn, 'Object Repository/Form3/RB Ada baik 6 Spion Kanan', 'Object Repository/Form3/RB Ada rusak 6 Spion kanan', 
    'Object Repository/Form3/RB Tidak Ada 6 Spion kanan')
if ((GlobalVariable.RBSpionKnn == 1) || (GlobalVariable.RBSpionKnn == 2)) {
    tipe(GlobalVariable.RBTipeSpionKnn, 'Object Repository/Form3/Tipe 1 Elektrik Spion Kanan', 'Object Repository/Form3/Tipe 2 Non Elektrik Spion Kanan')
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)
SwipeHelper.swipeUp2()

//Velg depan kiri
adaPerubahan(GlobalVariable.ChkboxVelgDpnKr, 'Object Repository/Form3/Checkbox perbedaan 7 Velg dpn kiri', 'Object Repository/Form3/Textbox perbedaan 7 Velg dpn kr', 
    GlobalVariable.PerbedaanVelgDpnKr)
kondisiBarang(GlobalVariable.RBVelgDpnKr, 'Object Repository/Form3/RB Ada Baik 7 Velg dpn kiri', 'Object Repository/Form3/RB Ada rusak 7 velg dpn kr', 
    'Object Repository/Form3/RB TIdak ada 7 Velg dpn kr')
if ((GlobalVariable.RBVelgDpnKr == 1) || (GlobalVariable.RBVelgDpnKr == 2)) {
    tipe(GlobalVariable.RBTipeVelgDpnKr, 'Object Repository/Form3/Tipe 1 Racing Velg dpn kr', 'Object Repository/Form3/Tipe 2 Kaleng Velg dpn Kiri')
    tipe(GlobalVariable.RBDopVelgDpnKr, 'Object Repository/Form3/Dop 1 Ada Velg dpn kr', 'Object Repository/Form3/Dop 2 Tidak ada Velg dpn kr')
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Velg Dpn Kanan
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxVelgDpnKnn, 'Object Repository/Form3/Checkbox perbedaan 8 Velp dpn knn', 'Object Repository/Form3/Textbox perbedaan 8 Velg dpn knn', 
    GlobalVariable.PerbedaanVelgDpnKanan)
kondisiBarang(GlobalVariable.RBVelgDpnKnn, 'Object Repository/Form3/RB Ada baik 8 Velg dpn knn', 'Object Repository/Form3/RB Ada rusak 8 Velg dpn knn', 
    'Object Repository/Form3/RB Tidak ada 8 Velg dpn knn')
Mobile.takeScreenshot()
if ((GlobalVariable.RBVelgDpnKnn == 1) || (GlobalVariable.RBVelgDpnKnn == 2)) {
    tipe(GlobalVariable.RBTipeVelgDpnKnn, 'Object Repository/Form3/Tipe 1 Racing Velg dpn knn', 'Object Repository/Form3/Tipe 2 Kaleng Velg dpn knn')
    tipe(GlobalVariable.RBDopVelgDpnKnn, 'Object Repository/Form3/Dop 1 Ada Velg dpn knn', 'Object Repository/Form3/Dop 2 Tidak velg dpn knn')
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)
SwipeHelper.swipeUp2()

//velg Belakang Kanan
adaPerubahan(GlobalVariable.ChkboxVelgBlkgKnn, 'Object Repository/Form3/Checkbox perbedaan 9 Velg blkg knn', 'Object Repository/Form3/Textbox perbedaan 9 Velg blkg knn', 
    GlobalVariable.PerbedaanVelgBlkgKanan)
kondisiBarang(GlobalVariable.RBVelgBlkgKnn, 'Object Repository/Form3/RB Ada baik 9 velg blkg knn', 'Object Repository/Form3/RB Ada rusak 9 velg blkg knn', 
    'Object Repository/Form3/RB Tidak ada 9 Velg blkg knn')
Mobile.takeScreenshot()
if ((GlobalVariable.RBVelgBlkgKnn == 1) || (GlobalVariable.RBVelgBlkgKnn == 2)) {
    tipe(GlobalVariable.RBTipeVelgBlkgKnn, 'Object Repository/Form3/Tipe 1 Racing Velg blkg knn', 'Object Repository/Form3/Tipe 2 Kaleng Velg blkg knn')
    tipe(GlobalVariable.RBDopVelgBlkgKnn, 'Object Repository/Form3/Dop 1 Ada Velg blkg knn', 'Object Repository/Form3/Dop 2 Tida velg blkg kn')
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Velg Blkg Kiri
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxVelgBlkgKr, 'Object Repository/Form3/Checkbox perbedaan 10 Velg blkg kr', 'Object Repository/Form3/Textbox perbedaan 10 Velg blkg kr', 
    GlobalVariable.PerbedaanVelgBlkgKr)
kondisiBarang(GlobalVariable.RBVelgBlkgKr, 'Object Repository/Form3/RB Ada baik 10 Velg Blkg kr', 'Object Repository/Form3/RB Ada rusak 10 Velg blkg kr', 
    'Object Repository/Form3/RB Tidak ada 10 velg blkg kr')
if ((GlobalVariable.RBVelgBlkgKr == 1) || (GlobalVariable.RBVelgBlkgKr == 2)) {
    tipe(GlobalVariable.RBTipeVelgBlkgKr, 'Object Repository/Form3/Tipe 1 Racing velg blkg kr', 'Object Repository/Form3/Tipe 2 Kaleng Velg blkg kr')
    tipe(GlobalVariable.RBDopVelgBlkgKr, 'Object Repository/Form3/Dop 1 Ada velg blkg kr', 'Object Repository/Form3/Dop 2 Tidak Velg blkg kr')
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//velg Serep
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxVelgSrp, 'Object Repository/Form3/Checkbox perbedaan 11 Velg srp', 'Object Repository/Form3/Textbox perbedaan 11 velg srp', 
    GlobalVariable.PerbedaanVelgSrp)
kondisiBarang(GlobalVariable.RBVelgSrp, 'Object Repository/Form3/RB Ada baik 11 Velg srp', 'Object Repository/Form3/RB Ada rusak 11 Velg srp', 
    'Object Repository/Form3/RB Tidak ada 11 Velg srp')
if ((GlobalVariable.RBVelgSrp == 1) || (GlobalVariable.RBVelgSrp == 2)) {
    tipe(GlobalVariable.RBTipeVelgSrp, 'Object Repository/Form3/Tipe 1 Racing Velg srp', 'Object Repository/Form3/Tipe 2 Kaleng Velg spr')
    tipe(GlobalVariable.RBDopVelgSrp, 'Object Repository/Form3/Dop 1 ada Velg srp', 'Object Repository/Form3/Dop 2 tidak Velg srp')
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Lampu Belakang
SwipeHelper.swipeUp()
adaPerubahan(GlobalVariable.ChkboxLampublkg, 'Object Repository/Form3/Checkbox perbedaan 12 Lampu blkg', 'Object Repository/Form3/Textbox perbedaan 12 Lampu blkg', 
    GlobalVariable.PerbedaanLampublg)
kondisiBarang(GlobalVariable.RBLampuBlkg, 'Object Repository/Form3/RB ada baik 12 lampu blkg', 'Object Repository/Form3/RB Ada rusak 12 Lampu blkg', 
    'Object Repository/Form3/RB tidak ada 12 lampu blkg')

//Kondisi Cat
adaPerubahan(GlobalVariable.ChkboxKondisiCat, 'Object Repository/Form3/Checkbox perbedaan 13 Kondisi car', 'Object Repository/Form3/Textbox perbedaan 13 Kondisi cat', 
    GlobalVariable.PerbedaanKondisiCat)
kondisiBarang(GlobalVariable.RBKondisiCat, 'Object Repository/Form3/RB Ada baik 13 Kondisi cat', 'Object Repository/Form3/RB Ada rusak 13 Kondisi Cat', 
    'Object Repository/Form3/RB Tidak ada 13 Kondisi cat')
takeSS("Form 3")
Mobile.delay(1)
Mobile.tap(findTestObject('Object Repository/Button next form 2'), 0)

//Next form 4
Mobile.waitForElementPresent(findTestObject('Object Repository/Form4/Button Interior'), 0)
Mobile.tap(findTestObject('Object Repository/Form4/Button Interior'), 0)
takePhoto('Object Repository/Form4/Upload Interior Belakang')
takePhoto('Object Repository/Form4/Upload Interior Depan')
takePhoto('Object Repository/Form4/Upload Km Kendaraan')
Mobile.takeScreenshot()
Mobile.tap(findTestObject('Object Repository/Form3/Button save eksterior'), 0)
Mobile.waitForElementPresent(findTestObject('Object Repository/Popup Success'), 0)
Mobile.takeScreenshot()
Mobile.tap(findTestObject('Object Repository/Popup Success'), 0)

//Radio
adaPerubahan(GlobalVariable.ChkboxRadio, 'Object Repository/Form4/Checkbox Perbedaan 1 Radio', 'Object Repository/Form4/Textbox Perbedaan 1 radio', 
    GlobalVariable.PerbedaanRadio)
kondisiBarang(GlobalVariable.RBRadio, 'Object Repository/Form4/RB Ada baik 1 Radio', 'Object Repository/Form4/RB Ada rusak 1 Radio', 
    'Object Repository/Form4/RB Tidak ada 1 Radio')

//AC
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxAC, 'Object Repository/Form4/Checkbox Perbedaan 2 AC', 'Object Repository/Form4/Textbox Perbedaan 2 AC', 
    GlobalVariable.PerbedaanAC)
kondisiBarang(GlobalVariable.RBAC, 'Object Repository/Form4/RB Ada baik 2 AC', 'Object Repository/Form4/RB Ada rusak 2 AC', 
    'Object Repository/Form4/RB TIdak ada 2 AC')
if ((GlobalVariable.RBAC == 1) || (GlobalVariable.RBAC == 2)) {
    tipe(GlobalVariable.RBtipeAC, 'Object Repository/Form4/Tipe 1 single AC', 'Object Repository/Form4/Tipe 2 Double AC')
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Kaca Spion Dalam
//SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxSpionDlm, 'Object Repository/Form4/Checkbox Perbedaan 3 Spion Dalam', 'Object Repository/Form4/Textbox Perbedaan 3 Spion dlm', 
    GlobalVariable.PerbedaanSpionDlm)
kondisiBarang(GlobalVariable.RBSpionDlm, 'Object Repository/Form4/RB Ada baik 3 Spion dlm', 'Object Repository/Form4/RB Ada rusak 3 Spion dlm', 
    'Object Repository/Form4/RB Tidak ada 3 Spion dlm')

//Power Window
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxPwrWndw, 'Object Repository/Form4/Checkbox Perbedaan 4 PowerWindow', 'Object Repository/Form4/Textbox perbedaan 4 power window', 
    GlobalVariable.PerbedaanPwrWndw)
kondisiBarang(GlobalVariable.RBPwrWndw, 'Object Repository/Form4/RB Ada baik 4 Power window', 'Object Repository/Form4/RB ada rusak 4 Power window', 
    'Object Repository/Form4/RB tidak ada 4 power window')

//Central Lock
//SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxCentralLock, 'Object Repository/Form4/Checkbox perbedaan 5 Central Lock', 'Object Repository/Form4/Textbox perbedaan 5 Central Lock', 
    GlobalVariable.PerbedaanCentralLock)
kondisiBarang(GlobalVariable.RBCentralLock, 'Object Repository/Form4/RB Ada baik 5 Central Lock', 'Object Repository/Form4/RB Ada rusak 5 Cental Lock', 
    'Object Repository/Form4/RB Tidak ada 5 Central lock')

//Kursi
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxKursi, 'Object Repository/Form4/Checkbox perbedaan 6 Kursi', 'Object Repository/Form4/Textbox perbedaan 6 kursi', 
    GlobalVariable.PerbedaanKursi)
kondisiBarang(GlobalVariable.RBKursi, 'Object Repository/Form4/RB Ada baik 6 Kursi', 'Object Repository/Form4/RB ada rusak 6 Kursi', 
    'Object Repository/Form4/RB tidak ada 6 kursi')
if ((GlobalVariable.RBKursi == 1) || (GlobalVariable.RBKursi == 2)) {
	Mobile.waitForElementPresent(findTestObject('Object Repository/Form4/Textbox Jumlah Kursi'), 20)
	Mobile.tap(findTestObject("Object Repository/Form4/Textbox Jumlah Kursi"), 10)
	Mobile.clearText(findTestObject("Object Repository/Form4/Textbox Jumlah Kursi"), 0)
	driver.getKeyboard().pressKey(GlobalVariable.JumlahKursi.toString())
	Mobile.hideKeyboard()		
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//karpet
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxKarpet, 'Object Repository/Form4/Checkbox perbedaan 7 karpet', 'Object Repository/Form4/Textbox perbedaan 7 karpet', 
    GlobalVariable.PerbedaanKarpet)
kondisiBarang(GlobalVariable.RBKarpet, 'Object Repository/Form4/RB ada baik 7 karpet', 'Object Repository/Form4/RB ada rusak 7 karpet', 
    'Object Repository/Form4/RB Tidak ada 7 Karpet')
if ((GlobalVariable.RBKarpet == 1) || (GlobalVariable.RBKarpet == 2)) {
    tipe(GlobalVariable.RBTipeKarpet, 'Object Repository/Form4/Tipe 1 Standar Karpet', 'Object Repository/Form4/Tipe 2 Tambahan karpet')
//	SwipeHelper.swipeUp()
	Mobile.waitForElementPresent(findTestObject('Object Repository/Form4/Jumlah karpet'), 20)
	Mobile.tap(findTestObject("Object Repository/Form4/Jumlah karpet"), 10)
	Mobile.clearText(findTestObject("Object Repository/Form4/Jumlah karpet"), 0)
	driver.getKeyboard().pressKey(GlobalVariable.JumlahKarpet.toString())
	Mobile.hideKeyboard()	
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Tang
//SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxTang, 'Object Repository/Form4/Checkbox perbedaan 8 Tang', 'Object Repository/Form4/Textbox perbedaan 8 Tang', 
    GlobalVariable.PerbedaanTang)
kondisiBarang(GlobalVariable.RBTang, 'Object Repository/Form4/RB ada Baik 8 Tang', 'Object Repository/Form4/RB Ada Rusak 8 Tang', 
    'Object Repository/Form4/RB Tidak ada 8 Tang')

//Obeng
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxObeng, 'Object Repository/Form4/Checkbox Perbedaan 9 Obeng', 'Object Repository/Form4/Textbox perbedaan 9 Obeng', 
    GlobalVariable.PerbedaanObeng)
kondisiBarang(GlobalVariable.RBObeng, 'Object Repository/Form4/RB Ada baik 9 Obeng', 'Object Repository/Form4/RB Ada rusak 9 Obeng', 
    'Object Repository/Form4/RB Tidak ada 9 Obeng')

//Kunci pass
//SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxKunciPas, 'Object Repository/Form4/Checkbox Perbedaan 10 KunciPas', 'Object Repository/Form4/Textbox perbedaan 10 kunci pas', 
    GlobalVariable.PerbedaanKunciPas)
kondisiBarang(GlobalVariable.RBKunciPas, 'Object Repository/Form4/RB ada baik 10 Kunci pas', 'Object Repository/Form4/RB Ada rusak 10 Kunci pas', 
    'Object Repository/Form4/RB Tidak ada 10 Kunci pas')

//KunciBan
//SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxKunciBan, 'Object Repository/Form4/Checkbox perbedaan 11 Kunci Ban', 'Object Repository/Form4/Textbox perbedaan 11 kunci Ban', 
    GlobalVariable.PerbedaanKunciBan)
kondisiBarang(GlobalVariable.RBKunciBan, 'Object Repository/Form4/RB Ada baik 11 Kunci Ban', 'Object Repository/Form4/RB ada rusak 11 Kunci ban', 
    'Object Repository/Form4/RB Tidak ada 11 Kunci ban')

//Dongkrak
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxDongkrak, 'Object Repository/Form4/Checkbox perbedaan 12 Dongkrak', 'Object Repository/Form4/TextBox perbedaan 12 dongkrak', 
    GlobalVariable.PerbedaanDongkrak)
kondisiBarang(GlobalVariable.RBDongkrak, 'Object Repository/Form4/RB ada baik 12 Dongkrak', 'Object Repository/Form4/RB ada rusak 12 Dongkrak', 
    'Object Repository/Form4/RB tidak ada 12 Dongkrak')

//SegitigaPngmn
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxSegitiga, 'Object Repository/Form4/Checkbox perbedaan 13 Stg', 'Object Repository/Form4/Textbox Perbedaan 13 stg', 
    GlobalVariable.PerbedaanSegitiga)
kondisiBarang(GlobalVariable.RBSegitiga, 'Object Repository/Form4/RB ada baik 13 Stg', 'Object Repository/Form4/RB ada rusak 13 stg', 
    'Object Repository/Form4/RB Tidak ada 13 Stg')

//Barang konsumen
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxBarangKnsmn, 'Object Repository/Form4/Checkbox perbedaan 14 Barang Knsmn', 'Object Repository/Form4/Textbox Perbedaan 14 Barang knsmn', 
    GlobalVariable.PerbedaanBarangKnsmn)
kondisiBarang(GlobalVariable.RBBarangKnsmn, 'Object Repository/Form4/RB ada baik 14 Barang knsmn', 'Object Repository/Form4/RB ada rusak 14 Barang knsmn', 
    'Object Repository/Form4/RB tidak ada 14 barang knsmn')
SwipeHelper.swipeUp2()
if ((GlobalVariable.RBBarangKnsmn == 1) || (GlobalVariable.RBBarangKnsmn == 2)) {
    Mobile.setText(findTestObject('Object Repository/Form4/Textboxt Deskripsi barang knsmsn'), GlobalVariable.DeskripsiBrgKnsmn, 0)
    Mobile.hideKeyboard()
    takePhoto('Object Repository/Form4/Upload barang knsmn')
    Mobile.takeScreenshot()
}
takeSS("Form 4")
Mobile.tap(findTestObject('Object Repository/Button next form 2'), 0)

//Next form 5
Mobile.waitForElementPresent(findTestObject('Object Repository/Form5/Button upload kondisi Kendaraan'), 0)
Mobile.tap(findTestObject('Object Repository/Form5/Button upload kondisi Kendaraan'), 0)
takePhoto('Object Repository/Form5/Upload Gesekan Mesin')
takePhoto('Object Repository/Form5/Upload Gesekan Rangka')
takePhoto2('Object Repository/Form5/Upload Mesin kendaraan')
Mobile.tap(findTestObject('Object Repository/Form3/Button save eksterior'), 0)
Mobile.waitForElementPresent(findTestObject('Object Repository/Popup Success'), 0)
Mobile.takeScreenshot()
Mobile.tap(findTestObject('Object Repository/Popup Success'), 0)

//Mesin
adaPerubahan(GlobalVariable.ChkboxMesin, 'Object Repository/Form5/Checkbox perbedaan 1 Mesin', 'Object Repository/Form5/Textbox perbedaan 1 Mesin', 
    GlobalVariable.PerbedaanMesin)
kondisiBarang(GlobalVariable.RBMesin, 'Object Repository/Form5/RB ada baik 1 Mesin', 'Object Repository/Form5/RB ada rusak 1 mesin', 
    'Object Repository/Form5/RB tidak ada 1 Mesin')

//Accu
adaPerubahan(GlobalVariable.ChkboxAccu, 'Object Repository/Form5/Checkbox Perbedaan 2 Accu', 'Object Repository/Form5/Textbox perbedaan 2 accu', 
    GlobalVariable.PerbedaanAccu)
kondisiBarang(GlobalVariable.RBAccu, 'Object Repository/Form5/RB ada baik 2 Accu', 'Object Repository/Form5/RB ada rusak 2 accu', 
    'Object Repository/Form5/RB tidak ada 2 accu')
takeSS("Form 5")
Mobile.tap(findTestObject('Object Repository/Button next form 2'), 0)

//Next form 6
Mobile.waitForElementPresent(findTestObject('Object Repository/Form6/Textbox kelengkapan Kendaraan'), 0)
Mobile.setText(findTestObject('Object Repository/Form6/Textbox kelengkapan Kendaraan'), GlobalVariable.KelengkapanKendaraan, 0)
Mobile.hideKeyboard()
//Mobile.tap(findTestObject('Object Repository/Form6/Upload foto kerusakan', [('Upload') : '1']), 0)
takePhoto3('Object Repository/Form6/Upload foto kerusakan', [('Upload') : '1'])
handlePopupOk()
Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

SwipeHelper.swipeUp2()
Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
SwipeHelper.swipeUp2()
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)
Mobile.takeScreenshot()
if (GlobalVariable.fotoKerusakan > 1) {
    for (int j = 1; j < GlobalVariable.fotoKerusakan; j++) {
        int k = j + 1
        String tambah = k.toString()
        Mobile.tap(findTestObject('Object Repository/Form6/Button Tambah Upload'), 0)
        if (Mobile.verifyElementNotVisible(findTestObject('Object Repository/Form6/Upload foto kerusakan', [('Upload') : tambah]), 
            5, FailureHandling.OPTIONAL) == true) {
			SwipeHelper.swipeUp()
        }        
        println(tambah)
		if (!Mobile.verifyElementVisible(findTestObject('Object Repository/Form6/Upload foto kerusakan', [('Upload') : tambah]), 2, FailureHandling.OPTIONAL)) {
			SwipeHelper.swipeUp2()
		}
//        Mobile.tap(findTestObject('Object Repository/Form6/Upload foto kerusakan', [('Upload') : tambah]), 0)
		takePhoto3('Object Repository/Form6/Upload foto kerusakan', [('Upload') : tambah])
		handlePopupOk()
//		takePhoto('Object Repository/Form6/Upload foto kerusakan')		
		Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
		SwipeHelper.swipeUp2()		
        Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
		SwipeHelper.swipeUp2()
    }
}
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)
SwipeHelper.swipeUp()
Mobile.setText(findTestObject('Object Repository/Form6/Textbox Keterangan kerusakan'), GlobalVariable.KeteranganRusak, 0)
Mobile.hideKeyboard()
takeSS("Form 6")
Mobile.tap(findTestObject('Object Repository/Button next form 2'), 0)

//Next form 7
Mobile.waitForElementPresent(findTestObject('Object Repository/Form7/Upload BAST'), 0)
takePhoto('Object Repository/Form7/Upload BAST')
takeSS("Form 7")
// sengaja di remarks, remarks akan dibuka jika sudah ingin submit data dan 
//Mobile.tap(findTestObject('Object Repository/Form7/android.widget.TextView - Submit'), 0)

//    Mobile.tapAtPosition(812, 2135)
//Mobile.checkElement(findTestObject(null), 0)
//Mobile.checkElement(findTestObject(null), 0)






