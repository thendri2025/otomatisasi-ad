 import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.mobile.keyword.internal.MobileAbstractKeyword as MobileAbstractKeyword
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import com.kms.katalon.core.util.KeywordUtil
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper as MobileElementCommonHelper
import io.appium.java_client.MobileElement as MobileElement
import io.appium.java_client.android.nativekey.AndroidKey
import io.appium.java_client.android.nativekey.KeyEvent
import io.appium.java_client.AppiumDriver
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.interactions.PointerInput
import org.openqa.selenium.interactions.Sequence
import io.appium.java_client.TouchAction as TouchAction
import io.appium.java_client.android.AndroidDriver as AndroidDriver
import io.appium.java_client.touch.WaitOptions as WaitOptions
import io.appium.java_client.touch.offset.PointOption as PointOption
import java.time.Duration as Duration
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory as MobileDriverFactory


public class SwipeHelper {	
	private static AndroidDriver getDriver() {
		return (AndroidDriver) MobileDriverFactory.getDriver()
	}

	static void swipeUp() {
		AndroidDriver driver = getDriver()
		int width = driver.manage().window().getSize().width
		int height = driver.manage().window().getSize().height

		int startX = width / 2
		int startY = (int) (height * 0.8)   // titik bawah
		int endY   = (int) (height * 0.2)   // titik atas

		performSwipe(driver, startX, startY, startX, endY)
	}

	static void swipeUp2() {
		AndroidDriver driver = getDriver()
		int width = driver.manage().window().getSize().width
		int height = driver.manage().window().getSize().height

		int startX = width / 2
		int startY = (int) (height * 0.8)   // titik bawah
		int endY   = (int) (height * 0.6)   // titik atas

		performSwipe(driver, startX, startY, startX, endY)
	}


	static void swipeDown() {
		AndroidDriver driver = getDriver()
		int width = driver.manage().window().getSize().width
		int height = driver.manage().window().getSize().height

		int startX = width / 2
		int startY = (int) (height * 0.2)   // titik atas
		int endY   = (int) (height * 0.8)   // titik bawah

		performSwipe(driver, startX, startY, startX, endY)
	}
	
	static void scrollToText(String text) {
		AndroidDriver driver = getDriver()
		try {
			driver.findElementByAndroidUIAutomator(
				'new UiScrollable(new UiSelector().scrollable(true))' +
				'.scrollIntoView(new UiSelector().text("' + text + '"))'
			)
		} catch (Exception e) {
			println "⚠️ Tidak menemukan teks: " + text
		}
	}

	private static void performSwipe(AndroidDriver driver, int startX, int startY, int endX, int endY) {
		PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger")
		Sequence swipe = new Sequence(finger, 1)

		swipe.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), startX, startY))
		swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
		swipe.addAction(finger.createPointerMove(Duration.ofMillis(800), PointerInput.Origin.viewport(), endX, endY))
		swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))

		driver.perform(Arrays.asList(swipe))
	}
}


WebUI.callTestCase(findTestCase('Login/Login BCAF'), [:], FailureHandling.STOP_ON_FAILURE)

// Deklarasi sekali di awal
AndroidDriver<?> driver = (AndroidDriver<?>) MobileDriverFactory.getDriver()

Mobile.waitForElementPresent(findTestObject('Button Task'), 20)

//Mobile.takeScreenshot()

Mobile.tap(findTestObject('Button Task'), 10)

Mobile.waitForElementPresent(findTestObject('Button CarIn'), 10)

//Mobile.takeScreenshot()

Mobile.tap(findTestObject('Button CarIn'), 0)

Mobile.waitForElementPresent(findTestObject('Dropdown Tipe Transaksi'), 0)

//Mobile.takeScreenshot()

Mobile.verifyElementExist(findTestObject('Dropdown Tipe Transaksi'), 10)

Mobile.tap(findTestObject('Dropdown Tipe Transaksi'), 0)

//Mobile.takeScreenshot()

Mobile.tap(findTestObject('List Dropdown - Titipan Konsumen'), 0)

//Mobile.takeScreenshot()

Mobile.waitForElementPresent(findTestObject('TextBox No Polisi'), 0)

Mobile.setText(findTestObject('TextBox No Polisi'), GlobalVariable.NoPolisi, 0 // 1
    )

Mobile.hideKeyboard()

//Mobile.takeScreenshot()

Mobile.tap(findTestObject('Button submit pencarian CarIn'), 0)

Mobile.waitForElementPresent(findTestObject('Verify No Polisi'), 5)

//Mobile.takeScreenshot()

//TestObject DataCarIn = new TestObject()

//DataCarIn.addProperty('xpath', ConditionType.EQUALS, '//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView[1]/android.widget.LinearLayout[1]')

//TestObject VerifyNopol = new TestObject().addProperty('xpath', ConditionType.EQUALS, DataCarIn.findPropertyValue('xpath') + 
//    '/android.widget.LinearLayout[1]/android.widget.TextView[5]')


TestObject DataCarIn = new TestObject().addProperty('xpath', ConditionType.EQUALS,
	"//androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[1]")

TestObject VerifyNopol = new TestObject()
VerifyNopol.addProperty("resource-id", ConditionType.EQUALS, "com.indocyber.bcaf:id/valNoPolisi")

Mobile.waitForElementPresent(VerifyNopol, 10)

String Nopol = Mobile.getText(VerifyNopol, 0)
println("Nopol: " + Nopol)

if (GlobalVariable.NoPolisi.contains(Nopol)) {
    TestObject DetailData = new TestObject().addProperty('xpath', ConditionType.EQUALS, DataCarIn.findPropertyValue('xpath') + 
        '/android.widget.ImageView[1]')

    Mobile.tap(DataCarIn, 0)
} else {
    KeywordUtil.markFailed('Object yang dicari tidak sesuai.')
}

Mobile.waitForElementPresent(findTestObject('NoBAST'), 0 //2
    )

//Mobile.takeScreenshot()

Mobile.delay(3)

Mobile.setText(findTestObject('NoBAST'), GlobalVariable.NoBAST, 0 //3
    )

Mobile.hideKeyboard()

//Mobile.takeScreenshot()

Mobile.tap(findTestObject('Nama_Pool'), 0 //4
    )

//Mobile.takeScreenshot()

int i = 1

while (true) {
    TestObject ChoosePool = new TestObject()

    ChoosePool.addProperty('xpath', ConditionType.EQUALS, "//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.view.ViewGroup[1]/androidx.recyclerview.widget.RecyclerView[1]/android.widget.LinearLayout[$i]/android.widget.LinearLayout[1]/android.widget.TextView[1]")

    String verify = Mobile.getText(ChoosePool, 0)

    println(verify)

    if (verify == GlobalVariable.Pool) {
        Mobile.takeScreenshot()

        Mobile.tap(ChoosePool, 0)

        break //4
    } else {
//        scrollKoorY(650, 450)
		SwipeHelper.swipeUp()
		
    }
}

Mobile.delay(3)

Mobile.waitForElementPresent(findTestObject('TanggalTerimaKonsumen'), 0 //5
    )

//Mobile.takeScreenshot()

Mobile.tap(findTestObject('TanggalTerimaKonsumen'), 0 //6
    )

//Mobile.takeScreenshot()

datePicker(GlobalVariable.TanggalKonsumen, GlobalVariable.BulanKonsumen, GlobalVariable.TahunKonsumen)

//Mobile.takeScreenshot()

Mobile.waitForElementPresent(findTestObject('TanggalTerimaPool'), 0 //7
    )

Mobile.tap(findTestObject('TanggalTerimaPool'), 0 //8
    )

//Mobile.takeScreenshot()

datePicker(GlobalVariable.TanggalPool, GlobalVariable.BulanPool, GlobalVariable.TahunPool)

//Mobile.takeScreenshot()

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

// CASE STOPPER
//Mobile.scrollToText('Meter Bensin', FailureHandling.STOP_ON_FAILURE //9
//    )

	//TestObject seekbar = new TestObject()
//seekbar.addProperty("resource-id", ConditionType.EQUALS, "com.indocyber.bcaf:id/valueSeekbar")
//Mobile.scrollToElement(seekbar, 10)
		
//Mobile.swipe(500, 1000, 500, 1500)
//Mobile.touchAndSwipe(500, 1000, 500, 500)

		
//Mobile.tap(findTestObject('MeterBensin'), 0 //10
//    )

// scrollToEnd
SwipeHelper.swipeUp()
SwipeHelper.swipeUp()

// Klik field kota
Mobile.waitForElementPresent(findTestObject('Pencarian kota Kendaraan'), 30)
Mobile.tap(findTestObject("Pencarian kota Kendaraan"), 10)

// Buat object dinamis untuk field Search
TestObject searchField = new TestObject("dynamicSearch")
searchField.addProperty("xpath", ConditionType.EQUALS,
	"//*[@class='android.widget.EditText' and @resource-id='com.indocyber.bcaf:id/searchEditText']")

// Pastikan field search muncul sebelum setText
Mobile.waitForElementPresent(searchField, 20)

// Set text ke field
Mobile.tap(searchField, 10)
Mobile.setText(searchField, GlobalVariable.KotaKendaraan, 0)

// Tutup keyboard biar list kelihatan
Mobile.hideKeyboard()

// Tekan tombol Search / Enter di keyboard
MobileDriverFactory.getDriver().pressKey(new KeyEvent(AndroidKey.ENTER))

// Tambahkan sedikit delay agar hasil keluar
Mobile.delay(3)

boolean found = false
int z = 1
String kota = GlobalVariable.KotaKendaraan.trim()
while (!found) {
	TestObject kotaOption = new TestObject("dynamicKota" + z)
	kotaOption.addProperty("xpath", ConditionType.EQUALS,
		"//androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[" + z + "]/android.widget.LinearLayout/android.widget.TextView")

	try {
		String verify = Mobile.getText(kotaOption, 3)
		println("Ditemukan: " + verify)

		if (verify.equalsIgnoreCase(kota)) {
			Mobile.takeScreenshot()
			Mobile.tap(kotaOption, 10)
			println("Berhasil memilih kota: " + verify)
			found = true
		} else {
			// scroll kalau teks tidak sesuai			
//			scrollKoorY(650, 450)
			SwipeHelper.swipeUp()
		}
	} catch (Exception e) {
		// kalau index ke-i ga ada → scroll
//		scrollKoorY(650, 450)
		SwipeHelper.swipeUp()
	}
	z++
}


Mobile.hideKeyboard()

// scrollToEnd
SwipeHelper.swipeUp()
SwipeHelper.swipeUp()

// Step 11 - Set lokasi kendaraan
Mobile.setText(findTestObject('LokasiKendaraanDiAmbil'), GlobalVariable.Lokasikendaraan, 0)

Mobile.hideKeyboard()

// Step 12 - Input kilometer
Mobile.waitForElementPresent(findTestObject('Object Repository/KM'), 20)
Mobile.tap(findTestObject("Object Repository/KM"), 10)
Mobile.clearText(findTestObject("Object Repository/KM"), 0)
//AndroidDriver<?> driver = (AndroidDriver<?>) MobileDriverFactory.getDriver()
driver.getKeyboard().pressKey(GlobalVariable.Kilometer.toString())
Mobile.hideKeyboard()


//int x_min = 73
//
//int x_max = 1007
//
//// Pastikan jadi double supaya tidak dibulatkan
//double persen = GlobalVariable.MeterBensin / 100.0
//int x = (int)(x_min + (persen * (x_max - x_min)))
//
////println(x)
//
//// Cari object slider
//TestObject slider = findTestObject('Object Repository/MeterBensin')
//
//
//// Ambil element asli dari TestObject
////MobileElement sliderElement = driver.findElement(slider.findProperties().get(0).getLocatorStrategy(), slider.findProperties().get(0).getLocator())
//
//// Ambil element asli
//MobileElement sliderElement = (MobileElement) MobileElementCommonHelper.findElement(slider, 10)
//
//// Hitung posisi Y dari elemen
//int y = sliderElement.getLocation().getY() + (sliderElement.getSize().getHeight() / 2)
//	
//Mobile.tapAtPosition(x, y)

//// --- Persentase target (0 - 100) ---
//int targetPercent = GlobalVariable.MeterBensin
//
//// --- Ambil driver ---
////AppiumDriver driver = MobileDriverFactory.getDriver()
//
//// Cari object slider di repository
//TestObject slider = findTestObject('Object Repository/MeterBensin')
//// Tunggu sampai slider muncul
//Mobile.waitForElementPresent(slider, 20)
//
//// Ambil elemen asli berdasarkan resource-id
//MobileElement sliderElement = driver.findElementById("com.indocyber.bcaf:id/valueSeekBar")
//
//// Hitung posisi slider
//int startX = sliderElement.getLocation().getX()
//int yAxis = sliderElement.getLocation().getY()
//int elementWidth = sliderElement.getSize().getWidth()
//
//// Geser ke 70% (misalnya mau isi bensin 70%)
//int moveToX = startX + (elementWidth * targetPercent / 100)
//
//// Lakukan swipe/drag
//Mobile.swipe(startX, yAxis, moveToX, yAxis)
//
//// Optional: kasih delay biar kelihatan
//Mobile.delay(2)

// Ambil persentase dari GlobalVariable
int targetPercent = GlobalVariable.MeterBensin

// Panggil fungsi helper
setSliderPercent(findTestObject('Object Repository/MeterBensin'), targetPercent)

// Delay biar kelihatan
Mobile.delay(2)


Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Button Next Form (1)'), 0 //13
    )

//Lanjut Form2
Mobile.waitForElementPresent(findTestObject('Form2/Ada baik 1'), 0)

//Mobile.takeScreenshot()

//STNK 5 Tahun
adaPerubahan(GlobalVariable.STNK5thn, 'Object Repository/Form2/Checkbox Ada perbedaan 1', 'Object Repository/Form2/Textbox STNK 5thn', 
    GlobalVariable.Perbedaan5thn 
    )

kondisiBarang(GlobalVariable.RBSTNK5thn, 'Object Repository/Form2/Ada baik 1', 'Object Repository/Form2/Ada rusak 1', 'Object Repository/Form2/Tidak ada 1' 
    )

//Mobile.takeScreenshot()

if ((GlobalVariable.RBSTNK5thn == 1) || (GlobalVariable.RBSTNK5thn == 2)) {
    Mobile.tap(findTestObject('Object Repository/Form2/Datepicker STNK5thn'), 0)

    datePicker(GlobalVariable.Tanggal5thn, GlobalVariable.Bulan5thn, GlobalVariable.Tahun5thn)

	Mobile.delay(2)
	Mobile.waitForElementPresent(findTestObject('Object Repository/Form2/Upload STNK5thn'), 20)	
	takePhoto('Object Repository/Form2/Upload STNK5thn' 
        )
}

//Mobile.takeScreenshot()

SwipeHelper.swipeUp()

//STNK 1 Tahun
adaPerubahan(GlobalVariable.STNK1thn, 'Object Repository/Form2/Checkbox ada perbedaan 2', 'Object Repository/Form2/Textbox STNK 1thn', 
    GlobalVariable.Perbedaan1thn 
    )

kondisiBarang(GlobalVariable.RBSTNK1thn, 'Object Repository/Form2/Ada baik 2', 'Object Repository/Form2/Ada rusak 2', 'Object Repository/Form2/Tidak ada 2' 
    )

SwipeHelper.swipeUp()
//Mobile.scrollToText('Tgl Jatuh Tempo 1 Tahun', FailureHandling.CONTINUE_ON_FAILURE 
//    )

//Mobile.takeScreenshot()

if ((GlobalVariable.RBSTNK1thn == 1) || (GlobalVariable.RBSTNK1thn == 2)) {
    Mobile.tap(findTestObject('Object Repository/Form2/Datepicker STNK1thn'), 0)

    datePicker(GlobalVariable.Tanggal1thn, GlobalVariable.Bulan1thn, GlobalVariable.Tahun1thn)

//    inputNumber('Object Repository/Form2/Textbox Pajak 1thn', GlobalVariable.Pajak1Tahun 
//        )
	Mobile.waitForElementPresent(findTestObject('Object Repository/Form2/Textbox Pajak 1thn'), 20)
	Mobile.tap(findTestObject("Object Repository/Form2/Textbox Pajak 1thn"), 10)
	Mobile.clearText(findTestObject("Object Repository/Form2/Textbox Pajak 1thn"), 0)
//	AndroidDriver<?> driver = (AndroidDriver<?>) MobileDriverFactory.getDriver()
	driver.getKeyboard().pressKey(GlobalVariable.Pajak1Tahun.toString())
	Mobile.hideKeyboard()
					
    //	scrollKoorY(1200, 1450)
	SwipeHelper.swipeUp()
    takePhoto('Object Repository/Form2/Upload STNK1thn' 
        )
}

//Mobile.takeScreenshot()

//Buku KIR
//Mobile.scrollToText('Buku KIR' 
//    )
SwipeHelper.swipeUp()
SwipeHelper.swipeUp()

adaPerubahan(GlobalVariable.KIR, 'Object Repository/Form2/Checkbox ada perbedaan 3', 'Object Repository/Form2/Textbox KIR', 
    GlobalVariable.PerbedaanKIR 
    )

kondisiBarang(GlobalVariable.RBKIR, 'Object Repository/Form2/Ada baik 3', 'Object Repository/Form2/Ada rusak 3', 'Object Repository/Form2/Tidak ada 3' 
    )

//Mobile.takeScreenshot()

if ((GlobalVariable.RBKIR == 1) || (GlobalVariable.RBKIR == 2)) {
//if (GlobalVariable.RBKIR?.toString() in ['1','2']) {
    // Tap datepicker
    Mobile.tap(findTestObject('Object Repository/Form2/Datepicker KIR'), 0)

    // Pilih tanggal lewat custom function
    datePicker(GlobalVariable.TanggalKIR, GlobalVariable.BulanKIR, GlobalVariable.TahunKIR)

    // Scroll/swipe supaya tombol upload terlihat
    SwipeHelper.swipeUp()

    // Ambil foto (fungsi custom takePhoto)
    takePhoto('Object Repository/Form2/Upload KIR')

    // Scroll lagi setelah upload
    SwipeHelper.swipeUp()

    // Kalau mau pastikan posisi ke "Buku Manual/service"
    // Mobile.scrollToText('Buku Manual/service')
}


//Mobile.takeScreenshot()


Mobile.waitForElementPresent(findTestObject('Object Repository/Form2/Checkbox ada perbedaan 4'), 10)

//Buku Manual or Service
adaPerubahan(GlobalVariable.ManualService, 'Object Repository/Form2/Checkbox ada perbedaan 4', 'Object Repository/Form2/TextBox Manual service', 
    GlobalVariable.PerbedaanManualService 
    )

kondisiBarang(GlobalVariable.RBManualService, 'Object Repository/Form2/Ada baik 4', 'Object Repository/Form2/Ada rusak 4', 
    'Object Repository/Form2/Tidak ada 4' 
    )

handlePopupOk()
	
//Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Button next form 2'), 0 
    )

handlePopupOk()
	
	
//Form ke-3
Mobile.waitForElementPresent(findTestObject('Object Repository/Form3/Button Exterior'), 0)

//Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Form3/Button Exterior'), 0 //31
    )

//Mobile.takeScreenshot()

takePhoto('Object Repository/Form3/Upload Ban Cadangan' //32
    )

//Mobile.takeScreenshot()

takePhoto('Object Repository/Form3/Upload Ban Digunakan' //33
    )

//Mobile.takeScreenshot()

takePhoto('Object Repository/Form3/Upload belakang' //34
    )

//Mobile.takeScreenshot()

takePhoto('Object Repository/Form3/Upload depan' //35
    )

SwipeHelper.swipeUp()
	

//Mobile.takeScreenshot()


takePhoto('Object Repository/Form3/Upload Samping kanan' //36
    )

//Mobile.takeScreenshot()

takePhoto('Object Repository/Form3/Upload samping kiri' //37
    )

//Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Form3/Button save eksterior'), 0 //38
    )

Mobile.waitForElementPresent(findTestObject('Popup Success'), 0)

//Mobile.takeScreenshot()

Mobile.tap(findTestObject('Popup Success'), 0)

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Kunci Kontak
adaPerubahan(GlobalVariable.ChkboxKontak, 'Object Repository/Form3/Checkbox perbedaan 1 Kontak', 'Object Repository/Form3/Textbox Perbedaan 1 Kontak', 
    GlobalVariable.PerbedaanKontak 
    )

kondisiBarang(GlobalVariable.RBKunciKontak, 'Object Repository/Form3/RB Ada baik 1 Kontak', 'Object Repository/Form3/RB Ada rusak 1 Kontak', 
    'Object Repository/Form3/RB Tidak ada 1 Kontak' 
    )

//Mobile.takeScreenshot()

if ((GlobalVariable.RBKunciKontak == 1) || (GlobalVariable.RBKunciKontak == 2)) {
//    inputNumber('Object Repository/Form3/Textbox Jumlah Kontak', GlobalVariable.JumlahKontak)
	Mobile.waitForElementPresent(findTestObject('Object Repository/Form3/Textbox Jumlah Kontak'), 20)
	Mobile.tap(findTestObject("Object Repository/Form3/Textbox Jumlah Kontak"), 10)
	Mobile.clearText(findTestObject("Object Repository/Form3/Textbox Jumlah Kontak"), 0)
//	AndroidDriver<?> driver = (AndroidDriver<?>) MobileDriverFactory.getDriver()
	driver.getKeyboard().pressKey(GlobalVariable.JumlahKontak.toString())
	Mobile.hideKeyboard()

	

//    Mobile.takeScreenshot()

//    scrollKoorY(1200, 1450)
    
	takePhoto('Object Repository/Form3/Upload kontak')

//    Mobile.takeScreenshot()
}

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Alarm
adaPerubahan(GlobalVariable.ChkboxAlarm, 'Object Repository/Form3/Checkbox pebedaan 2 Alarm', 'Object Repository/Form3/Textbox perbedaan 2 alarm', 
    GlobalVariable.PerbedaanAlarm)

//scroll('Object Repository/Form3/RB Ada baik 2 Alarm', 'Lampu Depan')

kondisiBarang(GlobalVariable.RBAlarm, 'Object Repository/Form3/RB Ada baik 2 Alarm', 'Object Repository/Form3/RB Ada rusak 2 alarm', 
    'Object Repository/Form3/RB Tidak ada 2 Alarm')

//SwipeHelper.swipeUp()

//Mobile.takeScreenshot()

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//SwipeHelper.scrollToText("Lampu Depan")
SwipeHelper.swipeUp2()

//Lampu Depan
adaPerubahan(GlobalVariable.ChkboxLampuDpn, 'Object Repository/Form3/Checkbox Perbedaan 3 LampuDpn', 'Object Repository/Form3/TextBoxt Perbedaan 3 Alarm', 
    GlobalVariable.PerbedaanLampuDpn)

kondisiBarang(GlobalVariable.RBLampuDpn, 'Object Repository/Form3/RB Ada baik 3 LampuDPn', 'Object Repository/Form3/RB Ada Rusak 3 LampuDPn', 
    'Object Repository/Form3/RB Tidak ada 3 LampuDpn')

Mobile.takeScreenshot()

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//SwipeHelper.scrollToText("Wiper")
SwipeHelper.swipeUp2()
//Wiper
adaPerubahan(GlobalVariable.ChkboxWiper, 'Object Repository/Form3/Checkbox perbedaan 4 Wiper', 'Object Repository/Form3/Textbox Perbedaan 4 Wiper', 
    GlobalVariable.PerbedaanWiper)

kondisiBarang(GlobalVariable.RBWiper, 'Object Repository/Form3/RB ada baik 4 WIper', 'Object Repository/Form3/RB ada rusak 4 wiper', 
    'Object Repository/Form3/RB tidak ada 4 wiper')

Mobile.takeScreenshot()

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//SwipeHelper.scrollToText("Kaca Spion Kiri")
SwipeHelper.swipeUp2()

//Kaca Spion Kiri
adaPerubahan(GlobalVariable.ChkboxSpionKr, 'Object Repository/Form3/Checkbox Perbedaan 5 Spion Kiri', 'Object Repository/Form3/Textbox Perbedaan 5 SpionKiri', 
    GlobalVariable.PerbedaanSpionKr)

kondisiBarang(GlobalVariable.RBSpionKr, 'Object Repository/Form3/RB Ada baik 5 Spion Kiri', 'Object Repository/Form3/RB Ada rusak 5 Spion Kiri', 
    'Object Repository/Form3/RB Tidak ada 5 Spion Kiri')

Mobile.takeScreenshot()

if ((GlobalVariable.RBSpionKr == 1) || (GlobalVariable.RBSpionKr == 2)) {
    tipe(GlobalVariable.RBTipeSpionKr, 'Object Repository/Form3/Tipe 1 Elektrik Spion Kiri', 'Object Repository/Form3/Tipe 2 Non Elektrik Spion Kiri')

    Mobile.takeScreenshot()
}

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Spion Kanan
//SwipeHelper.scrollToText("Kaca Spion Kanan")
SwipeHelper.swipeUp2()
//SwipeHelper.swipeUp()

adaPerubahan(GlobalVariable.ChkboxSpionKnn, 'Object Repository/Form3/Checkbox Perbedaan 6 SpionKanan', 'Object Repository/Form3/Textbox perbedaan 6 Spion kanan', 
    GlobalVariable.PerbedaanSpionKnn)

kondisiBarang(GlobalVariable.RBSpionKnn, 'Object Repository/Form3/RB Ada baik 6 Spion Kanan', 'Object Repository/Form3/RB Ada rusak 6 Spion kanan', 
    'Object Repository/Form3/RB Tidak Ada 6 Spion kanan')

//Mobile.takeScreenshot()

if ((GlobalVariable.RBSpionKnn == 1) || (GlobalVariable.RBSpionKnn == 2)) {
    tipe(GlobalVariable.RBTipeSpionKnn, 'Object Repository/Form3/Tipe 1 Elektrik Spion Kanan', 'Object Repository/Form3/Tipe 2 Non Elektrik Spion Kanan')

    Mobile.takeScreenshot()
}

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//SwipeHelper.scrollToText("Ban + Velg Depan Kiri")
SwipeHelper.swipeUp2()

//Velg depan kiri
adaPerubahan(GlobalVariable.ChkboxVelgDpnKr, 'Object Repository/Form3/Checkbox perbedaan 7 Velg dpn kiri', 'Object Repository/Form3/Textbox perbedaan 7 Velg dpn kr', 
    GlobalVariable.PerbedaanVelgDpnKr)

kondisiBarang(GlobalVariable.RBVelgDpnKr, 'Object Repository/Form3/RB Ada Baik 7 Velg dpn kiri', 'Object Repository/Form3/RB Ada rusak 7 velg dpn kr', 
    'Object Repository/Form3/RB TIdak ada 7 Velg dpn kr')

Mobile.takeScreenshot()

if ((GlobalVariable.RBVelgDpnKr == 1) || (GlobalVariable.RBVelgDpnKr == 2)) {
    tipe(GlobalVariable.RBTipeVelgDpnKr, 'Object Repository/Form3/Tipe 1 Racing Velg dpn kr', 'Object Repository/Form3/Tipe 2 Kaleng Velg dpn Kiri')

    Mobile.takeScreenshot()

    tipe(GlobalVariable.RBDopVelgDpnKr, 'Object Repository/Form3/Dop 1 Ada Velg dpn kr', 'Object Repository/Form3/Dop 2 Tidak ada Velg dpn kr')

    Mobile.takeScreenshot()
}

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Velg Dpn Kanan
//SwipeHelper.scrollToText("Ban + Velg Depan Kanan")
SwipeHelper.swipeUp2()

adaPerubahan(GlobalVariable.ChkboxVelgDpnKnn, 'Object Repository/Form3/Checkbox perbedaan 8 Velp dpn knn', 'Object Repository/Form3/Textbox perbedaan 8 Velg dpn knn', 
    GlobalVariable.PerbedaanVelgDpnKanan)

kondisiBarang(GlobalVariable.RBVelgDpnKnn, 'Object Repository/Form3/RB Ada baik 8 Velg dpn knn', 'Object Repository/Form3/RB Ada rusak 8 Velg dpn knn', 
    'Object Repository/Form3/RB Tidak ada 8 Velg dpn knn')

Mobile.takeScreenshot()

if ((GlobalVariable.RBVelgDpnKnn == 1) || (GlobalVariable.RBVelgDpnKnn == 2)) {
    tipe(GlobalVariable.RBTipeVelgDpnKnn, 'Object Repository/Form3/Tipe 1 Racing Velg dpn knn', 'Object Repository/Form3/Tipe 2 Kaleng Velg dpn knn')

    Mobile.takeScreenshot()

    tipe(GlobalVariable.RBDopVelgDpnKnn, 'Object Repository/Form3/Dop 1 Ada Velg dpn knn', 'Object Repository/Form3/Dop 2 Tidak velg dpn knn')

    Mobile.takeScreenshot()
}

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//SwipeHelper.scrollToText("Ban + Velg Belakang Kanan")
SwipeHelper.swipeUp2()

//velg Belakang Kanan
//scroll('Object Repository/Form3/Checkbox perbedaan 9 Velg blkg knn', 'Ban + Velg Belakang Kanan')

adaPerubahan(GlobalVariable.ChkboxVelgBlkgKnn, 'Object Repository/Form3/Checkbox perbedaan 9 Velg blkg knn', 'Object Repository/Form3/Textbox perbedaan 9 Velg blkg knn', 
    GlobalVariable.PerbedaanVelgBlkgKanan)

kondisiBarang(GlobalVariable.RBVelgBlkgKnn, 'Object Repository/Form3/RB Ada baik 9 velg blkg knn', 'Object Repository/Form3/RB Ada rusak 9 velg blkg knn', 
    'Object Repository/Form3/RB Tidak ada 9 Velg blkg knn')

Mobile.takeScreenshot()

if ((GlobalVariable.RBVelgBlkgKnn == 1) || (GlobalVariable.RBVelgBlkgKnn == 2)) {
    tipe(GlobalVariable.RBTipeVelgBlkgKnn, 'Object Repository/Form3/Tipe 1 Racing Velg blkg knn', 'Object Repository/Form3/Tipe 2 Kaleng Velg blkg knn')

    Mobile.takeScreenshot()

//    scrollKoorY(1950, 1600)
//	SwipeHelper.swipeUp()
	
    tipe(GlobalVariable.RBDopVelgBlkgKnn, 'Object Repository/Form3/Dop 1 Ada Velg blkg knn', 'Object Repository/Form3/Dop 2 Tida velg blkg kn')

    Mobile.takeScreenshot()
}

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Velg Blkg Kiri
//scroll('Object Repository/Form3/RB Ada baik 10 Velg Blkg kr', 'Ban + Velg Belakang Kiri')

//SwipeHelper.scrollToText("Ban + Velg Belakang Kiri")
SwipeHelper.swipeUp2()
//scrollKoorY(1950, 1650)
//SwipeHelper.swipeUp()

adaPerubahan(GlobalVariable.ChkboxVelgBlkgKr, 'Object Repository/Form3/Checkbox perbedaan 10 Velg blkg kr', 'Object Repository/Form3/Textbox perbedaan 10 Velg blkg kr', 
    GlobalVariable.PerbedaanVelgBlkgKr)

kondisiBarang(GlobalVariable.RBVelgBlkgKr, 'Object Repository/Form3/RB Ada baik 10 Velg Blkg kr', 'Object Repository/Form3/RB Ada rusak 10 Velg blkg kr', 
    'Object Repository/Form3/RB Tidak ada 10 velg blkg kr')

Mobile.takeScreenshot()

if ((GlobalVariable.RBVelgBlkgKr == 1) || (GlobalVariable.RBVelgBlkgKr == 2)) {
    tipe(GlobalVariable.RBTipeVelgBlkgKr, 'Object Repository/Form3/Tipe 1 Racing velg blkg kr', 'Object Repository/Form3/Tipe 2 Kaleng Velg blkg kr')

    Mobile.takeScreenshot()

    tipe(GlobalVariable.RBDopVelgBlkgKr, 'Object Repository/Form3/Dop 1 Ada velg blkg kr', 'Object Repository/Form3/Dop 2 Tidak Velg blkg kr')

    Mobile.takeScreenshot()
}

//scrollKoorY(1650, 1950)
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//velg Serep
//scroll('Object Repository/Form3/RB Ada baik 11 Velg srp', 'Ban + Velg Serep')
//SwipeHelper.scrollToText("Ban + Velg Serep")
SwipeHelper.swipeUp2()

adaPerubahan(GlobalVariable.ChkboxVelgSrp, 'Object Repository/Form3/Checkbox perbedaan 11 Velg srp', 'Object Repository/Form3/Textbox perbedaan 11 velg srp', 
    GlobalVariable.PerbedaanVelgSrp)

kondisiBarang(GlobalVariable.RBVelgSrp, 'Object Repository/Form3/RB Ada baik 11 Velg srp', 'Object Repository/Form3/RB Ada rusak 11 Velg srp', 
    'Object Repository/Form3/RB Tidak ada 11 Velg srp')

if ((GlobalVariable.RBVelgSrp == 1) || (GlobalVariable.RBVelgSrp == 2)) {
    tipe(GlobalVariable.RBTipeVelgSrp, 'Object Repository/Form3/Tipe 1 Racing Velg srp', 'Object Repository/Form3/Tipe 2 Kaleng Velg spr')

    tipe(GlobalVariable.RBDopVelgSrp, 'Object Repository/Form3/Dop 1 ada Velg srp', 'Object Repository/Form3/Dop 2 tidak Velg srp')
}

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Lampu Belakang
//scroll('Object Repository/Form3/RB ada baik 12 lampu blkg', 'Lampu Belakang')

//scrollKoorY(1950, 1600)
SwipeHelper.swipeUp()

adaPerubahan(GlobalVariable.ChkboxLampublkg, 'Object Repository/Form3/Checkbox perbedaan 12 Lampu blkg', 'Object Repository/Form3/Textbox perbedaan 12 Lampu blkg', 
    GlobalVariable.PerbedaanLampublg)

kondisiBarang(GlobalVariable.RBLampuBlkg, 'Object Repository/Form3/RB ada baik 12 lampu blkg', 'Object Repository/Form3/RB Ada rusak 12 Lampu blkg', 
    'Object Repository/Form3/RB tidak ada 12 lampu blkg')

Mobile.takeScreenshot()

//Kondisi Cat
//scroll('Object Repository/Form3/RB Ada baik 13 Kondisi cat', 'Kondisi Cat Body')

//scrollKoorY(1950, 1300)
//SwipeHelper.swipeUp()
adaPerubahan(GlobalVariable.ChkboxKondisiCat, 'Object Repository/Form3/Checkbox perbedaan 13 Kondisi car', 'Object Repository/Form3/Textbox perbedaan 13 Kondisi cat', 
    GlobalVariable.PerbedaanKondisiCat)

kondisiBarang(GlobalVariable.RBKondisiCat, 'Object Repository/Form3/RB Ada baik 13 Kondisi cat', 'Object Repository/Form3/RB Ada rusak 13 Kondisi Cat', 
    'Object Repository/Form3/RB Tidak ada 13 Kondisi cat')

Mobile.takeScreenshot()

Mobile.delay(1)

Mobile.tap(findTestObject('Object Repository/Button next form 2'), 0)

//Next form 4
Mobile.waitForElementPresent(findTestObject('Object Repository/Form4/Button Interior'), 0)

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Form4/Button Interior'), 0)

Mobile.takeScreenshot()

takePhoto('Object Repository/Form4/Upload Interior Belakang')

Mobile.takeScreenshot()

takePhoto('Object Repository/Form4/Upload Interior Depan')

Mobile.takeScreenshot()

takePhoto('Object Repository/Form4/Upload Km Kendaraan')

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Form3/Button save eksterior'), 0)

Mobile.waitForElementPresent(findTestObject('Object Repository/Popup Success'), 0)

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Popup Success'), 0)

//Radio
adaPerubahan(GlobalVariable.ChkboxRadio, 'Object Repository/Form4/Checkbox Perbedaan 1 Radio', 'Object Repository/Form4/Textbox Perbedaan 1 radio', 
    GlobalVariable.PerbedaanRadio)

kondisiBarang(GlobalVariable.RBRadio, 'Object Repository/Form4/RB Ada baik 1 Radio', 'Object Repository/Form4/RB Ada rusak 1 Radio', 
    'Object Repository/Form4/RB Tidak ada 1 Radio')

Mobile.takeScreenshot()

//AC
scroll('Object Repository/Form4/RB Ada baik 2 AC', 'AC')

adaPerubahan(GlobalVariable.ChkboxAC, 'Object Repository/Form4/Checkbox Perbedaan 2 AC', 'Object Repository/Form4/Textbox Perbedaan 2 AC', 
    GlobalVariable.PerbedaanAC)

kondisiBarang(GlobalVariable.RBAC, 'Object Repository/Form4/RB Ada baik 2 AC', 'Object Repository/Form4/RB Ada rusak 2 AC', 
    'Object Repository/Form4/RB TIdak ada 2 AC')

Mobile.takeScreenshot()

if ((GlobalVariable.RBAC == 1) || (GlobalVariable.RBAC == 2)) {
    tipe(GlobalVariable.RBtipeAC, 'Object Repository/Form4/Tipe 1 single AC', 'Object Repository/Form4/Tipe 2 Double AC')
}

Mobile.takeScreenshot()

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//Kaca Spion Dalam
scroll('Object Repository/Form4/RB Ada baik 3 Spion dlm', 'Kaca Spion Dalam')

adaPerubahan(GlobalVariable.ChkboxSpionDlm, 'Object Repository/Form4/Checkbox Perbedaan 3 Spion Dalam', 'Object Repository/Form4/Textbox Perbedaan 3 Spion dlm', 
    GlobalVariable.PerbedaanSpionDlm)

kondisiBarang(GlobalVariable.RBSpionDlm, 'Object Repository/Form4/RB Ada baik 3 Spion dlm', 'Object Repository/Form4/RB Ada rusak 3 Spion dlm', 
    'Object Repository/Form4/RB Tidak ada 3 Spion dlm')

Mobile.takeScreenshot()

//Power Window
//scroll('Object Repository/Form4/RB Ada baik 4 Power window', 'Power window')
SwipeHelper.swipeUp()

//scrollKoorY(1400, 1200)
adaPerubahan(GlobalVariable.ChkboxPwrWndw, 'Object Repository/Form4/Checkbox Perbedaan 4 PowerWindow', 'Object Repository/Form4/Textbox perbedaan 4 power window', 
    GlobalVariable.PerbedaanPwrWndw)

kondisiBarang(GlobalVariable.RBPwrWndw, 'Object Repository/Form4/RB Ada baik 4 Power window', 'Object Repository/Form4/RB ada rusak 4 Power window', 
    'Object Repository/Form4/RB tidak ada 4 power window')

Mobile.takeScreenshot()

//Cental Lock
scroll('Object Repository/Form4/RB Ada baik 5 Central Lock', 'Central lock')

adaPerubahan(GlobalVariable.ChkboxCentralLock, 'Object Repository/Form4/Checkbox perbedaan 5 Central Lock', 'Object Repository/Form4/Textbox perbedaan 5 Central Lock', 
    GlobalVariable.PerbedaanCentralLock)

kondisiBarang(GlobalVariable.RBCentralLock, 'Object Repository/Form4/RB Ada baik 5 Central Lock', 'Object Repository/Form4/RB Ada rusak 5 Cental Lock', 
    'Object Repository/Form4/RB Tidak ada 5 Central lock')

Mobile.takeScreenshot()

//Kursi
scroll('Object Repository/Form4/RB Ada baik 6 Kursi', 'Kursi Mobil')

adaPerubahan(GlobalVariable.ChkboxKursi, 'Object Repository/Form4/Checkbox perbedaan 6 Kursi', 'Object Repository/Form4/Textbox perbedaan 6 kursi', 
    GlobalVariable.PerbedaanKursi)

kondisiBarang(GlobalVariable.RBKursi, 'Object Repository/Form4/RB Ada baik 6 Kursi', 'Object Repository/Form4/RB ada rusak 6 Kursi', 
    'Object Repository/Form4/RB tidak ada 6 kursi')

Mobile.takeScreenshot()

if ((GlobalVariable.RBKursi == 1) || (GlobalVariable.RBKursi == 2)) {
//    scrollKoorY(1073, 811)
	SwipeHelper.swipeUp()
	

//    inputNumber('Object Repository/Form4/Textbox Jumlah Kursi', GlobalVariable.JumlahKursi)
	Mobile.waitForElementPresent(findTestObject('Object Repository/Form4/Textbox Jumlah Kursi'), 20)
	Mobile.tap(findTestObject("Object Repository/Form4/Textbox Jumlah Kursi"), 10)
	Mobile.clearText(findTestObject("Object Repository/Form4/Textbox Jumlah Kursi"), 0)
//	AndroidDriver<?> driver = (AndroidDriver<?>) MobileDriverFactory.getDriver()
	driver.getKeyboard().pressKey(GlobalVariable.JumlahKursi.toString())
	Mobile.hideKeyboard()
		
    Mobile.takeScreenshot()
}

//karpet
//scroll('Object Repository/Form4/RB ada baik 7 karpet', 'Karpet')
SwipeHelper.swipeUp2()

adaPerubahan(GlobalVariable.ChkboxKarpet, 'Object Repository/Form4/Checkbox perbedaan 7 karpet', 'Object Repository/Form4/Textbox perbedaan 7 karpet', 
    GlobalVariable.PerbedaanKarpet)

kondisiBarang(GlobalVariable.RBKarpet, 'Object Repository/Form4/RB ada baik 7 karpet', 'Object Repository/Form4/RB ada rusak 7 karpet', 
    'Object Repository/Form4/RB Tidak ada 7 Karpet')

Mobile.takeScreenshot()

if ((GlobalVariable.RBKarpet == 1) || (GlobalVariable.RBKarpet == 2)) {
    tipe(GlobalVariable.RBTipeKarpet, 'Object Repository/Form4/Tipe 1 Standar Karpet', 'Object Repository/Form4/Tipe 2 Tambahan karpet')

    Mobile.takeScreenshot()

//    scrollKoorY(1073, 711)
	SwipeHelper.swipeUp()
//    inputNumber('Object Repository/Form4/Jumlah karpet', GlobalVariable.JumlahKarpet)
	Mobile.waitForElementPresent(findTestObject('Object Repository/Form4/Jumlah karpet'), 20)
	Mobile.tap(findTestObject("Object Repository/Form4/Jumlah karpet"), 10)
	Mobile.clearText(findTestObject("Object Repository/Form4/Jumlah karpet"), 0)
//	AndroidDriver<?> driver = (AndroidDriver<?>) MobileDriverFactory.getDriver()
	driver.getKeyboard().pressKey(GlobalVariable.JumlahKarpet.toString())
	Mobile.hideKeyboard()
	
    Mobile.takeScreenshot()
}

//Tang
//scroll('Object Repository/Form4/RB ada Baik 8 Tang', 'Tang')
SwipeHelper.swipeUp2()

adaPerubahan(GlobalVariable.ChkboxTang, 'Object Repository/Form4/Checkbox perbedaan 8 Tang', 'Object Repository/Form4/Textbox perbedaan 8 Tang', 
    GlobalVariable.PerbedaanTang)

kondisiBarang(GlobalVariable.RBTang, 'Object Repository/Form4/RB ada Baik 8 Tang', 'Object Repository/Form4/RB Ada Rusak 8 Tang', 
    'Object Repository/Form4/RB Tidak ada 8 Tang')

Mobile.takeScreenshot()

//Obeng
//scroll('Object Repository/Form4/RB Ada baik 9 Obeng', 'Obeng')
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxObeng, 'Object Repository/Form4/Checkbox Perbedaan 9 Obeng', 'Object Repository/Form4/Textbox perbedaan 9 Obeng', 
    GlobalVariable.PerbedaanObeng)

kondisiBarang(GlobalVariable.RBObeng, 'Object Repository/Form4/RB Ada baik 9 Obeng', 'Object Repository/Form4/RB Ada rusak 9 Obeng', 
    'Object Repository/Form4/RB Tidak ada 9 Obeng')

Mobile.takeScreenshot()

//Kunci pass
//scroll('Object Repository/Form4/RB ada baik 10 Kunci pas', 'AC')
SwipeHelper.swipeUp2()
//scroll('Object Repository/Form4/RB ada baik 10 Kunci pas', 'Kunci Pas')
SwipeHelper.swipeUp2()

adaPerubahan(GlobalVariable.ChkboxKunciPas, 'Object Repository/Form4/Checkbox Perbedaan 10 KunciPas', 'Object Repository/Form4/Textbox perbedaan 10 kunci pas', 
    GlobalVariable.PerbedaanKunciPas)

kondisiBarang(GlobalVariable.RBKunciPas, 'Object Repository/Form4/RB ada baik 10 Kunci pas', 'Object Repository/Form4/RB Ada rusak 10 Kunci pas', 
    'Object Repository/Form4/RB Tidak ada 10 Kunci pas')

Mobile.takeScreenshot()

//KunciBan
//scroll('Object Repository/Form4/RB Ada baik 11 Kunci Ban', 'Kunci Ban')
SwipeHelper.swipeUp2()

adaPerubahan(GlobalVariable.ChkboxKunciBan, 'Object Repository/Form4/Checkbox perbedaan 11 Kunci Ban', 'Object Repository/Form4/Textbox perbedaan 11 kunci Ban', 
    GlobalVariable.PerbedaanKunciBan)

kondisiBarang(GlobalVariable.RBKunciBan, 'Object Repository/Form4/RB Ada baik 11 Kunci Ban', 'Object Repository/Form4/RB ada rusak 11 Kunci ban', 
    'Object Repository/Form4/RB Tidak ada 11 Kunci ban')

Mobile.takeScreenshot()

//Dongkrak
//scroll('Object Repository/Form4/RB ada baik 12 Dongkrak', 'Dongkrak & Handle')
SwipeHelper.swipeUp2()

//scrollKoorY(1950, 1600)
adaPerubahan(GlobalVariable.ChkboxDongkrak, 'Object Repository/Form4/Checkbox perbedaan 12 Dongkrak', 'Object Repository/Form4/TextBox perbedaan 12 dongkrak', 
    GlobalVariable.PerbedaanDongkrak)

kondisiBarang(GlobalVariable.RBDongkrak, 'Object Repository/Form4/RB ada baik 12 Dongkrak', 'Object Repository/Form4/RB ada rusak 12 Dongkrak', 
    'Object Repository/Form4/RB tidak ada 12 Dongkrak')

Mobile.takeScreenshot()

//SegitigaPngmn
//scroll('Object Repository/Form4/RB ada baik 12 Dongkrak', 'Segitiga Pengaman')
SwipeHelper.swipeUp2()
//scrollKoorY(1950, 1600)

adaPerubahan(GlobalVariable.ChkboxSegitiga, 'Object Repository/Form4/Checkbox perbedaan 13 Sgtg', 'Object Repository/Form4/Textbox Perbedaan 13 stg', 
    GlobalVariable.PerbedaanSegitiga)

kondisiBarang(GlobalVariable.RBSegitiga, 'Object Repository/Form4/RB ada baik 13 Stg', 'Object Repository/Form4/RB ada rusak 13 stg', 
    'Object Repository/Form4/RB Tidak ada 13 Stg')

Mobile.takeScreenshot()

//Barang konsumen
//scrollKoorY(1073, 911)
SwipeHelper.swipeUp2()
adaPerubahan(GlobalVariable.ChkboxBarangKnsmn, 'Object Repository/Form4/Checkbox perbedaan 14 Barang Knsmn', 'Object Repository/Form4/Textbox Perbedaan 14 Barang knsmn', 
    GlobalVariable.PerbedaanBarangKnsmn)

kondisiBarang(GlobalVariable.RBBarangKnsmn, 'Object Repository/Form4/RB ada baik 14 Barang knsmn', 'Object Repository/Form4/RB ada rusak 14 Barang knsmn', 
    'Object Repository/Form4/RB tidak ada 14 barang knsmn')

Mobile.takeScreenshot()

//scrollKoorY(1073, 511)
SwipeHelper.swipeUp2()

if ((GlobalVariable.RBBarangKnsmn == 1) || (GlobalVariable.RBBarangKnsmn == 2)) {
    Mobile.setText(findTestObject('Object Repository/Form4/Textboxt Deskripsi barang knsmsn'), GlobalVariable.DeskripsiBrgKnsmn, 
        0)

    Mobile.hideKeyboard()

    Mobile.takeScreenshot()

    takePhoto('Object Repository/Form4/Upload barang knsmn')

    Mobile.takeScreenshot()
}

Mobile.tap(findTestObject('Object Repository/Button next form 2'), 0)

//Next form 5
Mobile.waitForElementPresent(findTestObject('Object Repository/Form5/Button upload kondisi Kendaraan'), 0)

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Form5/Button upload kondisi Kendaraan'), 0)

Mobile.takeScreenshot()

takePhoto('Object Repository/Form5/Upload Gesekan Mesin')

Mobile.takeScreenshot()

takePhoto('Object Repository/Form5/Upload Gesekan Rangka')

Mobile.takeScreenshot()

takePhoto('Object Repository/Form5/Upload Mesin kendaraan')

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Form3/Button save eksterior'), 0)

Mobile.waitForElementPresent(findTestObject('Object Repository/Popup Success'), 0)

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Popup Success'), 0)

//Mesin
adaPerubahan(GlobalVariable.ChkboxMesin, 'Object Repository/Form5/Checkbox perbedaan 1 Mesin', 'Object Repository/Form5/Textbox perbedaan 1 Mesin', 
    GlobalVariable.PerbedaanMesin)

kondisiBarang(GlobalVariable.RBMesin, 'Object Repository/Form5/RB ada baik 1 Mesin', 'Object Repository/Form5/RB ada rusak 1 mesin', 
    'Object Repository/Form5/RB tidak baik 1 Mesin')

Mobile.takeScreenshot()

//Accu
adaPerubahan(GlobalVariable.ChkboxAccu, 'Object Repository/Form5/Checkbox Perbedaan 2 Accu', 'Object Repository/Form5/Textbox perbedaan 2 accu', 
    GlobalVariable.PerbedaanAccu)

kondisiBarang(GlobalVariable.RBAccu, 'Object Repository/Form5/RB ada baik 2 Accu', 'Object Repository/Form5/RB ada rusak 2 accu', 
    'Object Repository/Form5/RB tidak ada 2 accu')

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Button next form 2'), 0)

//Next form 6
Mobile.waitForElementPresent(findTestObject('Object Repository/Form6/Textbox kelengkapan Kendaraan'), 0)

Mobile.takeScreenshot()

Mobile.setText(findTestObject('Object Repository/Form6/Textbox kelengkapan Kendaraan'), GlobalVariable.KelengkapanKendaraan, 
    0)

Mobile.takeScreenshot()

Mobile.hideKeyboard()

Mobile.tap(findTestObject('Object Repository/Form6/Upload foro kerusakan', [('Upload') : '1']), 0)

Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

//Mobile.tapAtPosition(545, 2000)
SwipeHelper.swipeUp2()
Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

//Mobile.tapAtPosition(765, 2180)
SwipeHelper.swipeUp2()
Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

Mobile.takeScreenshot()

if (GlobalVariable.fotoKerusakan > 1) {
    for (int j = 1; j < GlobalVariable.fotoKerusakan; j++) {
        int k = j + 1

        String tambah = k.toString()

        Mobile.tap(findTestObject('Object Repository/Form6/Button Tambah Upload'), 0)

        if (Mobile.verifyElementNotVisible(findTestObject('Object Repository/Form6/Upload foro kerusakan', [('Upload') : tambah]), 
            5, FailureHandling.OPTIONAL) == true) {
//            scrollKoorY(1073, 711)
			SwipeHelper.swipeUp()
        }
        
        println(tambah)

        Mobile.tap(findTestObject('Object Repository/Form6/Upload foro kerusakan', [('Upload') : tambah]), 0)

        Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

//        Mobile.tapAtPosition(545, 2000)
		SwipeHelper.swipeUp2()
		
		
        Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

//        Mobile.tapAtPosition(765, 2180)		
		SwipeHelper.swipeUp2()
		
        Mobile.takeScreenshot()
    }
}

Mobile.delay(1, FailureHandling.STOP_ON_FAILURE)

//scrollKoorY(1073, 511)
SwipeHelper.swipeUp()
Mobile.setText(findTestObject('Object Repository/Form6/Textbox Keterangan kerusakan'), GlobalVariable.KeteranganRusak, 0)

Mobile.hideKeyboard()

Mobile.takeScreenshot()

Mobile.tap(findTestObject('Object Repository/Button next form 2'), 0)

//Next form 7
Mobile.waitForElementPresent(findTestObject('Object Repository/Form7/Upload BASt'), 0)

takePhoto('Object Repository/Form7/Upload BASt')

Mobile.takeScreenshot( //Mobile.tap(findTestObject('Object Repository/Form7/android.widget.TextView - Submit'), 0)
    ) //    Mobile.tapAtPosition(812, 2135)

Mobile.checkElement(findTestObject(null), 0)

Mobile.checkElement(findTestObject(null), 0)

//def adaPerubahan(boolean isChecked, String checkBox, String textBox, String isi) {
//    if (isChecked) {
//        Mobile.tap(findTestObject(checkBox), 0)
//
//        String teks = findTestObject(textBox).findPropertyValue('xpath')
//
//        TestObject pengisian = new TestObject().addProperty('xpath', ConditionType.EQUALS, teks)
//
//        Mobile.setText(findTestObject(textBox), isi, 0)
//
//        Mobile.hideKeyboard()
//    }
//}

def adaPerubahan(boolean isChecked, String checkBox, String textBox, String isi) {
	if (isChecked) {
		// tap checkbox
		Mobile.tap(findTestObject(checkBox), 0)

		// isi text di textbox
		Mobile.setText(findTestObject(textBox), isi, 0)

		// sembunyikan keyboard
		Mobile.hideKeyboard()
	}
}



//def takePhoto(String pathPhoto) {
//    Mobile.tap(findTestObject(pathPhoto), 0)
//
//    Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)
//
//    Mobile.tapAtPosition(545, 2000)
//
//    Mobile.delay(5, FailureHandling.STOP_ON_FAILURE)
//
//    Mobile.tap(findTestObject('Object Repository/Form2/Tombol_OK'), 0)
//}

def takePhoto(String pathPhoto) {
	Mobile.waitForElementPresent(findTestObject(pathPhoto), 20)
	Mobile.tap(findTestObject(pathPhoto), 0)

	Mobile.delay(2)

	int deviceHeight = Mobile.getDeviceHeight()
	int deviceWidth = Mobile.getDeviceWidth()
	int x = deviceWidth / 2
	int y = deviceHeight * 90 / 100

	// pakai W3C Actions API
	AppiumDriver<?> driver = MobileDriverFactory.getDriver()
	PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger")
	Sequence tap = new Sequence(finger, 1)
	tap.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), x, y))
	tap.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	tap.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))
	driver.perform(Arrays.asList(tap))

	Mobile.delay(3)

	if (Mobile.waitForElementPresent(findTestObject('Object Repository/Form2/Tombol_OK'), 10, FailureHandling.OPTIONAL)) {
		Mobile.tap(findTestObject('Object Repository/Form2/Tombol_OK'), 0)
		
		Mobile.delay(2)
		
		// Membuat Test Object baru secara dinamis
		TestObject tombolCentang = new TestObject("tombolCentangKamera")
		tombolCentang.addProperty("xpath", ConditionType.EQUALS, "//android.widget.ImageView[@resource-id='com.transsion.camera:id/btn_shutter_panel_camera_switcher']")
		
		// Menunggu elemen tombol centang muncul
		Mobile.waitForElementPresent(tombolCentang, 10)
		
		// Menekan tombol centang
		Mobile.tap(tombolCentang, 0)				
	} else {
		KeywordUtil.markFailed("Tombol OK tidak ditemukan setelah ambil foto")
	}
}

def inputNumber(String pathNumber, String isiNumber) {
    Mobile.tap(findTestObject(pathNumber), 0)

    for (int j = 0; j < isiNumber.length(); j++) {
        int digit = Character.getNumericValue(isiNumber.charAt(j))

        Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

        switch (digit) {
            case 1:
                Mobile.tapAtPosition(160, 1620)

                Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

                break
            case 2:
                Mobile.tapAtPosition(420, 1620)

                Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

                break
            case 3:
                Mobile.tapAtPosition(675, 1620)

                Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

                break
            case 4:
                Mobile.tapAtPosition(160, 1800)

                Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

                break
            case 5:
                Mobile.tapAtPosition(420, 1800)

                Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

                break
            case 6:
                Mobile.tapAtPosition(675, 1800)

                Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

                break
            case 7:
                Mobile.tapAtPosition(160, 1980)

                Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

                break
            case 8:
                Mobile.tapAtPosition(420, 1980)

                Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

                break
            case 9:
                Mobile.tapAtPosition(675, 1980)

                Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

                break
            case 0:
                Mobile.tapAtPosition(420, 2160)

                Mobile.delay(2, FailureHandling.STOP_ON_FAILURE)

                break
        }
    }
    
    Mobile.hideKeyboard()
}

//def kondisiBarang(int radioButton, String tipe1, String tipe2, String tipe3) {
//    switch (radioButton) {
//        case 1:
//            Mobile.tap(findTestObject(tipe1), 0)
//
//            Mobile.delay(2, FailureHandling.CONTINUE_ON_FAILURE)
//
//            break
//        case 2:
//            Mobile.tap(findTestObject(tipe2), 0)
//
//            Mobile.delay(2, FailureHandling.CONTINUE_ON_FAILURE)
//
//            break
//        case 3:
//            Mobile.tap(findTestObject(tipe3), 0)
//
//            Mobile.delay(2, FailureHandling.CONTINUE_ON_FAILURE)
//
//            break
//    }
//}

def kondisiBarang(int radioButton, String tipe1, String tipe2, String tipe3) {
	String selectedObjPath = ""
	switch (radioButton) {
		case 1:
			selectedObjPath = tipe1
			break
		case 2:
			selectedObjPath = tipe2
			break
		case 3:
			selectedObjPath = tipe3
			break
		default:
			KeywordUtil.logInfo("Radio button value tidak valid: " + radioButton)
			return
	}

	TestObject obj = findTestObject(selectedObjPath)
	if (Mobile.waitForElementPresent(obj, 10, FailureHandling.OPTIONAL)) {
		Mobile.tap(obj, 0)
		Mobile.delay(2, FailureHandling.CONTINUE_ON_FAILURE)
	} else {
		KeywordUtil.markFailed("Element tidak ditemukan: " + selectedObjPath)
	}
}


def datePicker(String tgl, String bln, String thn) {
    while (true) {
        println(tgl)

        println(bln)

        println(thn)

        TestObject kata = new TestObject().addProperty('xpath', ConditionType.EQUALS, '//hierarchy/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.DatePicker[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[2]')

        String cekData = Mobile.getText(kata, 0)

        println(cekData)

        if (cekData.contains(bln)) {
            break
        } else {
//            Mobile.tap(findTestObject('Object Repository/Prev Month'), 0)
			Mobile.tap(findTestObject('Prev Month'), 0)

            TestObject tanggal = new TestObject().addProperty('xpath', ConditionType.EQUALS, ('//hierarchy/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.DatePicker[1]/android.widget.LinearLayout[1]/android.widget.ScrollView[1]/android.widget.ViewAnimator[1]/android.view.ViewGroup[1]/com.android.internal.widget.ViewPager[1]/android.view.View[1]/android.view.View[contains(@text, "' + 
                tgl) + '")]')

            Mobile.tap(tanggal, 0)
        }
    }
    
    TestObject DrpDwnTahun = new TestObject().addProperty('xpath', ConditionType.EQUALS, '//hierarchy/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.DatePicker[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]')

    Mobile.tap(DrpDwnTahun, 0)

    TestObject Tahun = new TestObject().addProperty('xpath', ConditionType.EQUALS, ('//hierarchy/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.DatePicker[1]/android.widget.LinearLayout[1]/android.widget.ScrollView[1]/android.widget.ViewAnimator[1]/android.widget.ListView[1]/android.widget.TextView[contains(@text, "' + 
        thn) + '")]')

    Mobile.tap(Tahun, 0)

    Mobile.tap(findTestObject('Object Repository/Submit Datepicker'), 0)
	// setelah pilih tanggal → cek popup
	handlePopupOk()
}


//// Helper: normalisasi bulan ke format Indonesia
//String normalizeMonth(String raw) {
//	Map<String, String> monthMap = [
//		"Jan": "Januari", "January": "Januari", "Januari": "Januari",
//		"Feb": "Februari", "February": "Februari", "Februari": "Februari",
//		"Mar": "Maret", "March": "Maret", "Maret": "Maret",
//		"Apr": "April", "April": "April",
//		"May": "Mei", "Mei": "Mei",
//		"Jun": "Juni", "June": "Juni", "Juni": "Juni",
//		"Jul": "Juli", "July": "Juli", "Juli": "Juli",
//		"Aug": "Agustus", "August": "Agustus", "Agustus": "Agustus",
//		"Sep": "September", "September": "September",
//		"Oct": "Oktober", "October": "Oktober", "Oktober": "Oktober",
//		"Nov": "November", "November": "November",
//		"Dec": "Desember", "December": "Desember", "Desember": "Desember"
//	]
//	String safeKey = raw?.trim()?.capitalize()
//	return monthMap.get(safeKey, raw)
//}
//
//def datePicker(String tgl, String bln, String thn) {
//	// Normalisasi bulan target
//	bln = normalizeMonth(bln.trim())
//
//	List<String> bulanList = [
//		"Januari","Februari","Maret","April","Mei","Juni",
//		"Juli","Agustus","September","Oktober","November","Desember"
//	]
//
//	// === Dynamic object untuk header bulan ===
//	TestObject bulanHeader = new TestObject("bulanHeader")
//	bulanHeader.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.DatePicker//android.widget.LinearLayout/android.widget.TextView[2]")
//
//	// === Dynamic object tombol navigasi (Prev / Next) ===
//	TestObject prevBtn = new TestObject("prevBtn")
//	prevBtn.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.ImageButton[@content-desc='Previous month']")
//	prevBtn.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.ImageButton[@content-desc='Bulan sebelumnya']", true)
//	prevBtn.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.ImageButton[@resource-id='android:id/prev']", true)
//
//	TestObject nextBtn = new TestObject("nextBtn")
//	nextBtn.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.ImageButton[@content-desc='Next month']")
//	nextBtn.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.ImageButton[@content-desc='Bulan berikutnya']", true)
//	nextBtn.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.ImageButton[@resource-id='android:id/next']", true)
//
//	// === Dynamic object submit (OK button) ===
//	TestObject submitBtn = new TestObject("submitBtn")
//	submitBtn.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.Button[@text='OK']")
//	submitBtn.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.Button[@text='Pilih']", true)
//	submitBtn.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.Button[@resource-id='android:id/button1']", true)
//
//	// Loop navigasi bulan/tahun
//	int maxRetry = 36
//	while (maxRetry > 0) {
//		Mobile.waitForElementPresent(bulanHeader, 5)
//		String cekData = Mobile.getText(bulanHeader, 0)
//		println("📅 Bulan sekarang: " + cekData)
//
//		String[] parts = cekData.split(" ")
//		String bulanNow = normalizeMonth(parts[0].trim())
//		String tahunNow = parts.size() > 1 ? parts[1].trim() : thn
//
//		int tahunSekarang
//		try {
//			tahunSekarang = tahunNow.toInteger()
//		} catch (Exception e) {
//			tahunSekarang = thn.toInteger()
//		}
//
//		// ✅ Cek sudah sesuai target
//		if (bulanNow.equalsIgnoreCase(bln) && tahunSekarang == thn.toInteger()) {
//			println("✅ Sudah di bulan & tahun target: " + bulanNow + " " + tahunSekarang)
//			break
//		}
//
//		// Tentukan arah navigasi
//		int idxTarget = bulanList.indexOf(bln)
//		int idxNow = bulanList.indexOf(bulanNow)
//
//		if (tahunSekarang > thn.toInteger() ||
//		   (tahunSekarang == thn.toInteger() && idxNow > idxTarget)) {
//			Mobile.tap(prevBtn, 0)
//		} else {
//			Mobile.tap(nextBtn, 0)
//		}
//		maxRetry--
//	}
//
//	if (maxRetry == 0) {
//		KeywordUtil.markFailed("❌ Gagal menemukan bulan " + bln + " " + thn)
//	}
//
//	// Pilih tanggal (dynamic juga)
//	TestObject tanggal = new TestObject("tanggal")
//	tanggal.addProperty("xpath", ConditionType.EQUALS,
//		"//android.widget.DatePicker//android.view.View[@text='" + tgl + "']")
//
//	Mobile.waitForElementPresent(tanggal, 5)
//	Mobile.tap(tanggal, 0)
//
//	// Submit
//	Mobile.tap(submitBtn, 0)
//}


def scroll(String dicari, String menuju) {
    if (Mobile.verifyElementNotVisible(findTestObject(dicari), 5, FailureHandling.OPTIONAL) == true) {
        Mobile.scrollToText(menuju)
    }
}

def scrollKoorY(int y1, int y2) {
    AndroidDriver<?> driver = MobileDriverFactory.getDriver()

    TouchAction action = new TouchAction(driver)

    action.press(PointOption.point(500, y1)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).moveTo(PointOption.point(
            500, y2)).release().perform()
}

def tipe(int type, String tipeA, String tipeB) {
    switch (type) {
        case 1:
            Mobile.tap(findTestObject(tipeA), 0)

            break
        case 2:
            Mobile.tap(findTestObject(tipeB), 0)

            break
    }
}


def setSliderPercent(TestObject slider, int percent) {
	AppiumDriver<?> driverApp = MobileDriverFactory.getDriver()

	// Tunggu sampai slider ada
	Mobile.waitForElementPresent(slider, 20)

	// Cari elemen slider
	MobileElement sliderElement = (MobileElement) MobileElementCommonHelper.findElement(slider, 20)
	
	int startX = sliderElement.getLocation().getX()
	int elementWidth = sliderElement.getSize().getWidth()
	int yAxis = sliderElement.getLocation().getY() + (sliderElement.getSize().getHeight() / 2)

	int moveToX = startX + (elementWidth * percent / 100)

	// Buat "finger" untuk tap & geser
	PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger")
	Sequence swipe = new Sequence(finger, 1)

	// Tekan di start
	swipe.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), startX, yAxis))
	swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))

	// Geser ke target
	swipe.addAction(finger.createPointerMove(Duration.ofMillis(1000), PointerInput.Origin.viewport(), moveToX, yAxis))

	// Lepaskan
	swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))

	// Jalankan aksi
	driverApp.perform(Arrays.asList(swipe))
}

def handlePopupOk() {
	TestObject btnOkPopup = new TestObject('dynamicOkPopup')
	btnOkPopup.addProperty("class", ConditionType.EQUALS, "android.widget.TextView")
	btnOkPopup.addProperty("text", ConditionType.EQUALS, "OK")
	btnOkPopup.addProperty("resource-id", ConditionType.EQUALS, "com.indocyber.bcaf:id/okDialogButton")

	if (Mobile.waitForElementPresent(btnOkPopup, 5, FailureHandling.OPTIONAL)) {
		Mobile.tap(btnOkPopup, 0)
		println("Popup Info muncul → sudah tap OK")
	} else {
		println("Tidak ada popup Info")
	}
}

