from selenium import webdriver
from selenium.webdriver.chrome.options import Options

def start_browser():
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--ignore-certificate-errors")     # ⬅️ penting: abaikan error SSL
    options.add_argument("--allow-insecure-localhost")      # ⬅️ untuk localhost https
    options.add_argument("--disable-web-security")          # opsional: jika error CORS
    options.add_argument("--no-sandbox")                    # stabilisasi (terutama Linux/WSL)
    options.add_argument("--disable-dev-shm-usage")         # stabilisasi memory
    prefs = {"profile.managed_default_content_settings.images": 2}
    options.add_experimental_option("prefs", prefs)
    driver = webdriver.Chrome(options=options)
    return driver


