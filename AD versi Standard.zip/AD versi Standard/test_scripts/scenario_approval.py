import sys
import os
import time
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utils.logger import log_message
from datetime import datetime

def scenario_approval(driver, app_id):
    def klik(xpath, nama_aksi="klik", app_id=None):
        try:
            element = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, xpath))
            )
            element.click()

            # Screenshot per aksi
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            folder = os.path.join("screenshots", str(app_id) if app_id else "general")
            os.makedirs(folder, exist_ok=True)
            fname = f"screenshot_{nama_aksi}_{timestamp}.png"
            driver.save_screenshot(os.path.join(folder, fname))
        except Exception as e:
            # Screenshot jika gagal
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            folder = os.path.join("screenshots", str(app_id) if app_id else "general")
            os.makedirs(folder, exist_ok=True)
            fname = f"error_klik_{nama_aksi}_{timestamp}.png"
            driver.save_screenshot(os.path.join(folder, fname))
            raise

    try:
        wait = WebDriverWait(driver, 30)

        # Klik tombol Proceed
        klik("//button[@aria-label='Proceed Button' and .//span[text()='Proceed']]", nama_aksi="klik_proceed", app_id=app_id)

        log_message(f"Sukses approval untuk App ID: {app_id}")
        print(f"Sukses approval untuk App ID: {app_id}")

    except Exception as e:
        log_message(f"Gagal approval untuk App ID: {app_id} | Error: {str(e)}")
        print(f"Gagal approval untuk App ID: {app_id} | Error: {str(e)}")