from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utils.logger import log_message
from datetime import datetime
import time
import os

def scenario_reject(driver, app_id, alasan):
    def save_screenshot(driver, nama_aksi="aksi", app_id=None, prefix="screenshot"):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        folder = os.path.join("screenshots", str(app_id) if app_id else "general")
        os.makedirs(folder, exist_ok=True)
        fname = f"{prefix}_{nama_aksi}_{timestamp}.png"
        path = os.path.join(folder, fname)
        driver.save_screenshot(path)
        return path
    
    def klik(xpath, nama_aksi="klik"):
        try:
            el = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, xpath)))
            el.click()
            save_screenshot(driver, nama_aksi=nama_aksi, app_id=app_id)
        except Exception as e:
            save_screenshot(driver, nama_aksi=nama_aksi, app_id=app_id, prefix="error")
            raise

    def isi(xpath, value, nama_aksi="isi"):
        try:
            el = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, xpath)))
            el.clear()
            time.sleep(0.5)
            el.send_keys(value)
            save_screenshot(driver, nama_aksi=nama_aksi, app_id=app_id)
        except Exception as e:
            save_screenshot(driver, nama_aksi=nama_aksi, app_id=app_id, prefix="error")
            raise

    try:
        wait = WebDriverWait(driver, 20)

        # Klik tombol Reject
        # klik("//button[@aria-label='Return Button' and .//span[normalize-space(text())='Reject']]")
        klik("//button[@aria-label='Return Button' and .//span[normalize-space(text())='Reject']]", nama_aksi="klik_reject")

        # Isi deskripsi reject
        # isi("//mat-label[normalize-space(text())='Alasan Reject']/ancestor::mat-form-field//textarea",alasan)
        isi("//mat-label[normalize-space(text())='Alasan Reject']/ancestor::mat-form-field//textarea",
            alasan, nama_aksi="isi_alasan_reject")

        time.sleep(2)
        # Submit        
        # klik("//button[@mat-dialog-close and .//span[normalize-space(text())='Reject']]", nama_aksi="klik_submit_reject")
        # diganti tombol cancel dulu utk testing
        # klik("//button[normalize-space(.//span[@class='mdc-button__label'])='Cancel']")
        klik("//button[normalize-space(.//span[@class='mdc-button__label'])='Cancel']", nama_aksi="klik_cancel")
        log_message(f"Berhasil Reject: {app_id}")
        print(f"Berhasil Reject: {app_id} description : {alasan}")

    except Exception as e:
        log_message(f"Gagal Reject: {app_id} | Error: {str(e)}")
        print(f"Gagal Reject: {app_id} | Error: {str(e)}")