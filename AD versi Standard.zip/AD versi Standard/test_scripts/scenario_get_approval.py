import pandas as pd
from openpyxl import load_workbook

def scenario_get_approval(app_id, df_testing, df_kelas, df_limit):
    df_testing['Cabang App'] = df_testing['Cabang App'].astype(str).str.strip().str.upper()
    df_kelas['Nama Cabang'] = df_kelas['Nama Cabang'].astype(str).str.strip().str.upper()
    data_row = df_testing[df_testing["App ID"].astype(str).str.strip() == str(app_id).strip()]
    if data_row.empty:
        return f"[x] App ID {app_id} tidak ditemukan"

    nama_cabang = str(data_row.iloc[0]["Cabang App"]).strip().upper()
    # nilai_pelunasan = float(data_row.iloc[0]["Nilai Pelunasan"])
    nilai_pelunasan = 110000000000
    app_branch = "Cabang"

    # Ambil kelas cabang
    kelas = None
    for _, row in df_kelas.iterrows():
        if row["Nama Cabang"].strip() == nama_cabang:
            kelas = row["Kelas Cabang"].strip().upper()
            break
    if not kelas:
        return f"[!] Kelas Cabang tidak ditemukan untuk cabang '{nama_cabang}'"

    struktur_approval = []
    user_login = []
    mapping_excel = {}

    urutan_jabatan = ["TL", "BOH", "Unit Head", "Dept Head", "DD"] if kelas != "D" else ["BOH", "Unit Head", "Dept Head", "DD"]
    found_upper_limit = False

    for jabatan in urutan_jabatan:
        jabatan_full = f"{jabatan} {kelas}" if jabatan in ["TL", "BOH"] else jabatan

        # Untuk Unit Head ke atas, abaikan APP Branch
        if jabatan in ["Unit Head", "Dept Head", "DD"]:
            row_limit = df_limit[df_limit["Jabatan"].str.strip().str.upper().str.startswith(jabatan.upper())]
        else:
            row_limit = df_limit[
                (df_limit["APP Branch"].str.strip().str.upper() == app_branch.upper()) &
                (df_limit["Jabatan"].str.strip().str.upper() == jabatan_full.upper())
            ]

        if row_limit.empty:
            continue

        limit = float(row_limit.iloc[0]["Limit Approval"])

        if nilai_pelunasan <= limit and not found_upper_limit:
            # ini adalah limit pertama yang lebih tinggi dari pelunasan
            struktur_approval.append(jabatan_full)
            user_login.append({
                "Jabatan": jabatan_full,
                "User ID": str(row_limit.iloc[0].get("User ID", "")).strip(),
                "Password": str(row_limit.iloc[0].get("Password", "")).strip()
            })
            mapping_excel[f"Approval {len(struktur_approval)}"] = jabatan_full
            found_upper_limit = True
        elif nilai_pelunasan > limit:
            # approval di bawah nilai pelunasan tetap masuk
            struktur_approval.append(jabatan_full)
            user_login.append({
                "Jabatan": jabatan_full,
                "User ID": str(row_limit.iloc[0].get("User ID", "")).strip(),
                "Password": str(row_limit.iloc[0].get("Password", "")).strip()
            })
            mapping_excel[f"Approval {len(struktur_approval)}"] = jabatan_full

    return {
        "App ID": app_id,
        "Cabang": nama_cabang,
        "Kelas": kelas,
        "Level": len(struktur_approval) - 1,
        "Struktur Approval": struktur_approval,
        "User Login List": user_login,
        "Mapping Excel": mapping_excel
    }


def get_struktur_approval(kelas_cabang, level, app_branch, df_limit, df_hierarchy):
    jabatan_list = []
    struktur_akun = []
    mapping_excel = {}

    baris = df_hierarchy[
        (df_hierarchy["Level"] == level) & 
        (df_hierarchy["APP Branch"].str.upper() == app_branch.upper())
    ]

    if baris.empty:
        raise Exception(f"[x] Tidak ditemukan struktur approval untuk Level {level} dan APP Branch '{app_branch}'")

    baris = baris.iloc[0]

    for i in range(1, 7):
        jabatan = baris.get(f"Approve{i}")
        if pd.isna(jabatan):
            continue

        jabatan_full = jabatan.strip()

        if jabatan_full not in ["TL KP", "Unit Head", "Dept Head", "Dep Head", "DD"]:
            jabatan_full += f" {kelas_cabang}"

        jabatan_list.append(jabatan_full)
        mapping_excel[f"Approval {i}"] = jabatan_full

        akun = df_limit[
            (df_limit["Jabatan"].str.upper() == jabatan_full.upper()) &
            (df_limit["APP Branch"].str.upper() == app_branch.upper())
        ]

        if not akun.empty:
            akun_row = akun.iloc[0]
            struktur_akun.append({
                "jabatan": jabatan_full,
                "user_id": akun_row["User ID"],
                "password": akun_row["Password"]
            })
        else:
            struktur_akun.append({
                "jabatan": jabatan_full,
                "user_id": None,
                "password": None
            })

    return struktur_akun, mapping_excel

def write_approval_to_excel(app_id, mapping_excel, excel_path="data/template_excel.xlsx"):
    wb = load_workbook(excel_path)
    sheet = wb["Data Testing"]

    headers = {cell.value: idx for idx, cell in enumerate(sheet[1], start=1)}

    found = False
    for row in sheet.iter_rows(min_row=2):
        if str(row[headers["App ID"] - 1].value).strip() == str(app_id).strip():
            for key, val in mapping_excel.items():
                if key in headers:
                    row[headers[key] - 1].value = val
            found = True
            break

    if not found:
        print(f"[x] App ID {app_id} tidak ditemukan saat update approval")
    else:
        print(f"[v] Struktur Approval berhasil ditulis ke Excel untuk App ID {app_id}")

    wb.save(excel_path)
