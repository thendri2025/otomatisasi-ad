from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from datetime import datetime

def log_message(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("log_output.txt", "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {msg}\n")
    print(f"[{timestamp}] {msg}")

def scenario_save(driver, app_id):
    def klik(xpath):
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, xpath))).click()

    try:
        wait = WebDriverWait(driver, 10)
        # Klik tombol Save
        # klik("//button[@aria-label='Pending Button' and .//span[normalize-space(text())='Save']]")
        driver.save_screenshot(f"screenshots/{app_id}_save.png")
        log_message(f"Berhasil Save: {app_id}")
        print(f"Berhasil Save: {app_id}")
    except Exception as e:
        log_message(f"Gagal Save: {app_id} | Error: {str(e)}")
        print(f"Gagal Save: {app_id} | Error: {str(e)}")