import os
import time
from datetime import datetime
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Fungsi logging
def log_message(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("log_output.txt", "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {msg}\n")
    print(f"[{timestamp}] {msg}")

def klik(driver,xpath, nama_aksi="klik", app_id=None):
    element = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, xpath))
    )
    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
    WebDriverWait(driver, 15).until(EC.element_to_be_clickable((By.XPATH, xpath)))
    time.sleep(1)  # kasih waktu buat rendering selesai
    try:
        element.click()
    except:
        driver.execute_script("arguments[0].click();", element)
    
    # Screenshot
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = os.path.join("screenshots", str(app_id) if app_id else "general")
    os.makedirs(folder, exist_ok=True)
    fname = f"screenshot_{nama_aksi}_{timestamp}.png"
    driver.save_screenshot(os.path.join(folder, fname))

def isi(driver,xpath, value, nama_aksi="isi", app_id=None):
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, xpath))).send_keys(value)

    # Screenshot
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = os.path.join("screenshots", str(app_id) if app_id else "general")
    os.makedirs(folder, exist_ok=True)
    fname = f"screenshot_{nama_aksi}_{timestamp}.png"
    driver.save_screenshot(os.path.join(folder, fname))

# Fungsi utama scenario pending
def scenario_pending(driver, app_id, alasan):
    try:
        wait = WebDriverWait(driver, 20)

        # Buat folder screenshots jika belum ada
        if not os.path.exists("screenshots"):
            os.makedirs("screenshots")

        log_message(f"Mulai Pending untuk: {app_id}")

        wait = WebDriverWait(driver, 15)
        pending_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[.='Pending']")))
        
        # Klik tombol Pending
        klik(driver, "//button[@aria-label='Pending Button' and .//span[text()='Pending']]", nama_aksi="klik_pending", app_id=app_id)

        # Isi alasan pending
        isi(driver, "//label[contains(., 'Alasan Pending')]/ancestor::mat-form-field//textarea",
            alasan, nama_aksi="isi_alasan_pending", app_id=app_id)


        # Submit pending
        # klik(driver, "//button[.//span[@class='mdc-button__label' and text()='Pending']]",
        #      nama_aksi="klik_cancel", app_id=app_id)
        # di ganti tombol cancel dulu untuk testing 
        klik(driver, "//button[@type='button' and @mat-dialog-close and contains(@class,'mat-warn')]//span[normalize-space()='Cancel']",
             nama_aksi="klik_cancel", app_id=app_id)

        log_message(f"Berhasil submit Pending untuk: {app_id}")
        print(f"Berhasil submit Pending untuk: {app_id} description : {alasan}")

    except Exception as e:
        screenshot_path = f"screenshots/{app_id}_pending_error.png"
        driver.save_screenshot(screenshot_path)
        log_message(f"Gagal Pending: {app_id} | Error: {str(e)} | Screenshot: {screenshot_path}")
        print(f"Gagal Pending: {app_id} | Error: {str(e)} | Screenshot: {screenshot_path}")