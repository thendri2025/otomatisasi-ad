from selenium import webdriver
from selenium.webdriver.chrome.options import Options

def start_browser():
    options = Options()
    options.add_argument("--start-maximized")
    prefs = {"profile.managed_default_content_settings.images": 2}
    options.add_experimental_option("prefs", prefs)
    driver = webdriver.Chrome(options=options)
    return driver


