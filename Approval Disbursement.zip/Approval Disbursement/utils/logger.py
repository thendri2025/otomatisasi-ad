from datetime import datetime

def log_message(message):
    with open("logs/test_log.txt", "a") as file:
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        file.write(f"[{timestamp}] {message}\n")
