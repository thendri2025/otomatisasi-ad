import openpyxl

def load_excel_data(path):
    wb = openpyxl.load_workbook(path)
    sheet = wb.active
    data = []
    for row in sheet.iter_rows(min_row=2, values_only=True):
        data.append(row)
    return data

def load_excel_sheet_data(path, sheet_name):
    wb = openpyxl.load_workbook(path, data_only=True)
    sheet = wb[sheet_name]
    data = []
    for row in sheet.iter_rows(min_row=2, values_only=True):
        data.append(row)
    return data
