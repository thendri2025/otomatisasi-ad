from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utils.logger import log_message
import time

def scenario_reject(driver, app_id, alasan):
    def klik(xpath):
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, xpath))).click()

    def isi(xpath, value):
            el = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, xpath)))
            el.clear()
            time.sleep(0.5)  # delay untuk kestabilan
            el.send_keys(value)

    try:
        wait = WebDriverWait(driver, 20)

        # Klik tombol Reject
        klik("//button[@aria-label='Return Button' and .//span[normalize-space(text())='Reject']]")
        # Isi deskripsi reject
        isi("//mat-label[normalize-space(text())='Alasan Reject']/ancestor::mat-form-field//textarea",alasan)
        time.sleep(2)
        # Submit
        # wait.until(EC.element_to_be_clickable((By.XPATH, "//button[@mat-dialog-close and .//span[normalize-space(text())='Reject']]"))).click()
        # diganti tombol cancel dulu utk testing
        klik("//button[normalize-space(.//span[@class='mdc-button__label'])='Cancel']")
        driver.save_screenshot(f"screenshots/{app_id}_reject.png")
        log_message(f"Berhasil Reject: {app_id}")
        print(f"Berhasil Reject: {app_id} description : {alasan}")

    except Exception as e:
        log_message(f"Gagal Reject: {app_id} | Error: {str(e)}")
        print(f"Gagal Reject: {app_id} | Error: {str(e)}")