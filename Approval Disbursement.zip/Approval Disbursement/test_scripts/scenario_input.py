import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from config import BASE_URL, USERNAME, PASSWORD, EXCEL_PATH
from utils.browser import start_browser
from utils.excel_reader import load_excel_sheet_data
from test_scripts.scenario_approval import scenario_approval
from test_scripts.scenario_reject import scenario_reject
from test_scripts.scenario_pending import scenario_pending
from test_scripts.scenario_save import scenario_save
from utils.logger import log_message
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import ElementClickInterceptedException
from openpyxl import load_workbook
from datetime import datetime
import time
import pandas as pd
import openpyxl
import pyautogui

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

def scenario_input(driver,p_user_id,p_pwd, p_app_id, p_document_blanko ,p_document_maskapai ,p_document_memo_ca,
                   p_document_simulasi_et,p_alasan_ca):
    def klik(xpath):
            element = WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.XPATH, xpath))
            )
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
            WebDriverWait(driver, 15).until(EC.element_to_be_clickable((By.XPATH, xpath)))
            time.sleep(1)  # kasih waktu buat rendering selesai
            try:
                element.click()
            except:
                driver.execute_script("arguments[0].click();", element)

    def isi(xpath, value):
            WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, xpath))).send_keys(value)

    def scroll(xpath):
            element = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.XPATH, xpath)))
            driver.execute_script("arguments[0].scrollIntoView();", element)
    
    def safe_scroll_and_click(xpath):
        try:
            elems = driver.find_elements(By.XPATH, xpath)
            if elems:
                scroll(xpath)
                klik(xpath)
            else:
                print(f"[SKIP] Elemen tidak ditemukan: {xpath}")
        except Exception as e:
            print(f"[ERROR] Gagal scroll/klik elemen: {xpath} => {e}")
    
    def element_exists(xpath):
        return len(driver.find_elements(By.XPATH, xpath)) > 0

    def upload_dokumen(driver, label_teks, path_file):
        # Pastikan ekstensi .pdf
        if not path_file.lower().endswith('.pdf'):
            path_file += '.pdf'
        path_file = os.path.join("data", path_file)
        abs_path = os.path.abspath(path_file)

        # Validasi apakah file benar-benar ada
        if not os.path.exists(abs_path):
            print(f"[ERROR] File tidak ditemukan: {abs_path}")
            return

        print(f"[INFO] Mulai upload '{label_teks}' dari: {abs_path}")
        # Gunakan XPath yang benar-benar klik tombol upload
        xpath_icon = f"//div[contains(@class,'uploadField') and contains(normalize-space(.),'{label_teks}')]/mat-icon"

        try:
            icon_upload = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, xpath_icon))
            )
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", icon_upload)
            time.sleep(0.2)
            icon_upload.click()
            print(f"[INFO] Klik ikon upload berhasil untuk: {label_teks}")
        except TimeoutException:
            print(f"[ERROR] Tidak bisa menemukan ikon upload untuk: '{label_teks}'")
            return
        except Exception as e:
            print(f"[ERROR] Gagal klik ikon upload: {e}")
            return

        # Kirim path file ke native dialog (pakai pyautogui)
        time.sleep(1.5)  # beri waktu untuk dialog terbuka
        try:
            pyautogui.write(abs_path)
            time.sleep(0.5)
            pyautogui.press('enter')
            print(f"[v] Upload berhasil: {label_teks}")
        except Exception as e:
            print(f"[ERROR] Gagal menulis path file: {e}")

    def pilih_alasan_ca(teks_alasan):
        try:
            xpath_dropdown = "//mat-label[contains(text(), 'Alasan CA')]/ancestor::div[contains(@class,'mat-mdc-form-field')]//mat-select"
            dropdown = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, xpath_dropdown))
            )

            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", dropdown)
            time.sleep(0.3)
            dropdown.click()

            # Jika opsi tidak muncul, bisa jadi karena dropdown gagal membuka
            xpath_opsi = f"//mat-option//span[contains(text(), '{teks_alasan}')]"
            opsi = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, xpath_opsi))
            )
            opsi.click()
            time.sleep(1)
            print(f"[v] Alasan CA dipilih: {teks_alasan}")

        except TimeoutException:
            print(f"[!] Timeout: Dropdown 'Alasan CA' atau opsi '{teks_alasan}' tidak muncul. Lewati proses ini.")
        except ElementClickInterceptedException:
            print(f"[!] Klik terhalang elemen lain saat memilih Alasan CA. Lewati proses ini.")
        except Exception as e:
            print(f"[!] Dropdown 'Alasan CA' gagal: {e}. Lewati proses ini.")

    def upload_if_exists(label_teks, filename):
        if filename:
            if not filename.lower().endswith('.pdf'):
                filename += '.pdf'
            path_file = os.path.join("data", filename)
            if os.path.exists(path_file):
                try:
                    if driver.session_id:
                        upload_dokumen(driver,label_teks, filename)
                except Exception as e:
                    print(f"[ERROR] Gagal upload_dokumen {label_teks}: {e}")
            else:
                print(f"[WARNING] File tidak ditemukan: {path_file}")

    def write_approval_on_double_click(
        excel_path,
        app_id,
        nama_konsumen,
        no_kontrak,
        nilai_pelunasan,
        tanggal_masuk,
        cabang_app,
        dokumen_upload):

        import unicodedata
        # Fungsi bantu untuk membersihkan teks header
        def normalize_text(text):
            if text is None:
                return ""
            return unicodedata.normalize("NFKD", str(text)).strip().replace("\xa0", " ")

        # Pastikan ekstensi .xlsx
        if not excel_path.lower().endswith('.xlsx'):
            excel_path += '.xlsx'
        excel_path = os.path.join("data", excel_path)
        abs_path = os.path.abspath(excel_path)
        print(f"[INFO] Path File Excel : {abs_path}")

        # Validasi apakah file benar-benar ada
        if not os.path.exists(abs_path):
            print(f"[ERROR] File tidak ditemukan: {abs_path}")
            return

        wb = openpyxl.load_workbook(abs_path)
        sheet = wb["Data Testing"]

        # Ambil posisi kolom berdasarkan header dengan normalisasi
        headers = {normalize_text(cell.value): idx for idx, cell in enumerate(sheet[1], start=1)}

        # Pastikan semua kolom yang dibutuhkan ada
        required_fields = [
            "App ID", "Nama Konsumen", "No Kontrak", 
            "Nilai Pelunasan", "Tanggal Masuk", "Cabang App", "Dokumen Uploaded"
        ]
        for field in required_fields:
            if field not in headers:
                raise Exception(f"[ERROR] Kolom '{field}' tidak ditemukan di Excel")

        # Loop semua baris, cari berdasarkan App ID
        found = False
        for row in sheet.iter_rows(min_row=2):
            cell_app_id = row[headers["App ID"] - 1].value
            if str(cell_app_id).strip() == str(app_id).strip():
                row[headers["Nama Konsumen"] - 1].value = nama_konsumen
                row[headers["No Kontrak"] - 1].value = no_kontrak
                row[headers["Nilai Pelunasan"] - 1].value = nilai_pelunasan
                row[headers["Tanggal Masuk"] - 1].value = tanggal_masuk
                row[headers["Cabang App"] - 1].value = cabang_app
                row[headers["Dokumen Uploaded"] - 1].value = dokumen_upload
                found = True
                print(f"[v] Data berhasil diupdate untuk App ID: {app_id}")
                break

        if not found:
            print(f"[x] App ID {app_id} tidak ditemukan di sheet 'Data Testing'")

        wb.save(abs_path)    

    # driver = start_browser()
    wait = WebDriverWait(driver, 2)

    print("[DEBUG] Menjalankan scenario_input() dengan data:")
    print(f"USERNAME: {p_user_id}")
    print(f"app_id: {p_app_id}")
    print(f"document_blanko: {p_document_blanko}")
    print(f"document_memo_ca: {p_document_memo_ca}")
    print(f"document_simulasi_et: {p_document_simulasi_et}")
    print(f"alasan_ca: {p_alasan_ca}")

    # Buka halaman login
    driver.get(BASE_URL)    
    isi("//input[@id='userid']", p_user_id)
    isi("//input[@id='password']", p_pwd)
    klik("//button[contains(., 'LOGIN')]")
    time.sleep(2)
    try:
        klik("//button[contains(., 'Mengerti')]")
    except: pass    
    # klik("//a[contains(@href, 'fe-appdisbursement.idofocus.co.id')]")
    wait.until(EC.element_to_be_clickable((By.XPATH,"//a[contains(@href, 'fe-appdisbursement.idofocus.co.id')]"))).click()
    time.sleep(2)

    current_url = driver.current_url
    print(current_url)
    # Validasi URL salah redirect
    if "s3-pentest.idofocus.co.id:25443/#/login" in current_url:
        print("[INFO] Redirect ke URL salah. Kembali dan klik link manual...")        
        # Kembali ke halaman sebelumnya
        isi("//input[@id='userid']", p_user_id)
        isi("//input[@id='password']", p_pwd)
        klik("//button[contains(., 'LOGIN')]")
        time.sleep(2)
        try:
            klik("//button[contains(., 'Mengerti')]")
        except: pass
        klik("//a[contains(@href, 'fe-appdisbursement.idofocus.co.id')]")
        klik("//input[@type='text' and @placeholder='APP ID / NO KONTRAK' and @name='ID']")
        print("[INFO] Klik link ke fe-appdisbursement.idofocus.co.id berhasil")
    else:
        print("[INFO] Redirect berhasil ke halaman yang benar.")
                
    try:
        search_input = WebDriverWait(driver, 15).until(
        EC.element_to_be_clickable((By.XPATH, "//input[@type='text' and @placeholder='APP ID / NO KONTRAK' and @name='ID']")))
        ActionChains(driver).move_to_element(search_input).click().perform()
        search_input.send_keys(Keys.CONTROL + "a", Keys.DELETE)
        search_input.send_keys(p_app_id + Keys.ENTER)
        time.sleep(2)  # waktu tunggu hasil muncul, bisa disesuaikan
    except Exception as e:
        print(f"[x] Tidak bisa menemukan baris APP ID: {p_app_id} => {e}")
        driver.save_screenshot(f"logs/appid_not_found_{p_app_id}.png")
        return
    
    xpath_app_row = f"//mat-cell[contains(text(),'{p_app_id}')]/ancestor::mat-row"
    if not element_exists(xpath_app_row):
        print(f"[WARNING] APP ID {p_app_id} tidak ditemukan. Skip proses.")
        return False
    try:
        element = WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.XPATH, xpath_app_row)))
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
        time.sleep(0.5)
    except Exception as e:
        print(f"[x] Tidak bisa menemukan baris APP ID: {p_app_id} => {e}")
        return
    element = WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.XPATH, xpath_app_row)))
    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
    time.sleep(0.5)
        
    def extract_data_from_table(driver):
        wait = WebDriverWait(driver, 20)

        try:
            p_app_id = wait.until(EC.presence_of_element_located((By.XPATH, "//mat-row[1]//mat-cell[contains(@class, 'cdk-column-appId')]"))).text.strip()
            p_nama_konsumen = driver.find_element(By.XPATH, "//mat-row[1]//mat-cell[contains(@class, 'cdk-column-custName')]").text.strip()
            p_no_kontrak = driver.find_element(By.XPATH, "//mat-row[1]//mat-cell[contains(@class, 'cdk-column-nokontrak')]").text.strip()
            raw_pelunasan = driver.find_element(By.XPATH, "//mat-row[1]//mat-cell[contains(@class, 'cdk-column-pencairan')]").text.strip()
            p_nilai_pelunasan = float(raw_pelunasan.replace("Rp", "").replace(".", "").replace(",", "").strip())
            p_tanggal_masuk = driver.find_element(By.XPATH, "//mat-row[1]//mat-cell[contains(@class, 'cdk-column-createdDate')]").text.strip()
            p_cabang_app = driver.find_element(By.XPATH, "//mat-row[1]//mat-cell[contains(@class, 'cdk-column-cabangAppName')]").text.strip()
            p_dokumen_upload = driver.find_element(By.XPATH, "//mat-row[1]//mat-cell[contains(@class, 'cdk-column-jumlahDoc')]").text.strip()
            
            print(f"[v] Data ditemukan untuk App ID: {p_app_id}")
            return p_app_id, p_nama_konsumen, p_no_kontrak, p_nilai_pelunasan, p_tanggal_masuk, p_cabang_app, p_dokumen_upload

        except Exception as e:
            print(f"[x] Gagal mengekstrak data dari tabel: {e}")
            raise

    try:
        p_app_id, p_nama_konsumen, p_no_kontrak, p_nilai_pelunasan, p_tanggal_masuk, p_cabang_app, p_dokumen_upload = extract_data_from_table(driver)
    except Exception as e:
        print(f"[ERROR] Gagal ekstrak data APP ID {p_app_id}, skip ke berikutnya: {e}")
        driver.save_screenshot(f"logs/extract_failed_{p_app_id}.png")
        return

    write_approval_on_double_click(
        excel_path="template_excel.xlsx",
        app_id=p_app_id,
        nama_konsumen=p_nama_konsumen,
        no_kontrak=p_no_kontrak,
        nilai_pelunasan=p_nilai_pelunasan,
        tanggal_masuk=p_tanggal_masuk,
        cabang_app=p_cabang_app,
        dokumen_upload = p_dokumen_upload
    )
    
    ActionChains(driver).double_click(element).perform()    
    # Tunggu halaman detail termuat (gunakan elemen unik)
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, f"//*[contains(text(),'{p_app_id}')]"))
    )

    safe_scroll_and_click("//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'Memo Pencairan')]]")
    time.sleep(1)
    safe_scroll_and_click("//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'MA VS Aprova')]]")
    time.sleep(1)
    safe_scroll_and_click("//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'Summary MA')]]")
    time.sleep(1)
    safe_scroll_and_click("//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'Customer Data')]]")
    time.sleep(1)
    safe_scroll_and_click("//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'Loan Data')]]")
    time.sleep(1)
    safe_scroll_and_click("//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'Persyaratan Realisasi Lainnya')]]")
    time.sleep(1)
    safe_scroll_and_click("//a[.//span[contains(text(),'Document')]]")

    if element_exists("//span[contains(text(),'Blanko Kuitansi')]"):
        upload_if_exists("Blanko Kuitansi", p_document_blanko)
        time.sleep(1)
    else:
        print("[SKIP] Kolom upload Blanko Kuitansi tidak ditemukan.")
    
    if element_exists("//span[contains(text(),'Form Survei Maskapai, Foto Kendaraan & Gesekan No. Rangka dan No. Mesin')]"):
        upload_if_exists("Form Survei Maskapai, Foto Kendaraan & Gesekan No. Rangka dan No. Mesin", p_document_maskapai)
        time.sleep(1)
    else:
        print("[SKIP] Kolom upload Survei Maskapai tidak ditemukan.")

    if element_exists("//span[contains(text(),'MEMO CA')]"):
        upload_if_exists("MEMO CA", p_document_memo_ca)
        time.sleep(1)
    else:
        print("[SKIP] Kolom upload MEMO CA tidak ditemukan.")

    if element_exists("//span[contains(text(),'SIMULASI ET')]"):
        upload_if_exists("SIMULASI ET", p_document_simulasi_et)
        time.sleep(1)
    else:
        print("[SKIP] Kolom upload SIMULASI ET tidak ditemukan.")
    
    if element_exists("//mat-label[contains(text(), 'Alasan CA')]"):
        pilih_alasan_ca(p_alasan_ca)
    else:
        print(f"[SKIP] Dropdown 'Alasan CA' tidak ditemukan di halaman.")

    
    
        

    


