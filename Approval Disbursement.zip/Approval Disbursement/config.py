import os
from dotenv import load_dotenv
from pathlib import Path

env_path = Path(__file__).resolve().parent / ".env"
load_dotenv(dotenv_path=env_path)

BASE_URL = "https://sso-s3.idofocus.co.id:25443/#/login"
USERNAME = os.getenv("MY_APP_USERNAME")
PASSWORD = os.getenv("MY_APP_PASSWORD")
EXCEL_PATH = "data/template_excel.xlsx"


