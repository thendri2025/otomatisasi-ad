import sys
import os
import logging
import time
import traceback
sys.path.append(os.path.abspath('.'))  # atau sesuai direktori root project
from config import BASE_URL, USERNAME, PASSWORD, EXCEL_PATH
from utils.browser import start_browser
from utils.excel_reader import load_excel_sheet_data
from test_scripts.scenario_input import scenario_input
from test_scripts.scenario_approval import scenario_approval
from test_scripts.scenario_loop_approval import scenario_loop_approval
from test_scripts.scenario_reject import scenario_reject
from test_scripts.scenario_pending import scenario_pending
from test_scripts.scenario_save import scenario_save
from test_scripts.scenario_get_approval import scenario_get_approval
from test_scripts.scenario_get_approval import get_struktur_approval
from test_scripts.scenario_get_approval import write_approval_to_excel
from utils.logger import log_message
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd

def loop_approval_by_hierarchy(app_id, struktur_akun):
    for i, approver in enumerate(struktur_akun[1:], start=2):  # mulai dari Level-2
        user = str(approver.get("User ID", "")).strip()
        pwd = str(approver.get("Password", "")).strip()
        jabatan = approver.get("Jabatan", f"Level-{i}")

        if not user or user.lower() == "none":
            print(f"[SKIP] User ID kosong untuk {jabatan}, tidak dilakukan approval.")
            continue

        print(f"\n[🔁] Login sebagai {jabatan} ({user}) untuk approve APP ID {app_id}")
        
        try:
            # Buat driver baru untuk tiap user
            driver = start_browser()

            scenario_loop_approval(driver, app_id, user, pwd)

            wait = WebDriverWait(driver, 15)
            logout_btn = wait.until(EC.element_to_be_clickable(
                (By.XPATH, "//button[@aria-label='Logout' and .//mat-icon[text()='logout']]")))
            logout_btn.click()
            print(f"[v] Approval sukses oleh {jabatan} ({user})")
        except Exception as e:
            print(f"[x] Gagal approve oleh {jabatan} ({user}): {e}")
        finally:
            driver.quit()
            time.sleep(3)


# Load data dari sheet 'Data Testing'
data_rows = load_excel_sheet_data(EXCEL_PATH, "Data Testing")
driver = start_browser() 
# Loop data
# for row in data_rows[:1]:
for row in data_rows:    
    app_id = str(row[0]).strip() if row[0] else ""
    action_approval = str(row[1]).strip().lower() if row[1] else ""
    description_approval = str(row[2]).strip().lower() if row[2] else ""
    action_inquiry_ca = str(row[3]).strip().lower() if len(row) > 3 and row[3] else ""
    document_blanko = str(row[4]).strip().lower() if len(row) > 4 and row[4] else ""
    document_maskapai = str(row[5]).strip().lower() if len(row) > 5 and row[5] else ""
    document_memo_ca = str(row[6]).strip().lower() if len(row) > 6 and row[6] else ""
    document_simulasi_et = str(row[7]).strip().lower() if len(row) > 7 and row[7] else ""
    alasan_ca = str(row[8]).strip().upper() if len(row) > 8 and row[8] else ""

    if not app_id:
        continue
    try:        
        success_input = scenario_input(driver, USERNAME, PASSWORD, app_id, document_blanko, document_maskapai, document_memo_ca, document_simulasi_et, alasan_ca)
        # if not success_input:
        #     print(f"[SKIP] Proses approval dihentikan untuk APP ID {app_id} karena input gagal.")
        #     continue
    except Exception as e:
        print(f"[ERROR] Gagal memproses APP ID {app_id}: {e}")
        traceback.print_exc()  # Menampilkan full stack trace ke console
        continue  # lanjut ke user berikutnya
    
    if action_approval == "approve":        
        scenario_approval(driver, app_id)
    elif action_approval == "reject":
        scenario_reject(driver, app_id, description_approval)
    elif action_approval == "pending":
        scenario_pending(driver, app_id, description_approval)
    elif action_approval == "save":
        scenario_save(driver, app_id)
        
    # Path file Excel
    excel_path = "template_excel.xlsx"
    if not excel_path.lower().endswith('.xlsx'):
        excel_path += '.xlsx'
    excel_path = os.path.join("data", excel_path)
    abs_excel_path = os.path.abspath(excel_path)
    print(abs_excel_path)

    # Load semua sheet yang diperlukan
    sheet_excel_data = pd.read_excel(abs_excel_path, sheet_name=None)

    # Ambil sheet yang dibutuhkan
    df_testing = sheet_excel_data["Data Testing"]
    df_kelas = sheet_excel_data["Kelas Cabang"]
    df_limit = sheet_excel_data["Limit Approval"]
    df_hierarchy = sheet_excel_data["Hierarky Approval"]

    # hasil = scenario_get_approval(app_id, df_testing, df_kelas, df_limit, df_hierarchy)
    hasil = scenario_get_approval(app_id, df_testing, df_kelas, df_limit)
    if isinstance(hasil, dict):
        struktur_akun = hasil["User Login List"]
        mapping_excel = hasil["Mapping Excel"]
        write_approval_to_excel(app_id, mapping_excel)
        print(hasil)
        for approver in struktur_akun:
            print(f"{approver['Jabatan']}: {approver['User ID']} / {approver['Password']}")
        
        # wait = WebDriverWait(driver, 10)
        # logout_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Logout' and .//mat-icon[text()='logout']]")))
        # logout_btn.click()

        try:
            wait = WebDriverWait(driver, 10)
            logout_btn = wait.until(EC.element_to_be_clickable(
                (By.XPATH, "//button[@aria-label='Logout' and .//mat-icon[text()='logout']]")))
            logout_btn.click()
            print("[v] Logout berhasil")
        except TimeoutException:
            print("[!] Logout button tidak ditemukan — kemungkinan sudah logout atau session expired")


        # Jalankan hanya jika user memilih action_approval == approve
        if action_approval == "approve":
            loop_approval_by_hierarchy(app_id, struktur_akun)            
    else:
        print(hasil)  # Jika error seperti App ID tidak ditemukan
