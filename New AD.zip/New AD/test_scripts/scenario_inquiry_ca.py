from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains  
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from openpyxl import load_workbook
import time
import os
import pyautogui
import logging


# ========== CONFIGURATION =========
# EXCEL_PATH = 'data_login.xlsx'
EXCEL_PATH = 'D:/QA/Otomatisasi Project/Inquiry CA/data/data_login.xlsx'
URL_LOGIN = 'https://s3-pentest.idofocus.co.id:25443/#/login'
# ===================================

# XPATH MAPPING
XPATHS = {
    'nama_konsumen': "//mat-cell[contains(@class, 'cdk-column-custName')]",
    'no_kontrak': "//mat-cell[contains(@class, 'cdk-column-noKontrak')]",
    'alasan_ca': "//mat-cell[contains(@class, 'cdk-column-reasonCA')]",
    'tgl_realisasi': "//mat-cell[contains(@class, 'cdk-column-realizationDate')]",
    'absah': "//mat-cell[contains(@class, 'cdk-column-absah')]",
    'status': "//mat-cell[contains(@class, 'cdk-column-status')]//span[@class='pill']",
}


def klik(driver, xpath):
    element = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, xpath))
    )
    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
    WebDriverWait(driver, 15).until(EC.element_to_be_clickable((By.XPATH, xpath)))
    time.sleep(1)
    try:
        element.click()
    except:
        driver.execute_script("arguments[0].click();", element)

def isi(driver, xpath, value):
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, xpath))).send_keys(value)

def scroll(driver, xpath):
    element = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.XPATH, xpath)))
    driver.execute_script("arguments[0].scrollIntoView();", element)

def safe_scroll_and_click(driver, xpath):
    try:
        elems = driver.find_elements(By.XPATH, xpath)
        if elems:
            scroll(driver, xpath)
            klik(driver, xpath)
        else:
            print(f"[SKIP] Elemen tidak ditemukan: {xpath}")
    except Exception as e:
        print(f"[ERROR] Gagal scroll/klik elemen: {xpath} => {e}")

def element_exists(driver, xpath):
    return len(driver.find_elements(By.XPATH, xpath)) > 0

def baca_data_excel(path):
    wb = load_workbook(path)
    sheet = wb['Data Testing']
    data_dict = {}
    for row in sheet.iter_rows(min_row=2, values_only=True):
        app_id = str(row[0]) if row[0] else ''
        if not app_id:
            continue
        action = str(row[1]) if len(row) > 1 and row[1] else ''
        description = str(row[2]) if len(row) > 2 and row[2] else ''
        data_dict[app_id] = {
            'action': action,
            'description': description,
        }
    return data_dict

def start_browser():
    options = webdriver.ChromeOptions()
    options.add_argument('--start-maximized')
    # options.add_argument('--headless')  # Uncomment jika ingin tanpa buka browser
    driver = webdriver.Chrome(options=options)
    return driver
def ambil_teks(driver, xpath):
    return WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, xpath))).text.strip()

def baca_data_login(path):
    wb = load_workbook(path)
    sheet = wb['LoginData']
    return str(sheet['A2'].value), str(sheet['B2'].value)

def baca_app_id(path):
    wb = load_workbook(path)
    sheet = wb['Data Testing']
    return [str(row[0]) for row in sheet.iter_rows(min_row=2, max_col=1, values_only=True) if row[0]]

def tulis_data_ke_excel(path, app_id, data_dict):
    wb = load_workbook(path)
    sheet = wb['Data Testing']
    for row in sheet.iter_rows(min_row=2):
        if str(row[0].value) == app_id:
            row[3].value = data_dict['nama_konsumen']
            row[4].value = data_dict['no_kontrak']
            row[5].value = data_dict['alasan_ca']
            row[6].value = data_dict['tgl_realisasi']
            row[7].value = data_dict['absah']
            row[8].value = data_dict['status']
            break
    wb.save(path)

def upload_dokumen(driver, label_teks, path_file):
    # Pastikan ekstensi .pdf
    if not path_file.lower().endswith('.pdf'):
        path_file += '.pdf'
    path_file = os.path.join("data", path_file)
    abs_path = os.path.abspath(path_file)

    # Validasi apakah file benar-benar ada
    if not os.path.exists(abs_path):
        print(f"[ERROR] File tidak ditemukan: {abs_path}")
        return

    print(f"[INFO] Mulai upload '{label_teks}' dari: {abs_path}")
    # Gunakan XPath yang benar-benar klik tombol upload
    xpath_icon = f"//div[contains(@class,'uploadField') and contains(normalize-space(.),'{label_teks}')]/mat-icon"

    try:
        icon_upload = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, xpath_icon))
        )
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", icon_upload)
        time.sleep(0.2)
        icon_upload.click()
        print(f"[INFO] Klik ikon upload berhasil untuk: {label_teks}")
    except TimeoutException:
        print(f"[ERROR] Tidak bisa menemukan ikon upload untuk: '{label_teks}'")
        return
    except Exception as e:
        print(f"[ERROR] Gagal klik ikon upload: {e}")
        return

    # Kirim path file ke native dialog (pakai pyautogui)
    time.sleep(1.5)  # beri waktu untuk dialog terbuka
    try:
        pyautogui.write(abs_path)
        time.sleep(0.5)
        pyautogui.press('enter')
        print(f"[v] Upload berhasil: {label_teks}")
    except Exception as e:
        print(f"[ERROR] Gagal menulis path file: {e}")

def upload_if_exists(driver,label_teks, filename):
    if filename:
        if not filename.lower().endswith('.pdf'):
            filename += '.pdf'
        path_file = os.path.join("data", filename)
        if os.path.exists(path_file):
            try:
                if driver.session_id:
                    upload_dokumen(driver,label_teks, filename)
            except Exception as e:
                print(f"[ERROR] Gagal upload_dokumen {label_teks}: {e}")
        else:
            print(f"[WARNING] File tidak ditemukan: {path_file}")

def proses():
    logging.basicConfig(filename='logs/appid_log.txt', level=logging.INFO, format='%(asctime)s - %(message)s')
    username, password = baca_data_login(EXCEL_PATH)    
    app_ids = baca_app_id(EXCEL_PATH)
    driver = start_browser()
    driver.get(URL_LOGIN)
    isi(driver, "//input[@id='userid']", username)
    isi(driver, "//input[@id='password']", password)
    klik(driver, "//button[contains(., 'LOGIN')]")
    time.sleep(2)

    try:
        klik(driver, "//button[contains(., 'Mengerti')]")
    except: pass

    klik(driver, "//a[contains(@href, 'fe-appdisbursement.idofocus.co.id')]")
    klik(driver, "//a[.//span[contains(text(), 'Inquiry CA')]]")
    upload_data_dict = baca_data_excel(EXCEL_PATH)
    for app_id in app_ids:
        try:
            isi(driver, "//input[@placeholder='APP ID / NO KONTRAK']", app_id)
            time.sleep(2)
            try:
                search_input = WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.XPATH, "//input[@placeholder='APP ID / NO KONTRAK']")))
                ActionChains(driver).move_to_element(search_input).click().perform()
                # search_input.clear()
                search_input.send_keys(Keys.CONTROL + "a", Keys.DELETE)
                search_input.send_keys(app_id + Keys.ENTER)
                time.sleep(2)  # waktu tunggu hasil muncul, bisa disesuaikan
            except Exception as e:
                print(f"[x] Tidak bisa menemukan baris APP ID: {app_id} => {e}")
                driver.save_screenshot(f"logs/appid_not_found_{app_id}.png")
                return
            
            xpath_app_row = f"//mat-cell[normalize-space(text())='{app_id}']/ancestor::mat-row"
            try:
                element = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.XPATH, xpath_app_row)))
                driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
                time.sleep(0.5)
            except Exception as e:
                print(f"[x] Tidak bisa menemukan baris APP ID: {app_id} => {e}")
                return
            element = WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.XPATH, xpath_app_row)))
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
            time.sleep(0.5)
        
            hasil = {k: ambil_teks(driver, v) for k, v in XPATHS.items()}
            tulis_data_ke_excel(EXCEL_PATH, app_id, hasil)
            ActionChains(driver).double_click(element).perform()
            time.sleep(1)
            safe_scroll_and_click(driver,"//mat-expansion-panel-header[.//mat-panel-title[normalize-space()='Memo Pencairan']]")
            time.sleep(1)
            safe_scroll_and_click(driver,"//mat-expansion-panel-header[.//mat-panel-title[contains(normalize-space(), 'MA VS Aprova')]]")
            time.sleep(1)
            safe_scroll_and_click(driver,"//mat-expansion-panel-header[.//mat-panel-title[contains(normalize-space(),'Summary MA')]]")
            time.sleep(1)
            safe_scroll_and_click(driver,"//mat-expansion-panel-header[.//mat-panel-title[contains(normalize-space(),'Customer Data')]]")
            time.sleep(1)
            safe_scroll_and_click(driver,"//mat-expansion-panel-header[.//mat-panel-title[contains(normalize-space(),'Loan Data')]]")
            time.sleep(1)
            safe_scroll_and_click(driver,"//mat-expansion-panel-header[.//mat-panel-title[contains(normalize-space(),'Persyaratan Realisasi Lainnya')]]")
            time.sleep(1)
            safe_scroll_and_click(driver,"//a[.//span[contains(text(),'Document')]]")
            time.sleep(1)

            main_window = driver.current_window_handle
            existing_windows = driver.window_handles

            # Klik tombol visibility
            xpath_visibility = "//div[contains(@class,'uploadContainer') and contains(., 'Survei_Maskapai')]//button[.//mat-icon[text()='visibility'] and not(@disabled)]"
            safe_scroll_and_click(driver, xpath_visibility)
            time.sleep(1)  # Beri waktu untuk membuka tab baru

            # Cek tab/window baru dan pindah
            new_windows = driver.window_handles
            for window in new_windows:
                if window not in existing_windows:
                    driver.switch_to.window(window)
                    print("[INFO] Berpindah ke tab dokumen preview.")
                    time.sleep(1)  # Tunggu dokumen tampil
                    driver.close()
                    print("[INFO] Menutup tab dokumen.")
                    driver.switch_to.window(main_window)
                    print("[INFO] Kembali ke tab utama.")
                    break
            
            # Eksekusi aksi berdasarkan kolom 'action'
            action = upload_data_dict.get(app_id, {}).get('action', '').strip().lower()
            if action == 'pending':
                try:
                    klik(driver, "//button[@aria-label='Pending Button']")
                    description = upload_data_dict.get(app_id, {}).get('description', '').strip().lower()
                    time.sleep(3)
                    isi(driver, "//label[.//mat-label[text()='Alasan Pending']]/ancestor::div[contains(@class, 'mat-mdc-text-field-wrapper')]//textarea", description)
                    time.sleep(3)
                    # WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//button[.//span[contains(text(), 'Pending')] and @mat-dialog-close]"))).click()
                    # sementara di klik cancel dulu
                    WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//button[normalize-space(.//span[@class='mdc-button__label'])='Cancel']"))).click()            
                    time.sleep(3)
                    print(f"[INFO] proses'Pending' untuk APP ID {app_id} berhasil")
                except Exception as e:
                    print(f"[ERROR] Gagal klik tombol Pending: {e}")
            elif action == 'proceed':
                try:
                    # klik(driver, "//button[@aria-label='Proceed Button']")
                    print(f"[INFO] 'Proceed' untuk APP ID {app_id} berhasil")                
                    time.sleep(3)
                except Exception as e:
                    print(f"[ERROR] Gagal klik tombol Proceed: {e}")
            else:
                print(f"[INFO] Tidak ada aksi tombol untuk APP ID {app_id} (action: '{action}')")

            print(f"[✅] APP ID {app_id} selesai.")
            logging.info(f"SUCCESS: APP ID {app_id} selesai.")
            klik(driver,"//button[.//span[normalize-space(text())='Back']]")
            WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//button[.//span[contains(text(), 'Ya')]]"))).click()
        except Exception as e:
            print(f"[❌] Error APP ID {app_id}: {e}")
            logging.error(f"ERROR: APP ID {app_id} - {e}")
        # finally:
        #     driver.quit()
    klik(driver,"//button[@type='button' and @aria-label='Logout' and .//mat-icon[text()='logout']]")

if __name__ == '__main__':
    proses()

