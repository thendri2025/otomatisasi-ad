from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException
import time
from config import BASE_URL

def scenario_loop_approval(driver, app_id, user_id=None, password=None):
    wait = WebDriverWait(driver, 10)

    # Login otomatis jika user_id dan password disediakan
    if user_id and password:
        print(f"[LOGIN] Login sebagai: {user_id}")
        driver.get(BASE_URL)

        try:
            wait.until(EC.presence_of_element_located((By.ID, "userid"))).send_keys(user_id)
            wait.until(EC.presence_of_element_located((By.ID, "password"))).send_keys(password)
            wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(., 'LOGIN')]"))).click()
            time.sleep(3)

            try:
                wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(., 'Mengerti')]"))).click()
                print("[INFO] Klik tombol 'Mengerti'")
            except TimeoutException:
                pass  # tombol 'Mengerti' tidak selalu muncul

        except Exception as e:
            print(f"[ERROR] Gagal login sebagai {user_id}: {e}")
            return

    try:
        driver.get("https://sso-s3.idofocus.co.id:25443/#/dashboard")
        wait.until(EC.element_to_be_clickable((By.XPATH,
            "//a[contains(@href, 'fe-appdisbursement.idofocus.co.id')]"))).click()
        print("[INFO] Masuk ke halaman Approval Disbursement")

        # Cari APP ID
        search_input = wait.until(
            EC.element_to_be_clickable((By.XPATH, "//input[@name='ID']"))
        )
        search_input.clear()
        search_input.send_keys(app_id + Keys.ENTER)
        time.sleep(3)

        # Klik baris APP ID
        xpath_app_row = f"//mat-cell[contains(text(),'{app_id}')]/ancestor::mat-row"
        element = wait.until(EC.element_to_be_clickable((By.XPATH, xpath_app_row)))
        ActionChains(driver).double_click(element).perform()

        # Tunggu halaman detail termuat
        wait.until(EC.presence_of_element_located((By.XPATH, f"//*[contains(text(),'{app_id}')]")))
        print(f"[APPROVAL] Masuk detail APP ID {app_id}")

        # Klik tombol Approve
        # wait.until(EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Proceed Button' and .//span[text()='Proceed']]"))).click()
        print(f"[\u2705] Approval berhasil untuk APP ID {app_id} oleh {user_id or 'user utama'}")

        time.sleep(2)

    except Exception as e:
        print(f"[\u274C] Gagal approve APP ID {app_id}: {e}")
