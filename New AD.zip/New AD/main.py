import sys
import os
import logging
import time
import traceback
sys.path.append(os.path.abspath('.'))  # atau sesuai direktori root project
from config import BASE_URL, USERNAME, PASSWORD, EXCEL_PATH
from utils.browser import start_browser
from utils.excel_reader import load_excel_sheet_data
from test_scripts.scenario_input import scenario_input
from test_scripts.scenario_approval import scenario_approval
from test_scripts.scenario_loop_approval import scenario_loop_approval
from test_scripts.scenario_reject import scenario_reject
from test_scripts.scenario_pending import scenario_pending
from test_scripts.scenario_save import scenario_save
from test_scripts import scenario_inquiry_ca
from test_scripts.scenario_get_approval import scenario_get_approval
from test_scripts.scenario_get_approval import get_struktur_approval
from test_scripts.scenario_get_approval import write_approval_to_excel
from utils.logger import log_message
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
import pandas as pd

def loop_approval_by_hierarchy(app_id, struktur_akun):
    success = True
    for i, approver in enumerate(struktur_akun[1:], start=2):  # mulai dari Level-2
        user = str(approver.get("User ID", "")).strip()
        pwd = str(approver.get("Password", "")).strip()
        jabatan = approver.get("Jabatan", f"Level-{i}")

        if not user or user.lower() == "none":
            print(f"[SKIP] User ID kosong untuk {jabatan}, tidak dilakukan approval.")
            continue

        print(f"\n[🔁] Login sebagai {jabatan} ({user}) untuk approve APP ID {app_id}")
        
        try:
            # Buat driver baru untuk tiap user
            driver = start_browser()

            scenario_loop_approval(driver, app_id, user, pwd)

            wait = WebDriverWait(driver, 15)
            logout_btn = wait.until(EC.element_to_be_clickable(
                (By.XPATH, "//button[@aria-label='Logout' and .//mat-icon[text()='logout']]")))
            logout_btn.click()
            print(f"[v] Approval sukses oleh {jabatan} ({user})")
        except Exception as e:
            print(f"[x] Gagal approve oleh {jabatan} ({user}): {e}")
            success = False
        finally:            
            driver.quit()
            time.sleep(3)
    return success
    
def scroll(driver,xpath):
            element = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.XPATH, xpath)))
            driver.execute_script("arguments[0].scrollIntoView();", element)
def safe_scroll(driver,xpath):
        try:
            elems = driver.find_elements(By.XPATH, xpath)
            if elems:
                scroll(driver,xpath)
            else:
                print(f"[SKIP] Elemen tidak ditemukan: {xpath}")
        except Exception as e:
            print(f"[ERROR] Gagal scroll elemen: {xpath} => {e}")
def klik(driver,xpath):
        element = WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, xpath))
        )
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
        WebDriverWait(driver, 15).until(EC.element_to_be_clickable((By.XPATH, xpath)))
        time.sleep(1)
        try:
            element.click()
        except:
            driver.execute_script("arguments[0].click();", element)
def ambil_screenshot(driver, folder, timestamp, nama_aksi, xpath):
    try:
        safe_scroll(driver, xpath)
        fname = f"{timestamp}_{nama_aksi}.png"
        path = os.path.join(folder, fname)
        driver.save_screenshot(path)
        print(f"[📸] Screenshot disimpan: {path}")
        time.sleep(1)
    except Exception as e:
        print(f"[⚠️] Gagal screenshot {nama_aksi}: {e}")

from config import DOCUMENT_BLANKO, DOCUMENT_MASKAPAI, DOCUMENT_MEMO_CA, DOCUMENT_SIMULASI_ET, ALASAN_CA
# Load data dari sheet 'Data Testing'
data_rows = load_excel_sheet_data(EXCEL_PATH, "Data Testing")
driver = start_browser() 
# Loop data
for row in data_rows[:1]:
# for row in data_rows:    
    app_id = str(row[0]).strip() if row[0] else ""
    action_approval = str(row[1]).strip().lower() if row[1] else ""
    description_approval = str(row[2]).strip().lower() if row[2] else ""
    # ganti ambil dari global variable
    document_blanko = DOCUMENT_BLANKO
    document_maskapai = DOCUMENT_MASKAPAI
    document_memo_ca = DOCUMENT_MEMO_CA
    document_simulasi_et = DOCUMENT_SIMULASI_ET
    alasan_ca = ALASAN_CA
    
    if not app_id:
        continue
    try:        
        success_input = scenario_input(driver, USERNAME, PASSWORD, app_id, document_blanko, document_maskapai, document_memo_ca, document_simulasi_et, alasan_ca)
    except Exception as e:
        print(f"[ERROR] Gagal memproses APP ID {app_id}: {e}")
        traceback.print_exc()  # Menampilkan full stack trace ke console
        continue  # lanjut ke user berikutnya
    
    if action_approval == "approve":        
        scenario_approval(driver, app_id)
    elif action_approval == "reject":
        scenario_reject(driver, app_id, description_approval)
    elif action_approval == "pending":
        scenario_pending(driver, app_id, description_approval)
    elif action_approval == "save":
        scenario_save(driver, app_id)
        
    # Path file Excel
    excel_path = EXCEL_PATH 
    if not excel_path.lower().endswith('.xlsx'):
        excel_path += '.xlsx'
    # excel_path = os.path.join("data", excel_path)
    abs_excel_path = os.path.abspath(excel_path)
    print(abs_excel_path)

    # Load semua sheet yang diperlukan
    sheet_excel_data = pd.read_excel(abs_excel_path, sheet_name=None)

    # Ambil sheet yang dibutuhkan
    df_testing = sheet_excel_data["Data Testing"]
    df_kelas = sheet_excel_data["Kelas Cabang"]
    df_limit = sheet_excel_data["Limit Approval"]
    df_hierarchy = sheet_excel_data["Hierarky Approval"]

    hasil = scenario_get_approval(app_id, df_testing, df_kelas, df_limit)
    if isinstance(hasil, dict):
        struktur_akun = hasil["User Login List"]
        mapping_excel = hasil["Mapping Excel"]
        write_approval_to_excel(app_id, mapping_excel)
        print(hasil)
        for approver in struktur_akun:
            masked_pwd = '*' * len(str(approver['Password'] or ''))
            print(f"{approver['Jabatan']}: {approver['User ID']} / {masked_pwd}")
        
        # Screenshot        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        folder = os.path.join("screenshots", str(app_id) if app_id else "general")
        os.makedirs(folder, exist_ok=True)

        # Klik tab Detail
        klik(driver, "//a[.//span[contains(text(),'Detail')]]")
        time.sleep(1)
        # Daftar elemen yang ingin di-screenshot di tab Detail
        detail_sections = [
            ("Detail1", "//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'Memo Pencairan')]]"),
            ("Detail2", "//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'MA VS Aprova')]]"),
            ("Detail3", "//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'Summary MA')]]"),
            ("Detail4", "//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'Customer Data')]]"),
            ("Detail5", "//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'Loan Data')]]"),
            ("Detail6", "//mat-expansion-panel-header[.//mat-panel-title[contains(text(),'Persyaratan Realisasi Lainnya')]]"),
        ]
        # Screenshot tab Detail
        for nama_aksi, xpath in detail_sections:
            ambil_screenshot(driver, folder, timestamp, nama_aksi, xpath)
        # Pindah ke tab Document
        klik(driver, "//a[.//span[contains(text(),'Document')]]")
        time.sleep(1)
        # Daftar elemen yang ingin di-screenshot di tab Document
        document_sections = [
            ("Document1", "//span[contains(text(),'Blanko Kuitansi')]"),
            ("Document2", "//span[contains(text(),'SIMULASI ET')]"),
        ]
        # Screenshot tab Document
        for nama_aksi, xpath in document_sections:
            ambil_screenshot(driver, folder, timestamp, nama_aksi, xpath)

        try:
            wait = WebDriverWait(driver, 15)
            logout_btn = wait.until(EC.element_to_be_clickable(
                (By.XPATH, "//button[@aria-label='Logout' and .//mat-icon[text()='logout']]")))

            # Cek apakah ada overlay aktif
            try:
                WebDriverWait(driver, 5).until(
                    EC.invisibility_of_element_located((By.CLASS_NAME, "cdk-overlay-backdrop"))
                )
            except TimeoutException:
                print("[⚠️] Overlay masih aktif, mencoba klik pakai JavaScript.")

            try:
                logout_btn.click()
            except Exception:
                driver.execute_script("arguments[0].click();", logout_btn)
                print("[!] Klik logout pakai JavaScript.")

            print("[v] Logout berhasil")
        except TimeoutException:
            print("[!] Logout button tidak ditemukan — kemungkinan sudah logout atau session expired")

        # Jalankan hanya jika user memilih action_approval == approve
        if action_approval == "approve":
            # loop_approval_by_hierarchy(app_id, struktur_akun)            
            success = loop_approval_by_hierarchy(app_id, struktur_akun)
            if success:
                print("[✔️] Semua approval berhasil, lanjut ke Inquiry CA")
                try:
                    # scenario_inquiry_ca.proses(app_id)
                    # testing data inquiry : 3715305
                    scenario_inquiry_ca.proses('3715305')
                except Exception as e:
                    print(f"[⚠️] Gagal menjalankan Inquiry CA untuk APP ID {app_id}: {e}")
            else:
                print(hasil)  # Jika error seperti App ID tidak ditemukan
